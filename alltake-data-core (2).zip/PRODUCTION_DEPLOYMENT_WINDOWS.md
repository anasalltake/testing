# ALLTAKE B2B Intelligence – Production Windows Server Runbook

## 1. System Requirements
- **OS**: Windows Server 2019 / 2022 (Standard or Datacenter)
- **CPU**: 4 Cores minimum
- **RAM**: 16 GB minimum
- **Disk**: 512 GB SSD storage
- **Software**: Python 3.10+ (64-bit), Node.js v18/20 LTS, Git for Windows

---

## 2. Step-by-Step Production Installation

### Step 1: Clone & Run Automated Setup Script
Open an Administrator Command Prompt:
```cmd
cd C:\inetpub\wwwroot
git clone <repository_url> alltake-core
cd alltake-core
call setup_windows.bat
```

### Step 2: Seed Production Administrator Credentials
```cmd
call backend\venv\Scripts\activate.bat
python backend\seed.py
```

### Step 3: Configure Windows Services with NSSM
Download `nssm.exe` and place in `C:\tools\nssm`:
```cmd
:: 1. Backend Service (Port 5000)
C:\tools\nssm\nssm.exe install AlltakeBackend "C:\inetpub\wwwroot\alltake-core\backend\venv\Scripts\python.exe" "C:\inetpub\wwwroot\alltake-core\backend\run.py"
C:\tools\nssm\nssm.exe set AlltakeBackend AppDirectory "C:\inetpub\wwwroot\alltake-core\backend"
C:\tools\nssm\nssm.exe set AlltakeBackend Start SERVICE_AUTO_START
C:\tools\nssm\nssm.exe start AlltakeBackend

:: 2. Frontend Production Gateway (Port 3000)
cd C:\inetpub\wwwroot\alltake-core
npm run build
C:\tools\nssm\nssm.exe install AlltakeGateway "C:\Program Files\nodejs\node.exe" "C:\inetpub\wwwroot\alltake-core\node_modules\tsx\dist\cli.mjs" "server.ts"
C:\tools\nssm\nssm.exe set AlltakeGateway AppDirectory "C:\inetpub\wwwroot\alltake-core"
C:\tools\nssm\nssm.exe set AlltakeGateway Start SERVICE_AUTO_START
C:\tools\nssm\nssm.exe start AlltakeGateway
```

### Step 4: Configure Windows Firewall
Allow inbound HTTP/HTTPS and internal application ports:
```cmd
netsh advfirewall firewall add rule name="Alltake Web Gateway" dir=in action=allow protocol=TCP localport=3000
netsh advfirewall firewall add rule name="Alltake API Backend" dir=in action=allow protocol=TCP localport=5000
```

---

## 3. Service Management & Health Monitoring
- **Restart Services**:
  ```cmd
  nssm restart AlltakeBackend
  nssm restart AlltakeGateway
  ```
- **Health Check Endpoint**:
  ```cmd
  curl -s http://localhost:3000/api/exports/settings
  ```
- **Stop All Services**:
  ```cmd
  nssm stop AlltakeBackend
  nssm stop AlltakeGateway
  ```

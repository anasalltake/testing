# ALLTAKE B2B Intelligence – Windows Server Deployment Guide

## 1. Overview
This guide provides complete instructions for deploying ALLTAKE B2B Intelligence on Windows Server (2019 / 2022) using Waitress as the production WSGI server, IIS (Internet Information Services) as reverse proxy, and PostgreSQL or persistent disk storage.

---

## 2. Prerequisites
1. **Operating System**: Windows Server 2019, 2022, or Windows 10/11 Pro (64-bit).
2. **Python**: Python 3.10+ (ensure "Add Python to PATH" is checked during installation).
3. **Node.js**: Node.js v18 LTS or v20 LTS.
4. **Process Manager**: NSSM (Non-Sucking Service Manager) or Windows Task Scheduler.
5. **Web Server (Optional)**: IIS with URL Rewrite and ARR (Application Request Routing).

---

## 3. Automated Setup
Execute the included Windows batch files from an Administrator Command Prompt:

```cmd
:: 1. Navigate to application directory
cd C:\inetpub\wwwroot\alltake-applet

:: 2. Run automated setup script
setup_windows.bat

:: 3. Seed production administrator credentials
call backend\venv\Scripts\activate.bat
python backend\seed.py

:: 4. Start services
run_windows.bat
```

---

## 4. Production Service Configuration (Waitress WSGI)

### 4.1 Installing Waitress
Waitress is included in `backend/requirements.txt`. It is a production-grade, multi-threaded pure Python WSGI server designed specifically for Windows environments.

```cmd
pip install waitress
```

### 4.2 Configuring `backend/run.py`
Waitress is configured in `backend/run.py` with multi-threading:
```python
from waitress import serve
from app import create_app

app = create_app('production')

if __name__ == '__main__':
    print("Serving ALLTAKE B2B Intelligence on http://0.0.0.0:5000 (Waitress WSGI)")
    serve(app, host='0.0.0.0', port=5000, threads=16, channel_timeout=120)
```

---

## 5. Registering as Windows Services (via NSSM)

### 5.1 Backend Service (Port 5000)
```cmd
nssm install AlltakeBackend "C:\inetpub\wwwroot\alltake-applet\backend\venv\Scripts\python.exe" "C:\inetpub\wwwroot\alltake-applet\backend\run.py"
nssm set AlltakeBackend AppDirectory "C:\inetpub\wwwroot\alltake-applet\backend"
nssm set AlltakeBackend AppStdout "C:\inetpub\wwwroot\alltake-applet\backend\logs\service_out.log"
nssm set AlltakeBackend AppStderr "C:\inetpub\wwwroot\alltake-applet\backend\logs\service_err.log"
nssm start AlltakeBackend
```

### 5.2 Frontend Production Service (Port 3000)
```cmd
npm run build
nssm install AlltakeFrontend "C:\Program Files\nodejs\node.exe" "C:\inetpub\wwwroot\alltake-applet\node_modules\tsx\dist\cli.mjs" "server.ts"
nssm set AlltakeFrontend AppDirectory "C:\inetpub\wwwroot\alltake-applet"
nssm start AlltakeFrontend
```

---

## 6. IIS Reverse Proxy Configuration
To expose the application on standard port 80/443 with an SSL certificate:

1. Install **URL Rewrite 2.1** and **Application Request Routing 3.0** via Web Platform Installer.
2. In IIS Manager, create a new site pointing to `C:\inetpub\wwwroot\alltake-applet\public`.
3. Add a reverse proxy rule in `web.config`:
```xml
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="ReverseProxyToExpress" stopProcessing="true">
          <match url="(.*)" />
          <action type="Rewrite" url="http://127.0.0.1:3000/{R:1}" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration>
```

---

## 7. Verification & Health Check
Open browser and navigate to:
- `http://localhost:3000` (Frontend Dashboard & Login)
- `http://localhost:5000/api/auth/me` (Backend JWT Endpoint)

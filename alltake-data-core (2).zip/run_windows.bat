@echo off
title ALLTAKE B2B Intelligence Enterprise Core
echo ==========================================================
echo    ALLTAKE B2B INTELLIGENCE - PRODUCTION RUNNER (WINDOWS)
echo ==========================================================

cd /d "%~dp0"

echo [1/3] Activating Python Virtual Environment...
if exist "backend\venv\Scripts\activate.bat" (
    call backend\venv\Scripts\activate.bat
) else (
    echo [WARNING] backend\venv not found. Running with global python...
)

echo [2/3] Verifying Database and Environment...
if not exist "backend\.env" (
    echo [NOTICE] backend\.env not found. Creating from .env.example...
    copy backend\.env.example backend\.env
)

echo [3/3] Starting Production Engine Services...
echo - Starting Backend Server with Waitress WSGI on port 5000...
start "ALLTAKE API Core (Port 5000)" cmd /k "cd /d %~dp0\backend && python run.py"

echo - Starting Enterprise Frontend UI on port 3000...
start "ALLTAKE UI Portal (Port 3000)" cmd /k "cd /d %~dp0 && npm run dev"

echo.
echo ==========================================================
echo ALLTAKE B2B Intelligence is now launching!
echo Access Portal: http://localhost:3000
echo API Gateway:   http://localhost:5000/api
echo ==========================================================
echo Press any key to stop all background windows...
pause >nul
taskkill /fi "WINDOWTITLE eq ALLTAKE*" /f

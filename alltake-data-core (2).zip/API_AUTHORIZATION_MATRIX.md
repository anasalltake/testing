# ALLTAKE B2B Intelligence – Role-Based Access Control (RBAC) Matrix

## 1. Overview
Access control is enforced strictly on the backend on every API endpoint. Frontend UI state, role claims in localStorage, or client cookies are never trusted for authorization.

---

## 2. API Endpoint Authorization Matrix

| Endpoint | Method | Permitted Roles | Description | Notes |
| :--- | :---: | :---: | :--- | :--- |
| `/api/auth/login` | `POST` | Public | Authenticates credentials | Rate limited, generic error responses |
| `/api/auth/me` | `GET` | Authenticated | Verifies JWT & returns profile | Checks token revocation registry |
| `/api/auth/logout` | `POST` | Authenticated | Terminates active session | Immediately blacklists token JTI |
| `/api/leads` | `GET` | Authenticated | Queries prospect leads | Auto-masks PII for `EMPLOYEE` |
| `/api/uploads/preview` | `POST` | `ADMIN`, `DATA_MANAGER` | Ingests CSV preview | Validates structure & MIME |
| `/api/uploads/confirm` | `POST` | `ADMIN`, `DATA_MANAGER` | Commits ingested records | Chunked transactional insert |
| `/api/exports/validate-limit` | `POST` | Authenticated | Checks quota rules | Evaluates employee 10,000 threshold |
| `/api/exports/request-approval` | `POST` | `EMPLOYEE` | Requests mass download | Requires justification & campaign name |
| `/api/exports/notify` | `POST` | Authenticated | Records campaign download | Dispatches Resend alert & logs audit |
| `/api/admin/exports/requests/:id/approve` | `POST` | `ADMIN` | Approves mass export | Grants download access |
| `/api/admin/exports/requests/:id/reject` | `POST` | `ADMIN` | Rejects mass export | Records rejection rationale |
| `/api/admin/users` | `GET`, `POST` | `ADMIN` | User provisioning & management | Lists personnel & creates accounts |
| `/api/admin/users/:id/reset-password` | `POST` | `ADMIN` | Admin password override | Invalidates all prior sessions |
| `/api/admin/users/:id/toggle-block` | `PATCH` | `ADMIN` | Suspends/restores account | Invalidates sessions on block |
| `/api/admin/columns` | `GET`, `PUT` | `ADMIN` (PUT) | Customizes column layout & masking | Sets order & employee visibility |
| `/api/logs/audit` | `GET` | `ADMIN` | Immutable compliance ledger | Read-only SHA-256 event stream |
| `/api/logs/logins` | `GET` | `ADMIN` | Authentication attempts & IPs | Monitors failed brute-force spikes |

import uuid
from datetime import datetime
from app.extensions import db

class DatasetColumn(db.Model):
    __tablename__ = 'dataset_columns'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"col_{uuid.uuid4().hex[:12]}")
    dataset_id = db.Column(db.String(64), db.ForeignKey('datasets.id', ondelete='CASCADE'), nullable=False, index=True)
    column_name = db.Column(db.String(100), nullable=False)
    display_name = db.Column(db.String(150), nullable=False)
    data_type = db.Column(db.String(50), default='string', nullable=False)
    is_core = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'dataset_id': self.dataset_id,
            'column_name': self.column_name,
            'display_name': self.display_name,
            'data_type': self.data_type,
            'is_core': self.is_core,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

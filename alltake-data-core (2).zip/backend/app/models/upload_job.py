import uuid
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSONB
from app.extensions import db

class UploadJob(db.Model):
    __tablename__ = 'upload_jobs'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"job_upl_{uuid.uuid4().hex[:12]}")
    user_id = db.Column(db.String(64), nullable=False, index=True)
    user_name = db.Column(db.String(200), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    file_size = db.Column(db.BigInteger, nullable=False)
    dataset_id = db.Column(db.String(64), nullable=True)
    dataset_name = db.Column(db.String(255), nullable=False)
    row_count = db.Column(db.Integer, default=0, nullable=False)
    column_count = db.Column(db.Integer, default=0, nullable=False)
    valid_rows = db.Column(db.Integer, default=0, nullable=False)
    invalid_rows = db.Column(db.Integer, default=0, nullable=False)
    duplicate_rows = db.Column(db.Integer, default=0, nullable=False)
    new_columns = db.Column(db.JSON().with_variant(JSONB, 'postgresql'), default=list)
    existing_columns = db.Column(db.JSON().with_variant(JSONB, 'postgresql'), default=list)
    status = db.Column(db.String(50), default='PENDING', nullable=False) # 'PENDING', 'VALIDATING', 'IMPORTING', 'COMPLETED', 'FAILED'
    error_details = db.Column(db.Text, nullable=True)
    started_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    completed_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user_name,
            'filename': self.filename,
            'file_size': self.file_size,
            'dataset_id': self.dataset_id,
            'dataset_name': self.dataset_name,
            'row_count': self.row_count,
            'column_count': self.column_count,
            'valid_rows': self.valid_rows,
            'invalid_rows': self.invalid_rows,
            'duplicate_rows': self.duplicate_rows,
            'new_columns': self.new_columns,
            'existing_columns': self.existing_columns,
            'status': self.status,
            'error_details': self.error_details,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }

import uuid
from datetime import datetime
from app.extensions import db

class LoginLog(db.Model):
    __tablename__ = 'login_logs'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"log_lgn_{uuid.uuid4().hex[:12]}")
    user_id = db.Column(db.String(64), nullable=True, index=True)
    email = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=True)
    ip_address = db.Column(db.String(64), nullable=True)
    user_agent = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), nullable=False) # 'SUCCESS', 'FAILED'
    failure_reason = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'email': self.email,
            'role': self.role,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'status': self.status,
            'failure_reason': self.failure_reason,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

import uuid
from datetime import datetime
from app.extensions import db

class Dataset(db.Model):
    __tablename__ = 'datasets'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"ds_{uuid.uuid4().hex[:12]}")
    name = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    uploaded_by_id = db.Column(db.String(64), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    uploaded_by_name = db.Column(db.String(200), nullable=False)
    row_count = db.Column(db.Integer, default=0, nullable=False)
    column_count = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(50), default='READY', nullable=False) # 'READY', 'PROCESSING', 'FAILED'
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    columns = db.relationship('DatasetColumn', backref='dataset', cascade='all, delete-orphan', lazy=True)
    records = db.relationship('DatasetRecord', backref='dataset', cascade='all, delete-orphan', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'original_filename': self.original_filename,
            'uploaded_by_id': self.uploaded_by_id,
            'uploaded_by_name': self.uploaded_by_name,
            'row_count': self.row_count,
            'column_count': self.column_count,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

import uuid
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSONB
from app.extensions import db

class DatasetRecord(db.Model):
    __tablename__ = 'dataset_records'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"rec_{uuid.uuid4().hex[:12]}")
    dataset_id = db.Column(db.String(64), db.ForeignKey('datasets.id', ondelete='CASCADE'), nullable=False, index=True)

    # Core indexed columns for fast server-side query execution
    name = db.Column(db.String(255), nullable=True, index=True)
    email = db.Column(db.String(255), nullable=True, index=True)
    country = db.Column(db.String(100), nullable=False, index=True)
    state = db.Column(db.String(100), nullable=True, index=True)
    city = db.Column(db.String(100), nullable=True, index=True)
    company = db.Column(db.String(255), nullable=True, index=True)
    phone = db.Column(db.String(100), nullable=True)
    job_title = db.Column(db.String(200), nullable=True)

    # Dynamic JSON/JSONB column supporting arbitrary CSV columns without schema alterations
    dynamic_data = db.Column(db.JSON().with_variant(JSONB, 'postgresql'), default=dict, nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        base = {
            'id': self.id,
            'dataset_id': self.dataset_id,
            'name': self.name,
            'email': self.email,
            'country': self.country,
            'state': self.state,
            'city': self.city,
            'company': self.company,
            'phone': self.phone,
            'job_title': self.job_title,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }
        if self.dynamic_data and isinstance(self.dynamic_data, dict):
            base.update(self.dynamic_data)
        return base

import uuid
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSONB
from app.extensions import db

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"adt_{uuid.uuid4().hex[:12]}")
    user_id = db.Column(db.String(64), nullable=True, index=True)
    user_name = db.Column(db.String(200), nullable=False)
    user_role = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(100), nullable=False, index=True)
    entity_type = db.Column(db.String(100), nullable=False)
    entity_id = db.Column(db.String(64), nullable=True)
    details = db.Column(db.JSON().with_variant(JSONB, 'postgresql'), default=dict)
    ip_address = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user_name,
            'user_role': self.user_role,
            'action': self.action,
            'entity_type': self.entity_type,
            'entity_id': self.entity_id,
            'details': self.details,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

import uuid
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSONB
from app.extensions import db

class DownloadJob(db.Model):
    __tablename__ = 'download_jobs'

    id = db.Column(db.String(64), primary_key=True, default=lambda: f"job_exp_{uuid.uuid4().hex[:12]}")
    user_id = db.Column(db.String(64), nullable=False, index=True)
    user_name = db.Column(db.String(200), nullable=False)
    dataset_id = db.Column(db.String(64), nullable=True)
    dataset_name = db.Column(db.String(255), nullable=False)
    format = db.Column(db.String(20), nullable=False) # 'CSV', 'EXCEL'
    filters_json = db.Column(db.JSON().with_variant(JSONB, 'postgresql'), default=dict)
    record_count = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(50), default='QUEUED', nullable=False) # 'QUEUED', 'PROCESSING', 'COMPLETED', 'FAILED'
    file_path = db.Column(db.String(500), nullable=True)
    error_message = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(64), nullable=True)
    started_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    completed_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user_name,
            'dataset_id': self.dataset_id,
            'dataset_name': self.dataset_name,
            'format': self.format,
            'filters_json': self.filters_json,
            'record_count': self.record_count,
            'status': self.status,
            'error_message': self.error_message,
            'ip_address': self.ip_address,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
        }

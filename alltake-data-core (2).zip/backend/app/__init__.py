from flask import Flask
from app.config import Config
from app.extensions import db, migrate, cors

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Init extensions
    db.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config['CORS_ORIGINS']}})

    # Register Blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.users import users_bp
    from app.routes.data import data_bp
    from app.routes.uploads import uploads_bp
    from app.routes.exports import exports_bp
    from app.routes.logs import logs_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(data_bp)
    app.register_blueprint(uploads_bp)
    app.register_blueprint(exports_bp)
    app.register_blueprint(logs_bp)

    @app.route('/api/health')
    def health_check():
        db_status = 'disconnected'
        overall_status = 'unhealthy'
        status_code = 503
        try:
            # Real database query check
            db.session.execute(db.text('SELECT 1'))
            db_status = 'connected'
            overall_status = 'healthy'
            status_code = 200
        except Exception:
            db_status = 'disconnected'
            overall_status = 'unhealthy'
            status_code = 503

        return {
            'status': overall_status,
            'app': 'Alltake Data Management System',
            'database': db_status
        }, status_code

    return app

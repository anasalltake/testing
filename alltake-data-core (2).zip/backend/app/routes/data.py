import math
from flask import Blueprint, request, jsonify
from sqlalchemy import func
from app.extensions import db
from app.models.dataset import Dataset
from app.models.dataset_column import DatasetColumn
from app.models.dataset_record import DatasetRecord
from app.auth.decorators import auth_required

data_bp = Blueprint('data', __name__, url_prefix='/api/data')
data_bp.before_request(auth_required(lambda: None))

@data_bp.route('', methods=['GET'])
def get_data():
    page = max(1, int(request.args.get('page', 1)))
    limit = min(500, max(10, int(request.args.get('limit', 50))))
    search = request.args.get('search', '').strip()
    country = request.args.get('country', '').strip()
    state = request.args.get('state', '').strip()
    city = request.args.get('city', '').strip()
    company = request.args.get('company', '').strip()
    dataset_id = request.args.get('dataset_id', '').strip()
    sort_by = request.args.get('sort', 'created_at')
    order = request.args.get('order', 'desc').lower()

    query = DatasetRecord.query

    if dataset_id:
        query = query.filter(DatasetRecord.dataset_id == dataset_id)
    if country:
        query = query.filter(DatasetRecord.country.ilike(country))
    if state:
        query = query.filter(DatasetRecord.state.ilike(state))
    if city:
        query = query.filter(DatasetRecord.city.ilike(city))
    if company:
        query = query.filter(DatasetRecord.company.ilike(f"%{company}%"))
    if search:
        term = f"%{search}%"
        query = query.filter(
            (DatasetRecord.name.ilike(term)) |
            (DatasetRecord.email.ilike(term)) |
            (DatasetRecord.company.ilike(term)) |
            (DatasetRecord.job_title.ilike(term)) |
            (DatasetRecord.phone.ilike(term))
        )

    # Sort
    sort_column = getattr(DatasetRecord, sort_by, DatasetRecord.created_at)
    if order == 'asc':
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    total = query.count()
    records = query.offset((page - 1) * limit).limit(limit).all()

    return jsonify({
        'success': True,
        'data': [r.to_dict() for r in records],
        'page': page,
        'limit': limit,
        'total': total,
        'total_pages': math.ceil(total / limit)
    })

@data_bp.route('/count', methods=['GET'])
def get_data_count():
    country = request.args.get('country', '').strip()
    state = request.args.get('state', '').strip()
    company = request.args.get('company', '').strip()
    search = request.args.get('search', '').strip()
    dataset_id = request.args.get('dataset_id', '').strip()

    query = DatasetRecord.query
    if dataset_id:
        query = query.filter(DatasetRecord.dataset_id == dataset_id)
    if country:
        query = query.filter(DatasetRecord.country.ilike(country))
    if state:
        query = query.filter(DatasetRecord.state.ilike(state))
    if company:
        query = query.filter(DatasetRecord.company.ilike(f"%{company}%"))
    if search:
        term = f"%{search}%"
        query = query.filter(
            (DatasetRecord.name.ilike(term)) | (DatasetRecord.email.ilike(term)) | (DatasetRecord.company.ilike(term))
        )

    return jsonify({'success': True, 'count': query.count()})

@data_bp.route('/countries', methods=['GET'])
def get_countries():
    dataset_id = request.args.get('dataset_id')
    query = db.session.query(
        DatasetRecord.country, func.count(DatasetRecord.id).label('leads')
    ).filter(DatasetRecord.country != None, DatasetRecord.country != '')

    if dataset_id:
        query = query.filter(DatasetRecord.dataset_id == dataset_id)

    countries = query.group_by(DatasetRecord.country).order_by(func.count(DatasetRecord.id).desc()).all()
    return jsonify({
        'success': True,
        'countries': [{'country': c[0], 'leads': c[1]} for c in countries]
    })

@data_bp.route('/facets', methods=['GET'])
def get_facets():
    countries = [r[0] for r in db.session.query(DatasetRecord.country).distinct().order_by(DatasetRecord.country.asc()).all() if r[0]]
    states = [r[0] for r in db.session.query(DatasetRecord.state).distinct().order_by(DatasetRecord.state.asc()).limit(100).all() if r[0]]
    datasets = [{'id': d.id, 'name': d.name} for d in Dataset.query.filter_by(status='READY').order_by(Dataset.name.asc()).all()]

    return jsonify({
        'success': True,
        'countries': countries,
        'states': states,
        'datasets': datasets
    })

@data_bp.route('/columns', methods=['GET'])
def get_columns():
    dataset_id = request.args.get('dataset_id')
    query = DatasetColumn.query
    if dataset_id:
        query = query.filter_by(dataset_id=dataset_id)

    columns = query.order_by(DatasetColumn.is_core.desc(), DatasetColumn.column_name.asc()).all()
    # Unique by column_name
    seen = set()
    result = []
    for c in columns:
        if c.column_name not in seen:
            seen.add(c.column_name)
            result.append(c.to_dict())

    return jsonify({'success': True, 'columns': result})

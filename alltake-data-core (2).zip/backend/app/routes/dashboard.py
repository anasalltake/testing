from flask import Blueprint, jsonify, g
from sqlalchemy import func
from app.extensions import db
from app.models.dataset import Dataset
from app.models.dataset_record import DatasetRecord
from app.models.upload_job import UploadJob
from app.models.download_job import DownloadJob
from app.models.user import User
from app.models.login_log import LoginLog
from app.models.audit_log import AuditLog
from app.auth.decorators import auth_required, roles_required

dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/api/dashboard')

@dashboard_bp.route('/admin', methods=['GET'])
@roles_required('ADMIN')
def admin_dashboard():
    total_records = DatasetRecord.query.count()
    total_countries = db.session.query(func.count(func.distinct(DatasetRecord.country))).scalar()
    total_employees = User.query.filter_by(role='EMPLOYEE').count()
    total_data_managers = User.query.filter_by(role='DATA_MANAGER').count()
    total_uploads = UploadJob.query.count()
    total_downloads = DownloadJob.query.count()
    active_users = User.query.filter_by(status='ACTIVE').count()
    total_datasets = Dataset.query.count()

    country_dist = db.session.query(
        DatasetRecord.country, func.count(DatasetRecord.id).label('count')
    ).group_by(DatasetRecord.country).order_by(func.count(DatasetRecord.id).desc()).limit(10).all()

    recent_uploads = [u.to_dict() for u in UploadJob.query.order_by(UploadJob.started_at.desc()).limit(5).all()]
    recent_downloads = [d.to_dict() for d in DownloadJob.query.order_by(DownloadJob.started_at.desc()).limit(5).all()]
    recent_logins = [l.to_dict() for l in LoginLog.query.order_by(LoginLog.created_at.desc()).limit(5).all()]
    recent_audits = [a.to_dict() for a in AuditLog.query.order_by(AuditLog.created_at.desc()).limit(6).all()]

    return jsonify({
        'success': True,
        'stats': {
            'totalRecords': total_records,
            'totalCountries': total_countries,
            'totalEmployees': total_employees,
            'totalDataManagers': total_data_managers,
            'totalUploads': total_uploads,
            'totalDownloads': total_downloads,
            'activeUsers': active_users,
            'totalDatasets': total_datasets
        },
        'countryDistribution': [{'country': c[0], 'count': c[1]} for c in country_dist],
        'recentUploads': recent_uploads,
        'recentDownloads': recent_downloads,
        'recentLogins': recent_logins,
        'recentAudits': recent_audits
    })

@dashboard_bp.route('/employee', methods=['GET'])
@auth_required
def employee_dashboard():
    total_records = DatasetRecord.query.count()
    total_countries = db.session.query(func.count(func.distinct(DatasetRecord.country))).scalar()

    country_stats = db.session.query(
        DatasetRecord.country, func.count(DatasetRecord.id).label('leads')
    ).group_by(DatasetRecord.country).order_by(func.count(DatasetRecord.id).desc()).all()

    available_datasets = [d.to_dict() for d in Dataset.query.filter_by(status='READY').order_by(Dataset.created_at.desc()).all()]
    my_downloads = [d.to_dict() for d in DownloadJob.query.filter_by(user_id=g.current_user.id).order_by(DownloadJob.started_at.desc()).limit(5).all()]

    return jsonify({
        'success': True,
        'stats': {
            'totalRecords': total_records,
            'totalCountries': total_countries,
            'myDownloadsCount': len(my_downloads)
        },
        'countryStats': [{'country': c[0], 'leads': c[1]} for c in country_stats],
        'availableDatasets': available_datasets,
        'myDownloads': my_downloads
    })

@dashboard_bp.route('/data-manager', methods=['GET'])
@roles_required('DATA_MANAGER', 'ADMIN')
def data_manager_dashboard():
    total_datasets = Dataset.query.count()
    total_records = DatasetRecord.query.count()
    my_uploads = UploadJob.query.filter_by(user_id=g.current_user.id).count()
    total_uploads = UploadJob.query.count()

    recent_uploads = [u.to_dict() for u in UploadJob.query.order_by(UploadJob.started_at.desc()).limit(8).all()]
    dataset_list = [d.to_dict() for d in Dataset.query.order_by(Dataset.created_at.desc()).all()]

    return jsonify({
        'success': True,
        'stats': {
            'totalDatasets': total_datasets,
            'totalRecords': total_records,
            'myUploads': my_uploads,
            'totalUploads': total_uploads
        },
        'recentUploads': recent_uploads,
        'datasetList': dataset_list
    })

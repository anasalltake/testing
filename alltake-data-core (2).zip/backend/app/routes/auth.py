from flask import Blueprint, request, jsonify, g
from datetime import datetime
from app.extensions import db
from app.models.user import User
from app.models.login_log import LoginLog
from app.auth.jwt_handler import generate_access_token, revoke_token, revoke_all_tokens_for_user
from app.auth.decorators import auth_required
from app.services.audit_service import log_audit_event

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    identifier = data.get('identifier', '').strip()
    password = data.get('password', '')
    ip = request.remote_addr or '127.0.0.1'
    user_agent = request.headers.get('User-Agent', '')

    if not identifier or not password:
        return jsonify({'success': False, 'message': 'Email/Username and password required'}), 400

    user = User.query.filter(
        (User.email.ilike(identifier)) | (User.username.ilike(identifier))
    ).first()

    # If database is completely unseeded, bootstrap initial admin account with hashed password
    if not user:
        low_id = identifier.lower().strip()
        if low_id in ['admin@alltake.com', 'admin', 'anasalltake@gmail.com'] and User.query.count() == 0:
            user = User(
                email='admin@alltake.com',
                username='admin',
                full_name='Anas (Executive Super Administrator)',
                role='ADMIN',
                status='ACTIVE'
            )
            user.set_password(password if password else 'Admin@Alltake2026!')
            db.session.add(user)
            db.session.commit()
        else:
            log = LoginLog(email=identifier, ip_address=ip, user_agent=user_agent, status='FAILED', failure_reason='USER_NOT_FOUND')
            db.session.add(log)
            db.session.commit()
            return jsonify({'success': False, 'message': 'Invalid credentials provided', 'error_code': 'AUTH_INVALID'}), 401

    if user.status != 'ACTIVE':
        log = LoginLog(user_id=user.id, email=user.email, role=user.role, ip_address=ip, user_agent=user_agent, status='FAILED', failure_reason='ACCOUNT_DISABLED')
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': False, 'message': 'Account is disabled or locked by Administrator', 'error_code': 'ACCOUNT_DISABLED'}), 403

    # Strictly verify cryptographic bcrypt hash (NO hardcoded password bypasses)
    if not user.check_password(password):
        log = LoginLog(user_id=user.id, email=user.email, role=user.role, ip_address=ip, user_agent=user_agent, status='FAILED', failure_reason='INVALID_PASSWORD')
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': False, 'message': 'Invalid credentials provided', 'error_code': 'AUTH_INVALID'}), 401

    user.last_login_at = datetime.utcnow()
    log = LoginLog(user_id=user.id, email=user.email, role=user.role, ip_address=ip, user_agent=user_agent, status='SUCCESS')
    db.session.add(log)
    db.session.commit()

    token = generate_access_token(user)
    log_audit_event(user, 'LOGIN', 'USER', user.id, {'method': 'PASSWORD'}, ip)

    return jsonify({
        'success': True,
        'token': token,
        'user': user.to_dict()
    })

@auth_bp.route('/logout', methods=['POST'])
@auth_required
def logout():
    payload = getattr(g, 'current_token_payload', None)
    if payload and 'jti' in payload:
        revoke_token(payload['jti'])
    user_name = g.current_user.full_name or g.current_user.username
    log_audit_event(g.current_user, 'LOGOUT', 'USER', g.current_user.id)
    return jsonify({
        'success': True,
        'message': f'Thank you, {user_name}! You have been securely logged out.',
        'user_name': user_name
    })

@auth_bp.route('/me', methods=['GET'])
@auth_required
def get_me():
    return jsonify({'success': True, 'user': g.current_user.to_dict()})

@auth_bp.route('/change-password', methods=['POST'])
@auth_required
def change_password():
    # Strict RBAC: Only Administrators can reset/change employee passwords. Employees cannot change their own passwords.
    if g.current_user.role == 'EMPLOYEE':
        return jsonify({
            'success': False,
            'message': 'Access Denied: Employees cannot change passwords. Only an Administrator can reset employee passwords.'
        }), 403

    data = request.get_json() or {}
    current_pwd = data.get('current_password', '')
    new_pwd = data.get('new_password', '')

    if not current_pwd or not new_pwd:
        return jsonify({'success': False, 'message': 'Current and new password required'}), 400

    if len(new_pwd) < 8:
        return jsonify({'success': False, 'message': 'Password must be at least 8 characters'}), 400

    if not g.current_user.check_password(current_pwd):
        return jsonify({'success': False, 'message': 'Current password is incorrect'}), 400

    g.current_user.set_password(new_pwd)
    db.session.commit()
    revoke_all_tokens_for_user(g.current_user.id)
    log_audit_event(g.current_user, 'PASSWORD_CHANGED', 'USER', g.current_user.id)

    return jsonify({'success': True, 'message': 'Password changed successfully'})

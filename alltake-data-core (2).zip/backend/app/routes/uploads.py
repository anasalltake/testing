import os
import io
import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify, g, send_file, Response
from werkzeug.utils import secure_filename
from app.extensions import db
from app.models.dataset import Dataset
from app.models.upload_job import UploadJob
from app.auth.decorators import roles_required
from app.services.csv_processor import inspect_dataset_file, process_dataset_import
from app.services.audit_service import log_audit_event

uploads_bp = Blueprint('uploads', __name__, url_prefix='/api/uploads')

ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls', 'tsv', 'txt', 'json'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@uploads_bp.route('/preview', methods=['POST'])
@roles_required('DATA_MANAGER', 'ADMIN')
def preview_upload():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part in request'}), 400

    file = request.files['file']
    if not file or not file.filename:
        return jsonify({'success': False, 'message': 'No file selected for preview'}), 400

    if not allowed_file(file.filename):
        return jsonify({
            'success': False,
            'message': f'Unsupported file type. Permitted formats: {", ".join(sorted(ALLOWED_EXTENSIONS)).upper()}'
        }), 400

    dup_field = request.form.get('duplicate_strategy', 'email')
    file_bytes = file.read()

    try:
        summary = inspect_dataset_file(file_bytes, file.filename, duplicate_strategy=dup_field)
        preview_data = summary.pop('preview_data', [])
        return jsonify({
            'success': True,
            'summary': summary,
            'preview_data': preview_data
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'File parsing failed: {str(e)}'}), 400

@uploads_bp.route('/confirm', methods=['POST'])
@roles_required('DATA_MANAGER', 'ADMIN')
def confirm_upload():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'}), 400

    file = request.files['file']
    if not file or not file.filename:
        return jsonify({'success': False, 'message': 'No file selected'}), 400

    if not allowed_file(file.filename):
        return jsonify({
            'success': False,
            'message': f'Unsupported file type. Permitted formats: {", ".join(sorted(ALLOWED_EXTENSIONS)).upper()}'
        }), 400

    dataset_name = request.form.get('dataset_name', '').strip()
    if not dataset_name:
        dataset_name = f"Dataset_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"

    dup_strategy = request.form.get('duplicate_strategy', 'email')
    handle_dups = request.form.get('handle_duplicates', 'SKIP')
    import_mode = request.form.get('import_mode', 'APPEND').upper()

    file_bytes = file.read()
    dataset_id = request.form.get('dataset_id') or f"ds_{uuid.uuid4().hex[:12]}"
    job_id = f"job_upl_{uuid.uuid4().hex[:12]}"

    # Existing dataset or create new
    dataset = Dataset.query.get(dataset_id)
    if not dataset:
        dataset = Dataset(
            id=dataset_id,
            name=dataset_name,
            original_filename=secure_filename(file.filename),
            uploaded_by_id=g.current_user.id,
            uploaded_by_name=g.current_user.full_name,
            status='PROCESSING'
        )
        db.session.add(dataset)
    else:
        dataset.status = 'PROCESSING'

    job = UploadJob(
        id=job_id,
        user_id=g.current_user.id,
        user_name=g.current_user.full_name,
        filename=secure_filename(file.filename),
        file_size=len(file_bytes),
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        status='PENDING'
    )

    db.session.add(job)
    db.session.commit()

    try:
        # Perform Authoritative Database Ingestion
        stats = process_dataset_import(
            job_id=job_id,
            dataset_id=dataset_id,
            dataset_name=dataset_name,
            file_bytes=file_bytes,
            filename=file.filename,
            user=g.current_user,
            import_mode=import_mode,
            handle_duplicates=handle_dups,
            duplicate_strategy=dup_strategy
        )

        log_audit_event(g.current_user, 'DATASET_IMPORTED', 'DATASET', dataset_id, {
            'dataset_name': dataset_name,
            'filename': file.filename,
            'import_mode': import_mode,
            'valid_rows': stats['valid_rows'],
            'duplicate_rows': stats['duplicate_rows']
        })

        return jsonify({
            'success': True,
            'message': f"Import completed. {stats['valid_rows']:,} records saved, {stats['duplicate_rows']:,} duplicates handled, {stats['invalid_rows']:,} rows rejected. PostgreSQL verification completed.",
            'dataset_id': dataset_id,
            'job_id': job_id,
            'stats': stats
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'PostgreSQL database persistence failed: {str(e)}',
            'job_id': job_id
        }), 500

@uploads_bp.route('/jobs', methods=['GET'])
@roles_required('DATA_MANAGER', 'ADMIN')
def list_upload_jobs():
    query = UploadJob.query
    if g.current_user.role != 'ADMIN':
        query = query.filter_by(user_id=g.current_user.id)

    jobs = [j.to_dict() for j in query.order_by(UploadJob.started_at.desc()).limit(50).all()]
    return jsonify({'success': True, 'jobs': jobs})

@uploads_bp.route('/sample-template', methods=['GET'])
@uploads_bp.route('/sample-csv', methods=['GET'])
def download_sample_template():
    sample_csv = (
        "Upload Date,Lead Type,First Name,Last Name,Email Address,Email Status,Job Title,Job Level,Company Name,"
        "Address Link,Address Line 1,City,State,Postal Code,Country,Company Phone,Direct Number,Other Number,"
        "Employee Size,Industry Type,Revenue Size,Job Title URL,Company URL,Revenue Size Link,SIC Code,NAICS Code,"
        "SIC Code URL,NAICS Code URL,Comment 1,Comment 2,Domain\n"
        "2026-10-13,Executive Lead,Anas,Khan,anas@alltake.com,Verified,Chief Technology Officer,C-Level,Alltake Technologies,"
        "https://maps.google.com/?q=New+York,120 Broadway 28th Fl,New York,NY,10271,United States,+1-212-555-0190,+1-212-555-0191,"
        "+1-212-555-0192,51 to 200,Information Technology,$25M to $50M,https://alltake.com/team/anas,https://alltake.com,"
        "https://bloomberg.com/alltake,7371,541511,https://siccode.com/7371,https://naics.com/541511,Primary verified account,"
        "Enterprise Tier,alltake.com\n"
    )
    return Response(
        sample_csv,
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=alltake_standard_31_template.csv"}
    )

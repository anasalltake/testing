import os
import uuid
from flask import Blueprint, request, jsonify, g, send_file, current_app
from app.extensions import db
from app.models.download_job import DownloadJob
from app.auth.decorators import auth_required
from app.services.excel_exporter import generate_export_file
from app.services.audit_service import log_audit_event

exports_bp = Blueprint('exports', __name__, url_prefix='/api/exports')

@exports_bp.route('/create', methods=['POST'])
@auth_required
def create_export():
    data = request.get_json() or {}
    export_format = data.get('format', 'CSV').upper()
    filters = data.get('filters', {})
    dataset_name = data.get('dataset_name', 'Filtered Leads Export')

    if export_format not in ['CSV', 'EXCEL']:
        return jsonify({'success': False, 'message': 'Format must be CSV or EXCEL'}), 400

    job_id = f"job_exp_{uuid.uuid4().hex[:12]}"
    job = DownloadJob(
        id=job_id,
        user_id=g.current_user.id,
        user_name=g.current_user.full_name,
        dataset_name=dataset_name,
        format=export_format,
        filters_json=filters,
        status='QUEUED',
        ip_address=request.remote_addr
    )
    db.session.add(job)
    db.session.commit()

    log_audit_event(g.current_user, 'EXPORT_STARTED', 'DOWNLOAD', job_id, {'format': export_format, 'filters': filters})

    # Generate file (can be pushed to Celery in high-volume queue or executed directly)
    export_folder = current_app.config['EXPORT_FOLDER']
    generate_export_file(job_id, export_folder)

    return jsonify({
        'success': True,
        'message': 'Export job generated',
        'job_id': job_id
    })

@exports_bp.route('/jobs', methods=['GET'])
@auth_required
def list_export_jobs():
    query = DownloadJob.query
    if g.current_user.role != 'ADMIN':
        query = query.filter_by(user_id=g.current_user.id)

    jobs = [j.to_dict() for j in query.order_by(DownloadJob.started_at.desc()).limit(50).all()]
    return jsonify({'success': True, 'jobs': jobs})

@exports_bp.route('/<job_id>/download', methods=['GET'])
@auth_required
def download_file(job_id):
    job = DownloadJob.query.get_or_404(job_id)

    if g.current_user.role != 'ADMIN' and job.user_id != g.current_user.id:
        return jsonify({'success': False, 'message': 'Access forbidden'}), 403

    if job.status != 'COMPLETED' or not job.file_path or not os.path.exists(job.file_path):
        return jsonify({'success': False, 'message': 'File not ready or expired'}), 404

    log_audit_event(g.current_user, 'EXPORT_COMPLETED', 'DOWNLOAD', job.id, {'filename': os.path.basename(job.file_path)})

    return send_file(
        job.file_path,
        as_attachment=True,
        download_name=os.path.basename(job.file_path)
    )

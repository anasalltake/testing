import math
from flask import Blueprint, request, jsonify, g
from app.models.audit_log import AuditLog
from app.models.login_log import LoginLog
from app.models.download_job import DownloadJob
from app.models.upload_job import UploadJob
from app.auth.decorators import roles_required, auth_required

logs_bp = Blueprint('logs', __name__, url_prefix='/api/logs')

@logs_bp.route('/audit', methods=['GET'])
@roles_required('ADMIN')
def get_audit_logs():
    page = max(1, int(request.args.get('page', 1)))
    limit = min(200, int(request.args.get('limit', 50)))
    action = request.args.get('action')
    user = request.args.get('user')

    query = AuditLog.query
    if action and action != 'ALL':
        query = query.filter_by(action=action)
    if user:
        query = query.filter(AuditLog.user_name.ilike(f"%{user}%"))

    total = query.count()
    logs = [l.to_dict() for l in query.order_by(AuditLog.created_at.desc()).offset((page - 1) * limit).limit(limit).all()]

    return jsonify({
        'success': True,
        'logs': logs,
        'total': total,
        'page': page,
        'limit': limit,
        'total_pages': math.ceil(total / limit)
    })

@logs_bp.route('/logins', methods=['GET'])
@roles_required('ADMIN')
def get_login_logs():
    page = max(1, int(request.args.get('page', 1)))
    limit = min(200, int(request.args.get('limit', 50)))
    status = request.args.get('status')

    query = LoginLog.query
    if status and status != 'ALL':
        query = query.filter_by(status=status)

    total = query.count()
    logs = [l.to_dict() for l in query.order_by(LoginLog.created_at.desc()).offset((page - 1) * limit).limit(limit).all()]

    return jsonify({
        'success': True,
        'logs': logs,
        'total': total,
        'page': page,
        'limit': limit,
        'total_pages': math.ceil(total / limit)
    })

@logs_bp.route('/downloads', methods=['GET'])
@auth_required
def get_download_logs():
    query = DownloadJob.query
    if g.current_user.role != 'ADMIN':
        query = query.filter_by(user_id=g.current_user.id)

    logs = [d.to_dict() for d in query.order_by(DownloadJob.started_at.desc()).limit(100).all()]
    return jsonify({'success': True, 'logs': logs})

@logs_bp.route('/uploads', methods=['GET'])
@roles_required('ADMIN', 'DATA_MANAGER')
def get_upload_logs():
    query = UploadJob.query
    if g.current_user.role != 'ADMIN':
        query = query.filter_by(user_id=g.current_user.id)

    logs = [u.to_dict() for u in query.order_by(UploadJob.started_at.desc()).limit(100).all()]
    return jsonify({'success': True, 'logs': logs})

from flask import Blueprint, request, jsonify, g
from app.extensions import db
from app.models.user import User
from app.models.audit_log import AuditLog
from app.models.login_log import LoginLog
from app.models.download_job import DownloadJob
from app.auth.decorators import roles_required
from app.services.audit_service import log_audit_event

users_bp = Blueprint('users', __name__, url_prefix='/api/users')

@users_bp.route('', methods=['GET'])
@roles_required('ADMIN')
def list_users():
    role = request.args.get('role')
    status = request.args.get('status')
    search = request.args.get('search')

    query = User.query
    if role:
        query = query.filter_by(role=role)
    if status:
        query = query.filter_by(status=status)
    if search:
        term = f"%{search}%"
        query = query.filter(
            (User.email.ilike(term)) | (User.username.ilike(term)) | (User.full_name.ilike(term))
        )

    users = [u.to_dict() for u in query.order_by(User.created_at.desc()).all()]
    return jsonify({'success': True, 'users': users})

@users_bp.route('', methods=['POST'])
@roles_required('ADMIN')
def create_user():
    data = request.get_json() or {}
    email = data.get('email', '').strip()
    username = data.get('username', '').strip()
    full_name = data.get('full_name', '').strip()
    role = data.get('role', '').strip()
    temporary_password = data.get('temporary_password', '')

    if not email or not username or not full_name or not role or not temporary_password:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400

    if role not in ['EMPLOYEE', 'DATA_MANAGER']:
        return jsonify({'success': False, 'message': 'Admin can only create EMPLOYEE or DATA_MANAGER accounts'}), 400

    if User.query.filter((User.email.ilike(email)) | (User.username.ilike(username))).first():
        return jsonify({'success': False, 'message': 'User with this email or username already exists'}), 409

    new_user = User(email=email, username=username, full_name=full_name, role=role, status='ACTIVE')
    new_user.set_password(temporary_password)

    db.session.add(new_user)
    db.session.commit()

    log_audit_event(g.current_user, 'USER_CREATED', 'USER', new_user.id, {'email': email, 'role': role})
    return jsonify({'success': True, 'message': 'User created successfully', 'user': new_user.to_dict()}), 201

@users_bp.route('/<user_id>', methods=['PUT'])
@roles_required('ADMIN')
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json() or {}

    if 'full_name' in data:
        user.full_name = data['full_name'].strip()
    if 'role' in data and data['role'] in ['ADMIN', 'EMPLOYEE', 'DATA_MANAGER']:
        user.role = data['role']

    db.session.commit()
    log_audit_event(g.current_user, 'USER_UPDATED', 'USER', user.id, {'role': user.role})
    return jsonify({'success': True, 'message': 'User updated successfully'})

@users_bp.route('/<user_id>/status', methods=['PATCH'])
@roles_required('ADMIN')
def toggle_user_status(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json() or {}
    new_status = data.get('status')

    if new_status not in ['ACTIVE', 'DISABLED']:
        return jsonify({'success': False, 'message': 'Invalid status'}), 400

    if user.id == g.current_user.id:
        return jsonify({'success': False, 'message': 'Cannot disable own account'}), 400

    user.status = new_status
    db.session.commit()

    action = 'USER_ENABLED' if new_status == 'ACTIVE' else 'USER_DISABLED'
    log_audit_event(g.current_user, action, 'USER', user.id)
    return jsonify({'success': True, 'message': f'User {new_status.lower()}'})

from app.auth.jwt_handler import revoke_all_tokens_for_user

@users_bp.route('/<user_id>/reset-password', methods=['POST'])
@roles_required('ADMIN')
def reset_password(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json() or {}
    new_password = data.get('new_password') or data.get('newPassword')

    if not new_password or len(new_password) < 8:
        return jsonify({'success': False, 'message': 'New password must be at least 8 characters'}), 400

    user.set_password(new_password)
    db.session.commit()
    # Invalidate all existing sessions and tokens for this user immediately
    revoke_all_tokens_for_user(user.id)
    log_audit_event(g.current_user, 'PASSWORD_CHANGED', 'USER', user.id, {'reset_by_admin': True})
    return jsonify({
        'success': True,
        'message': f'Password successfully updated for {user.full_name or user.username}. All previous sessions have been invalidated.',
        'user_id': user.id,
        'username': user.username
    })

@users_bp.route('/<user_id>/activity', methods=['GET'])
@roles_required('ADMIN')
def user_activity(user_id):
    user = User.query.get_or_404(user_id)
    audits = [a.to_dict() for a in AuditLog.query.filter_by(user_id=user_id).order_by(AuditLog.created_at.desc()).limit(20).all()]
    logins = [l.to_dict() for l in LoginLog.query.filter_by(user_id=user_id).order_by(LoginLog.created_at.desc()).limit(10).all()]
    downloads = [d.to_dict() for d in DownloadJob.query.filter_by(user_id=user_id).order_by(DownloadJob.started_at.desc()).limit(10).all()]

    return jsonify({
        'success': True,
        'user': user.to_dict(),
        'audits': audits,
        'logins': logins,
        'downloads': downloads
    })

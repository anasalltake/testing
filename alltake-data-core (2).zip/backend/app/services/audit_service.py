from datetime import datetime
from flask import request
from app.extensions import db
from app.models.audit_log import AuditLog

def log_audit_event(user, action: str, entity_type: str, entity_id: str = None, details: dict = None, ip: str = None):
    try:
        client_ip = ip or request.remote_addr or '127.0.0.1'
        log = AuditLog(
            user_id=user.id if user else None,
            user_name=user.full_name if user else 'System',
            user_role=user.role if user else 'SYSTEM',
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details or {},
            ip_address=client_ip,
            created_at=datetime.utcnow()
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[Audit Error] Failed to log event: {e}")

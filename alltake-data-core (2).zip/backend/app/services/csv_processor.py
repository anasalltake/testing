import io
import json
import csv
import hashlib
import pandas as pd
from datetime import datetime
from app.extensions import db
from app.models.dataset import Dataset
from app.models.dataset_column import DatasetColumn
from app.models.dataset_record import DatasetRecord
from app.models.upload_job import UploadJob

CORE_FIELDS = {
    'name', 'email', 'country', 'state', 'city', 'company', 'phone', 'job_title',
    'first_name', 'last_name', 'email_address', 'company_name', 'company_phone',
    'direct_number', 'other_number', 'employee_size', 'industry_type', 'revenue_size',
    'domain', 'sic_code', 'naics_code', 'postal_code', 'address_line1', 'job_level'
}

ALIAS_MAP = {
    'firstname': 'first_name',
    'fname': 'first_name',
    'first_name': 'first_name',
    'lastname': 'last_name',
    'lname': 'last_name',
    'last_name': 'last_name',
    'email': 'email',
    'emailaddress': 'email',
    'email_address': 'email',
    'business_email': 'email',
    'company': 'company',
    'companyname': 'company',
    'company_name': 'company',
    'organization': 'company',
    'org': 'company',
    'phone': 'phone',
    'companyphone': 'phone',
    'company_phone': 'phone',
    'telephone': 'phone',
    'directnumber': 'direct_number',
    'direct_number': 'direct_number',
    'mobile': 'direct_number',
    'country': 'country',
    'nation': 'country',
    'state': 'state',
    'province': 'state',
    'city': 'city',
    'postalcode': 'postal_code',
    'postal_code': 'postal_code',
    'zipcode': 'postal_code',
    'zip': 'postal_code',
    'jobtitle': 'job_title',
    'job_title': 'job_title',
    'title': 'job_title',
    'designation': 'job_title',
    'joblevel': 'job_level',
    'job_level': 'job_level',
    'employeesize': 'employee_size',
    'employee_size': 'employee_size',
    'headcount': 'employee_size',
    'industrytype': 'industry_type',
    'industry_type': 'industry_type',
    'industry': 'industry_type',
    'revenuesize': 'revenue_size',
    'revenue_size': 'revenue_size',
    'revenue': 'revenue_size',
    'domain': 'domain',
    'companyurl': 'domain',
    'website': 'domain',
}

def normalize_column_name(col: str) -> str:
    cleaned = "".join(c if c.isalnum() else "_" for c in str(col).strip().lower()).strip("_")
    return ALIAS_MAP.get(cleaned, cleaned)

def compute_row_hash(row_dict: dict) -> str:
    """
    Computes a deterministic hash of business fields for full-row duplicate detection.
    Excludes volatile/system keys.
    """
    excluded = {'id', 'dataset_id', 'created_at', 'upload_date', 'comment1', 'comment2'}
    canonical = {k: str(v).strip().lower() for k, v in row_dict.items() if k not in excluded and v}
    serialized = json.dumps(canonical, sort_keys=True)
    return hashlib.sha256(serialized.encode('utf-8')).hexdigest()

def load_dataframe_from_bytes(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """
    Robust multi-format parser supporting CSV, XLSX, XLS, TSV, TXT, and JSON.
    Preserves text precision, leading zeros, and postal codes as strings.
    """
    ext = filename.split('.')[-1].lower() if '.' in filename else 'csv'

    if ext in ['xlsx', 'xls']:
        return pd.read_excel(io.BytesIO(file_bytes), dtype=str).fillna('')

    elif ext == 'json':
        text = file_bytes.decode('utf-8', errors='ignore')
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            # Check if dict wrapped under 'data' or 'records' or 'leads'
            for key in ['data', 'records', 'leads', 'items']:
                if key in parsed and isinstance(parsed[key], list):
                    parsed = parsed[key]
                    break
            else:
                parsed = [parsed]
        elif not isinstance(parsed, list):
            parsed = [parsed]
        return pd.DataFrame(parsed, dtype=str).fillna('')

    else:
        # CSV, TSV, TXT
        # Detect delimiter from first few bytes
        sample_text = file_bytes[:8192].decode('utf-8', errors='ignore')
        sep = ','
        if ext == 'tsv':
            sep = '\t'
        else:
            try:
                dialect = csv.Sniffer().sniff(sample_text)
                sep = dialect.delimiter
            except Exception:
                if '\t' in sample_text and ',' not in sample_text:
                    sep = '\t'
                elif '|' in sample_text and ',' not in sample_text:
                    sep = '|'
                elif ';' in sample_text and ',' not in sample_text:
                    sep = ';'

        return pd.read_csv(io.BytesIO(file_bytes), sep=sep, dtype=str, on_bad_lines='skip').fillna('')

def inspect_dataset_file(file_bytes: bytes, filename: str, duplicate_strategy='email'):
    """
    Inspects file contents: detects headers, checks schema compatibility,
    and calculates expected duplicate and valid counts.
    """
    df = load_dataframe_from_bytes(file_bytes, filename)
    headers = [str(c).strip() for c in df.columns]
    normalized_headers = [normalize_column_name(h) for h in headers]

    # Existing columns in database
    existing_db_cols = {c.column_name for c in DatasetColumn.query.with_entities(DatasetColumn.column_name).distinct()}
    known_cols = CORE_FIELDS.union(existing_db_cols)

    new_cols = []
    existing_cols = []
    for h, norm in zip(headers, normalized_headers):
        if norm in known_cols:
            existing_cols.append(h)
        else:
            new_cols.append(h)

    total_rows = len(df)

    # Calculate duplicates based on strategy
    duplicate_rows = 0
    if duplicate_strategy == 'full_row':
        hashes = [compute_row_hash({normalize_column_name(k): str(v).strip() for k, v in row.items()}) for _, row in df.iterrows()]
        seen = set()
        for h in hashes:
            if h in seen:
                duplicate_rows += 1
            else:
                seen.add(h)
    else:
        dup_target = 'email' if duplicate_strategy == 'email' else 'phone'
        matched_col = None
        for h, norm in zip(headers, normalized_headers):
            if norm == dup_target:
                matched_col = h
                break

        if matched_col:
            duplicate_rows = int(df.duplicated(subset=[matched_col]).sum())

    valid_rows = max(0, total_rows - duplicate_rows)
    preview_rows = df.head(10).to_dict(orient='records')

    return {
        'total_rows': total_rows,
        'valid_rows': valid_rows,
        'duplicate_rows': duplicate_rows,
        'invalid_rows': 0,
        'detected_headers': headers,
        'new_columns': new_cols,
        'existing_columns': existing_cols,
        'preview_data': preview_rows,
        'filename': filename,
        'filesize': len(file_bytes),
    }

# Backward compatibility alias
inspect_csv = lambda stream, duplicate_field='email': inspect_dataset_file(
    stream.getvalue().encode('utf-8') if hasattr(stream, 'getvalue') else stream.read().encode('utf-8'),
    'uploaded.csv',
    duplicate_field
)

def process_dataset_import(
    job_id: str,
    dataset_id: str,
    dataset_name: str,
    file_bytes: bytes,
    filename: str,
    user,
    import_mode: str = 'APPEND',
    handle_duplicates: str = 'SKIP',
    duplicate_strategy: str = 'email'
):
    """
    Authoritative transactional batch import into PostgreSQL.
    Supports APPEND (default), UPDATE, and REPLACE modes with configurable duplicate handling.
    """
    job = UploadJob.query.get(job_id)
    if not job:
        return

    job.status = 'IMPORTING'
    db.session.commit()

    try:
        df = load_dataframe_from_bytes(file_bytes, filename)
        headers = [str(c).strip() for c in df.columns]

        # Handle REPLACE mode: Purge existing records for dataset
        if import_mode == 'REPLACE':
            DatasetRecord.query.filter_by(dataset_id=dataset_id).delete()
            db.session.commit()

        # Pre-seed existing duplicate check keys from PostgreSQL
        existing_keys = set()
        if duplicate_strategy == 'email':
            rows = db.session.query(DatasetRecord.email).filter(DatasetRecord.email.isnot(None), DatasetRecord.email != '').all()
            existing_keys = {r[0].strip().lower() for r in rows if r[0]}
        elif duplicate_strategy == 'phone':
            rows = db.session.query(DatasetRecord.phone).filter(DatasetRecord.phone.isnot(None), DatasetRecord.phone != '').all()
            existing_keys = {"".join(filter(str.isdigit, str(r[0]))) for r in rows if r[0]}

        # Register dynamic columns in PostgreSQL
        existing_dataset_cols = {c.column_name for c in DatasetColumn.query.filter_by(dataset_id=dataset_id).all()}
        for h in headers:
            norm = normalize_column_name(h)
            if norm not in existing_dataset_cols:
                is_core = norm in CORE_FIELDS
                col_record = DatasetColumn(
                    dataset_id=dataset_id,
                    column_name=norm,
                    display_name=h,
                    data_type='string',
                    is_core=is_core
                )
                db.session.add(col_record)
                existing_dataset_cols.add(norm)
        db.session.commit()

        # Batch insertion
        batch_size = 2000
        records_to_insert = []
        total_valid = 0
        total_invalid = 0
        total_duplicates = 0
        total_updated = 0
        seen_in_batch = set()

        for _, row in df.iterrows():
            row_dict = {normalize_column_name(k): str(v).strip() for k, v in row.items()}

            first_name = row_dict.get('first_name', '')
            last_name = row_dict.get('last_name', '')
            name = row_dict.get('name') or f"{first_name} {last_name}".strip() or row_dict.get('full_name', '')
            email = row_dict.get('email', '')
            country = row_dict.get('country') or 'United States'
            state = row_dict.get('state', '')
            city = row_dict.get('city', '')
            company = row_dict.get('company', '')
            phone = row_dict.get('phone') or row_dict.get('direct_number', '')
            job_title = row_dict.get('job_title', '')

            # Empty row check
            if not name and not email and not company and not phone:
                total_invalid += 1
                continue

            # Duplicate Evaluation
            is_dup = False
            dup_key = ''
            if duplicate_strategy == 'email':
                dup_key = email.strip().lower()
                if dup_key:
                    is_dup = (dup_key in existing_keys) or (dup_key in seen_in_batch)
            elif duplicate_strategy == 'phone':
                dup_key = "".join(filter(str.isdigit, phone))
                if dup_key:
                    is_dup = (dup_key in existing_keys) or (dup_key in seen_in_batch)
            elif duplicate_strategy == 'full_row':
                dup_key = compute_row_hash(row_dict)
                is_dup = (dup_key in seen_in_batch)

            if is_dup:
                total_duplicates += 1
                if handle_duplicates == 'SKIP':
                    continue
                elif handle_duplicates == 'UPDATE' and duplicate_strategy == 'email' and email:
                    # Update existing record matching email
                    existing_rec = DatasetRecord.query.filter(DatasetRecord.email.ilike(email)).first()
                    if existing_rec:
                        if name: existing_rec.name = name
                        if company: existing_rec.company = company
                        if phone: existing_rec.phone = phone
                        if job_title: existing_rec.job_title = job_title
                        if country: existing_rec.country = country
                        dynamic_cols = {k: v for k, v in row_dict.items() if k not in CORE_FIELDS}
                        existing_rec.dynamic_data = dynamic_cols
                        total_updated += 1
                        continue

            if dup_key:
                seen_in_batch.add(dup_key)
                existing_keys.add(dup_key)

            # Dynamic fields stored in native JSONB
            dynamic_cols = {k: v for k, v in row_dict.items() if k not in CORE_FIELDS}

            rec = DatasetRecord(
                dataset_id=dataset_id,
                name=name,
                email=email,
                country=country,
                state=state,
                city=city,
                company=company,
                phone=phone,
                job_title=job_title,
                dynamic_data=dynamic_cols,
                created_at=datetime.utcnow()
            )
            records_to_insert.append(rec)

            if len(records_to_insert) >= batch_size:
                db.session.bulk_save_objects(records_to_insert)
                db.session.commit()
                total_valid += len(records_to_insert)
                records_to_insert = []

        if records_to_insert:
            db.session.bulk_save_objects(records_to_insert)
            db.session.commit()
            total_valid += len(records_to_insert)

        # Update UploadJob metrics
        job.status = 'COMPLETED'
        job.valid_rows = total_valid
        job.invalid_rows = total_invalid
        job.duplicate_rows = total_duplicates
        job.completed_at = datetime.utcnow()

        # Update Dataset row count reflecting ACCUMULATED database records
        dataset = Dataset.query.get(dataset_id)
        if dataset:
            accumulated_count = DatasetRecord.query.filter_by(dataset_id=dataset_id).count()
            dataset.status = 'READY'
            dataset.row_count = accumulated_count
            dataset.column_count = DatasetColumn.query.filter_by(dataset_id=dataset_id).count()

        db.session.commit()

        return {
            'total_rows': len(df),
            'valid_rows': total_valid,
            'duplicate_rows': total_duplicates,
            'invalid_rows': total_invalid,
            'updated_rows': total_updated,
            'total_dataset_records': dataset.row_count if dataset else total_valid
        }

    except Exception as e:
        db.session.rollback()
        job = UploadJob.query.get(job_id)
        if job:
            job.status = 'FAILED'
            job.error_details = str(e)
            job.completed_at = datetime.utcnow()
            db.session.commit()
        print(f"[Import Error] Job {job_id} failed: {e}")
        raise e

# Backward compatibility alias
process_csv_import = lambda job_id, dataset_id, dataset_name, file_bytes, user, handle_duplicates='SKIP', duplicate_field='email': process_dataset_import(
    job_id=job_id,
    dataset_id=dataset_id,
    dataset_name=dataset_name,
    file_bytes=file_bytes,
    filename='uploaded.csv',
    user=user,
    import_mode='APPEND',
    handle_duplicates=handle_duplicates,
    duplicate_strategy=duplicate_field
)

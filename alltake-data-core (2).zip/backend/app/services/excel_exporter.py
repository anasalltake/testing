import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime
from app.extensions import db
from app.models.dataset_record import DatasetRecord
from app.models.download_job import DownloadJob

def sanitize_cell_value(val):
    if val is None:
        return ""
    val_str = str(val)
    # OWASP CSV Formula Injection defense:
    # If cell begins with =, +, -, @, \t, \r, prepend a single quote to prevent DDE/formula execution
    if val_str and val_str[0] in ('=', '+', '-', '@', '\t', '\r'):
        return "'" + val_str
    return val_str

def generate_export_file(job_id, export_folder):
    """
    Background worker function to generate filtered CSV or Excel files with
    OWASP CSV formula injection defense and memory-efficient batch processing.
    """
    job = DownloadJob.query.get(job_id)
    if not job:
        return

    try:
        job.status = 'PROCESSING'
        db.session.commit()

        # Build query according to filters_json
        query = DatasetRecord.query
        filters = job.filters_json or {}

        if filters.get('dataset_id'):
            query = query.filter(DatasetRecord.dataset_id == filters['dataset_id'])
        if filters.get('country'):
            query = query.filter(DatasetRecord.country.ilike(filters['country']))
        if filters.get('state'):
            query = query.filter(DatasetRecord.state.ilike(filters['state']))
        if filters.get('company'):
            query = query.filter(DatasetRecord.company.ilike(f"%{filters['company']}%"))
        if filters.get('search'):
            term = f"%{filters['search']}%"
            query = query.filter(
                (DatasetRecord.name.ilike(term)) |
                (DatasetRecord.email.ilike(term)) |
                (DatasetRecord.company.ilike(term))
            )

        os.makedirs(export_folder, exist_ok=True)
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        headers = ['Name', 'Email', 'Country', 'State', 'City', 'Company', 'Phone', 'Job Title']

        # Chunked stream processing to prevent memory spikes on massive exports
        records_query = query.order_by(DatasetRecord.created_at.desc()).yield_per(1000)
        total_exported = 0

        if job.format == 'CSV':
            filename = f"alltake_leads_{timestamp}.csv"
            filepath = os.path.join(export_folder, filename)

            import csv
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(headers)
                for r in records_query:
                    writer.writerow([
                        sanitize_cell_value(r.name),
                        sanitize_cell_value(r.email),
                        sanitize_cell_value(r.country),
                        sanitize_cell_value(r.state),
                        sanitize_cell_value(r.city),
                        sanitize_cell_value(r.company),
                        sanitize_cell_value(r.phone),
                        sanitize_cell_value(r.job_title),
                    ])
                    total_exported += 1

        else: # EXCEL
            filename = f"alltake_leads_{timestamp}.xlsx"
            filepath = os.path.join(export_folder, filename)

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Alltake Leads"
            ws.append(headers)

            # Header styling
            header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")

            # Max worksheet limit check
            max_limit = 1048500
            for r in records_query:
                if total_exported >= max_limit:
                    break
                ws.append([
                    sanitize_cell_value(r.name),
                    sanitize_cell_value(r.email),
                    sanitize_cell_value(r.country),
                    sanitize_cell_value(r.state),
                    sanitize_cell_value(r.city),
                    sanitize_cell_value(r.company),
                    sanitize_cell_value(r.phone),
                    sanitize_cell_value(r.job_title),
                ])
                total_exported += 1

            # Auto fit width
            for col in ws.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = col[0].column_letter
                ws.column_dimensions[col_letter].width = max(max_len + 3, 14)

            wb.save(filepath)

        job.status = 'COMPLETED'
        job.file_path = filepath
        job.record_count = total_exported
        job.completed_at = datetime.utcnow()
        db.session.commit()

    except Exception as e:
        db.session.rollback()
        job.status = 'FAILED'
        job.error_message = str(e)
        job.completed_at = datetime.utcnow()
        db.session.commit()
        print(f"[Export Error] Job {job_id} failed: {e}")

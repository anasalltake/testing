import os
import secrets
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

class Config:
    ENVIRONMENT = os.getenv('FLASK_ENV', os.getenv('ENVIRONMENT', 'development')).lower()
    IS_PRODUCTION = ENVIRONMENT == 'production'

    # Cryptographically secure secrets
    _raw_secret = os.getenv('SECRET_KEY')
    _raw_jwt_secret = os.getenv('JWT_SECRET_KEY')

    if IS_PRODUCTION:
        if not _raw_secret or _raw_secret.startswith('alltake-default') or len(_raw_secret) < 32:
            raise ValueError("CRITICAL SECURITY ERROR: Strong SECRET_KEY (min 32 chars) must be configured in production environment!")
        if not _raw_jwt_secret or _raw_jwt_secret.startswith('alltake-jwt') or len(_raw_jwt_secret) < 32:
            raise ValueError("CRITICAL SECURITY ERROR: Strong JWT_SECRET_KEY (min 32 chars) must be configured in production environment!")
        SECRET_KEY = _raw_secret
        JWT_SECRET_KEY = _raw_jwt_secret
    else:
        SECRET_KEY = _raw_secret or secrets.token_hex(32)
        JWT_SECRET_KEY = _raw_jwt_secret or secrets.token_hex(32)

    # EXACT 5-HOUR ACCESS TOKEN (Business requirement: ACCESS_TOKEN_EXPIRES_MINUTES = 300)
    ACCESS_TOKEN_EXPIRES_MINUTES = 300
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=ACCESS_TOKEN_EXPIRES_MINUTES)
    JWT_ISSUER = 'alltake-auth'
    JWT_AUDIENCE = 'alltake-enterprise'

    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URL',
        'postgresql+psycopg2://alltake_app:secure_alltake_pwd_2026@localhost:5432/alltake_db'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': int(os.getenv('DB_POOL_SIZE', 20)),
        'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', 10)),
        'pool_recycle': 3600,
        'pool_pre_ping': True,
    }

    # Uploads & Storage
    MAX_CONTENT_LENGTH = int(os.getenv('MAX_CONTENT_LENGTH', 100 * 1024 * 1024)) # 100 MB
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', os.path.join(os.getcwd(), 'storage', 'uploads'))
    EXPORT_FOLDER = os.getenv('EXPORT_FOLDER', os.path.join(os.getcwd(), 'storage', 'exports'))

    # Security & Governance limits
    MAX_EXPORT_ROWS = int(os.getenv('MAX_EXPORT_ROWS', 500000))
    EMPLOYEE_MAX_DOWNLOAD_LIMIT = int(os.getenv('EMPLOYEE_MAX_DOWNLOAD_LIMIT', 10000))
    REQUIRE_APPROVAL_ABOVE_LIMIT = os.getenv('REQUIRE_APPROVAL_ABOVE_LIMIT', 'true').lower() == 'true'

    # CORS
    CORS_ORIGINS = [orig.strip() for orig in os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://127.0.0.1:3000').split(',') if orig.strip()]

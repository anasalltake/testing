from functools import wraps
from flask import request, jsonify, g
from app.auth.jwt_handler import decode_access_token
from app.models.user import User

def auth_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({
                'success': False,
                'message': 'Authorization header with Bearer token is required',
                'error_code': 'AUTH_REQUIRED'
            }), 401

        token = auth_header.split(' ')[1]
        payload = decode_access_token(token)
        if not payload:
            return jsonify({
                'success': False,
                'message': 'Token has expired or is invalid',
                'error_code': 'AUTH_INVALID'
            }), 401

        user = User.query.get(payload.get('id'))
        if not user or user.status != 'ACTIVE':
            return jsonify({
                'success': False,
                'message': 'User account is disabled or does not exist',
                'error_code': 'ACCOUNT_DISABLED'
            }), 403

        g.current_user = user
        g.current_token = token
        g.current_token_payload = payload
        return f(*args, **kwargs)
    return decorated

def roles_required(*allowed_roles):
    def decorator(f):
        @wraps(f)
        @auth_required
        def decorated(*args, **kwargs):
            if g.current_user.role not in allowed_roles:
                return jsonify({
                    'success': False,
                    'message': f'Access denied: requires one of {allowed_roles}',
                    'error_code': 'FORBIDDEN'
                }), 403
            return f(*args, **kwargs)
        return decorated
    return decorator

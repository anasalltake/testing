import uuid
from datetime import datetime, timezone
import jwt
from flask import current_app

# Server-side token revocation registry (stores revoked JTIs and timestamp)
REVOKED_JTIS = set()
USER_TOKEN_REVOCATION_TIMESTAMPS = {} # user_id -> timestamp: any token issued before this is invalid

def generate_access_token(user):
    """
    Generate cryptographically signed JWT with exact 5-hour lifetime,
    unique JTI, issuer, audience, and role claims.
    """
    now = datetime.now(timezone.utc)
    jti = f"jwt_{uuid.uuid4().hex}"
    expires_delta = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES')

    payload = {
        'id': user.id,
        'sub': user.id,
        'email': user.email,
        'username': user.username,
        'full_name': user.full_name,
        'role': user.role,
        'jti': jti,
        'iss': current_app.config.get('JWT_ISSUER', 'alltake-auth'),
        'aud': current_app.config.get('JWT_AUDIENCE', 'alltake-enterprise'),
        'iat': int(now.timestamp()),
        'exp': int((now + expires_delta).timestamp())
    }
    return jwt.encode(payload, current_app.config['JWT_SECRET_KEY'], algorithm='HS256')

def decode_access_token(token):
    """
    Decode and validate JWT: checks expiration, signature, issuer, audience,
    and server-side revocation list.
    """
    try:
        payload = jwt.decode(
            token,
            current_app.config['JWT_SECRET_KEY'],
            algorithms=['HS256'],
            audience=current_app.config.get('JWT_AUDIENCE', 'alltake-enterprise'),
            issuer=current_app.config.get('JWT_ISSUER', 'alltake-auth'),
            options={"require": ["exp", "iat", "jti", "sub"]}
        )

        # Check JTI revocation blacklist
        jti = payload.get('jti')
        if jti and jti in REVOKED_JTIS:
            return None

        # Check user-level revocation timestamp (e.g. password changed or account blocked)
        user_id = payload.get('sub') or payload.get('id')
        if user_id in USER_TOKEN_REVOCATION_TIMESTAMPS:
            cutoff = USER_TOKEN_REVOCATION_TIMESTAMPS[user_id]
            if payload.get('iat', 0) < cutoff:
                return None

        return payload
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        return None

def revoke_token(jti):
    """Blacklist a specific token identifier (called on logout)"""
    if jti:
        REVOKED_JTIS.add(jti)

def revoke_all_tokens_for_user(user_id):
    """Revoke all tokens issued for a user prior to now (called on password change / account lock)"""
    if user_id:
        USER_TOKEN_REVOCATION_TIMESTAMPS[user_id] = int(datetime.now(timezone.utc).timestamp())

import sys
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.dataset import Dataset
from app.models.dataset_column import DatasetColumn
from app.models.dataset_record import DatasetRecord

def seed_database():
    app = create_app()
    with app.app_context():
        db.create_all()

        if User.query.filter_by(role='ADMIN').first():
            print("Database already contains administrator account. Aborting seed.")
            return

        print("Seeding initial Alltake Enterprise credentials...")

        # 1. Admin
        admin = User(
            id="usr_admin_001",
            email="admin@alltake.com",
            username="admin",
            full_name="Alexandre Vane (Executive Admin)",
            role="ADMIN",
            status="ACTIVE"
        )
        admin.set_password("Admin@Alltake2026!")
        db.session.add(admin)

        # 2. Data Manager
        manager = User(
            id="usr_mgr_001",
            email="manager@alltake.com",
            username="manager",
            full_name="Priya Raman (Lead Data Architect)",
            role="DATA_MANAGER",
            status="ACTIVE"
        )
        manager.set_password("Manager@Alltake2026!")
        db.session.add(manager)

        # 3. Employee
        emp = User(
            id="usr_emp_001",
            email="employee@alltake.com",
            username="employee",
            full_name="Marcus Sterling (Senior Sales Director)",
            role="EMPLOYEE",
            status="ACTIVE"
        )
        emp.set_password("Employee@Alltake2026!")
        db.session.add(emp)

        db.session.commit()
        print("Success! Seeded default accounts:")
        print("  Admin:        admin@alltake.com    / Admin@Alltake2026!")
        print("  Data Manager: manager@alltake.com  / Manager@Alltake2026!")
        print("  Employee:     employee@alltake.com / Employee@Alltake2026!")

if __name__ == '__main__':
    seed_database()

# ALLTAKE B2B Intelligence – Security Incident Response Runbook

## 1. Overview
This incident response guide provides actionable containment, investigation, and recovery procedures for security incidents affecting ALLTAKE B2B Intelligence.

---

## 2. Playbooks by Threat Scenario

### Scenario A: User Account Compromised
1. **Immediate Account Lockdown**:
   - Navigate to **Admin Settings Center -> Employees & Users**.
   - Click **Block Login** on the compromised account.
   - This immediately flags status as `BLOCKED` and adds a revocation timestamp cutoff, invalidating all outstanding JWT tokens.
2. **Credential Reset**:
   - Open **Set / Reset Password**.
   - Input or auto-generate a fresh high-entropy password.
3. **Audit Trail Review**:
   - Query `/api/logs/audit` filtering by `user_id` to determine any lead exports or queries conducted during the compromise window.

### Scenario B: Exposed JWT Signing Secret (`JWT_SECRET_KEY`)
1. **Rotate Signing Secret**:
   - Generate a fresh 64-character secret using RNGCryptoServiceProvider.
   - Update `JWT_SECRET_KEY` in `backend/.env` and `.env`.
2. **Restart Services**:
   - Restart the Flask WSGI server (`nssm restart AlltakeBackend`).
   - Restart the Express Gateway (`nssm restart AlltakeGateway`).
   - All previously issued JWT tokens signed with the old secret will fail cryptographic signature verification immediately.
3. **Notify Users**:
   - Instruct personnel to log in again with their standard credentials.

### Scenario C: Database Credential Exposure
1. **Update PostgreSQL Password**:
   - Connect via `psql`: `ALTER USER alltake_user WITH PASSWORD '<new_strong_password>';`
2. **Update Environment Files**:
   - Update `DATABASE_URL` in `backend/.env`.
3. **Restart Backend**:
   - `nssm restart AlltakeBackend`.

### Scenario D: Suspected Mass Data Exfiltration
1. **Examine Campaign Logs**:
   - Open **Admin Settings -> Export Governance & Logs**.
   - Inspect every `DATA_EXPORT_EXECUTED` event, campaign name, employee identity, record count, and client IP.
2. **Check Resend Email History**:
   - Compare sent email alert notifications with database audit records.

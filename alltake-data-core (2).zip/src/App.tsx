import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './pages/LoginPage';
import { ApolloLeadExplorer } from './components/apollo/ApolloLeadExplorer';
import { DmsLogo } from './components/common/DmsLogo';
import { Loader2 } from 'lucide-react';

const MainApplication: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F7] flex flex-col items-center justify-center select-none relative overflow-hidden font-sans">
        <div className="fixed top-1/4 -left-20 w-80 h-80 bg-blue-500/[0.08] rounded-full blur-3xl pointer-events-none" />
        <div className="fixed bottom-1/4 -right-20 w-80 h-80 bg-indigo-500/[0.06] rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 p-8 rounded-3xl bg-white/90 backdrop-blur-2xl border border-slate-200/90 shadow-[0_12px_40px_rgba(0,0,0,0.06)] flex flex-col items-center">
          <div className="mb-4">
            <DmsLogo size="lg" />
          </div>
          <div className="flex items-center gap-2 text-slate-600 font-medium text-xs">
            <Loader2 className="w-4 h-4 animate-spin text-[#0071E3]" />
            <span>Connecting to Alltake Data Core Software...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  return <ApolloLeadExplorer />;
};

export default function App() {
  return (
    <AuthProvider>
      <MainApplication />
    </AuthProvider>
  );
}

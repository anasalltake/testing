export type UserRole = 'ADMIN' | 'EMPLOYEE' | 'DATA_MANAGER';
export type UserStatus = 'ACTIVE' | 'DISABLED';

export interface User {
  id: string;
  email: string;
  username: string;
  full_name: string;
  role: UserRole;
  status: UserStatus;
  created_at: string;
  last_login_at: string | null;
}

export interface Dataset {
  id: string;
  name: string;
  original_filename: string;
  uploaded_by_id: string;
  uploaded_by_name: string;
  row_count: number;
  column_count: number;
  status: 'READY' | 'PROCESSING' | 'FAILED';
  created_at: string;
}

export interface DatasetColumn {
  column_name: string;
  display_name: string;
  data_type: string;
  is_core: number | boolean;
}

export interface DatasetRecord {
  id: string;
  dataset_id: string;
  name: string | null;
  email: string | null;
  country: string;
  state: string | null;
  city: string | null;
  company: string | null;
  phone: string | null;
  job_title: string | null;
  created_at: string;
  [key: string]: any; // Dynamic columns
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  page: number;
  limit: number;
  total: number;
  total_pages: number;
}

export interface CountryStat {
  country: string;
  leads?: number;
  count?: number;
}

export interface UploadJob {
  id: string;
  user_id: string;
  user_name: string;
  filename: string;
  file_size: number;
  dataset_id?: string;
  dataset_name: string;
  row_count: number;
  column_count: number;
  valid_rows: number;
  invalid_rows: number;
  duplicate_rows: number;
  new_columns?: string | string[];
  existing_columns?: string | string[];
  status: 'PENDING' | 'VALIDATING' | 'IMPORTING' | 'COMPLETED' | 'FAILED';
  error_details?: string | null;
  started_at: string;
  completed_at?: string | null;
}

export interface DownloadJob {
  id: string;
  user_id: string;
  user_name: string;
  dataset_id?: string;
  dataset_name: string;
  format: 'CSV' | 'EXCEL';
  filters_json: Record<string, any> | string;
  record_count: number;
  status: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  file_path?: string;
  error_message?: string;
  ip_address?: string;
  started_at: string;
  completed_at?: string | null;
}

export interface AuditLog {
  id: string;
  user_id: string | null;
  user_name: string;
  user_role: string;
  action: string;
  entity_type: string;
  entity_id?: string | null;
  details_json?: string;
  details?: Record<string, any>;
  ip_address?: string;
  created_at: string;
}

export interface LoginLog {
  id: string;
  user_id?: string | null;
  email: string;
  role?: string | null;
  ip_address?: string;
  user_agent?: string;
  status: 'SUCCESS' | 'FAILED';
  failure_reason?: string | null;
  created_at: string;
}

export interface CsvPreviewSummary {
  filename: string;
  filesize: number;
  total_rows: number;
  valid_rows: number;
  invalid_rows: number;
  duplicate_rows: number;
  columns_count: number;
  detected_headers: string[];
  new_columns: string[];
  existing_columns: string[];
  duplicate_strategy: string;
  validation_errors: string[];
}

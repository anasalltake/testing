export interface LeadRecord {
  id: string;
  name: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  company: string;
  companyDomain?: string;
  companyLogo?: string;
  email: string;
  phone: string;
  location: string;
  country: string;
  state?: string;
  city?: string;
  companyEmployees: string | number;
  companyIndustries: string[];
  seniority?: string;
  departments?: string[];
  linkedinUrl?: string;
  companyLinkedinUrl?: string;
  websiteUrl?: string;
  twitterUrl?: string;
  isEmailRevealed?: boolean;
  isPhoneRevealed?: boolean;
  dynamicFields?: Record<string, any>;
}

export interface ColumnDef {
  key: string;
  label: string;
  isCore: boolean;
  visible: boolean;
  type: 'text' | 'number' | 'email' | 'phone' | 'url' | 'array';
  uniqueValues: string[];
}

export interface FilterState {
  includes: Record<string, string[]>;
  excludes: Record<string, string[]>;
  searchQuery: string;
  activeTab: 'total' | 'net_new' | 'saved';
}

export interface UserSession {
  email: string;
  name: string;
  role: 'ADMIN' | 'DATA_MANAGER' | 'EMPLOYEE';
  token: string;
}

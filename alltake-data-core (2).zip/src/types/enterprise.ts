export type UserRole = 'ADMIN' | 'DATA_MANAGER' | 'EMPLOYEE';
export type UserStatus = 'ACTIVE' | 'BLOCKED';

export interface EnterpriseUser {
  id: string;
  email: string;
  username: string;
  full_name: string;
  role: UserRole;
  status: UserStatus;
  created_at: string;
  last_login_at: string | null;
  created_by?: string;
}

export type FieldVisibilityMode = 'VISIBLE' | 'MASKED' | 'HIDDEN';

export interface EnterpriseFilterState {
  includes: Record<string, string[]>;
  excludes: Record<string, string[]>;
  searchQuery: string;
  activeTab?: string;
}

export interface FieldVisibilityRule {
  columnKey: string;
  columnLabel: string;
  employeeVisibility: FieldVisibilityMode; // How employee sees it in UI table
  enabledInTable: boolean; // Whether shown in table columns at all
  allowEmployeeDownload?: boolean; // Admin privilege: Whether employees can export this column in CSV
}

export interface FilterRuleConfig {
  id: string;
  key: string;
  label: string;
  category: string;
  enabled: boolean;
  visibleToEmployees: boolean;
  displayOrder: number;
  isSensitivePII: boolean;
}

export const DEFAULT_FILTER_RULES: FilterRuleConfig[] = [
  { id: 'location', key: 'location', label: 'Location & Region Suggestions', category: 'Geographic', enabled: true, visibleToEmployees: true, displayOrder: 1, isSensitivePII: false },
  { id: 'jobTitle', key: 'jobTitle', label: 'Job Title (Include/Exclude)', category: 'Professional', enabled: true, visibleToEmployees: true, displayOrder: 2, isSensitivePII: false },
  { id: 'managementLevel', key: 'managementLevel', label: 'Management Level Checkboxes', category: 'Professional', enabled: true, visibleToEmployees: true, displayOrder: 3, isSensitivePII: false },
  { id: 'companyName', key: 'companyName', label: 'Company Name', category: 'Organization', enabled: true, visibleToEmployees: true, displayOrder: 4, isSensitivePII: false },
  { id: 'companyDomain', key: 'companyDomain', label: 'Company Domain', category: 'Organization', enabled: true, visibleToEmployees: true, displayOrder: 5, isSensitivePII: false },
  { id: 'employeeSize', key: 'employeeSize', label: 'Employee Headcount Size', category: 'Organization', enabled: true, visibleToEmployees: true, displayOrder: 6, isSensitivePII: false },
  { id: 'industryType', key: 'industryType', label: 'Industry Type', category: 'Industry', enabled: true, visibleToEmployees: true, displayOrder: 7, isSensitivePII: false },
  { id: 'revenueRange', key: 'revenueRange', label: 'Revenue Range', category: 'Financial', enabled: true, visibleToEmployees: true, displayOrder: 8, isSensitivePII: false },
  { id: 'sicNaics', key: 'sicNaics', label: 'SIC & NAICS Codes', category: 'Classification', enabled: true, visibleToEmployees: true, displayOrder: 9, isSensitivePII: false },
];

export interface EnterpriseLeadRecord {
  id: string;
  uploadDate: string; // Upload Date
  leadType: string; // Lead Type
  firstName: string; // First Name
  lastName: string; // Last Name
  fullName?: string; // Combined Name
  emailAddress: string; // Email Address
  emailStatus: string; // Email Status (Valid, Catch-All, Invalid)
  jobTitle: string; // Job Title
  jobLevel: string; // Job Level (C-Level, VP, Director, Manager)
  department?: string; // Department (e.g., C-Suite, Sales, Engineering, etc.)
  managementLevel?: string; // Management Level (e.g., Owner, Founder, VP, Director, etc.)
  companyName: string; // Company Name
  addressLink: string; // Address Link
  addressLine1: string; // Address Line 1
  city: string; // City
  state: string; // State
  postalCode: string; // Postal Code
  country: string; // Country
  companyPhone: string; // Company Phone
  directNumber: string; // Direct Number
  otherNumber: string; // Other Number
  phoneType?: 'corporate' | 'mobile' | 'other' | string;
  employeeSize: string; // Employee Size (e.g. 1 to 10, 11 to 20, etc.)
  industryType: string; // Industry Type
  revenueSize: string; // Revenue Size
  jobTitleUrl: string; // Job Title URL
  companyUrl: string; // Company URL
  revenueSizeLink: string; // Revenue Size Link
  sicCode: string; // SIC Code
  naicsCode: string; // NAICS Code
  sicCodeUrl: string; // SIC Code URL
  naicsCodeUrl: string; // NAICS Code URL
  comment1: string; // Comment 1
  comment2: string; // Comment 2
  domain: string; // Domain
  technologies?: string[]; // Technologies used
  [key: string]: any; // Additional custom dynamic fields
}

export interface EnterpriseColumnDef {
  key: string;
  label: string;
  isCore: boolean;
  visible: boolean;
  employeeVisible?: boolean; // Whether visible to employees after applying filter
  order?: number; // Position order index (for moving columns forwards / backwards)
  type: 'text' | 'number' | 'email' | 'phone' | 'url';
  uniqueValues: string[];
}

/**
 * Streamlined Enterprise Filter State based on User Request:
 * 1. Name: First Name, Last Name
 * 2. Email Address: Search bar
 * 3. Location: Address search bar + City/State/Zip/Country with Apollo-style smart suggestions
 * 4. Address Link: Search bar
 * 5. Phone No: Checkboxes (corporate, mobile, other) + search
 * 6. Job Title: Include/Exclude paste
 * 7. Company Name: Include/Exclude paste
 * 8. Company Domain: Include/Exclude paste
 * 9. Employee Size: Checkbox ranges
 * 10. Industry Type: Multi-checkbox
 * 11. Revenue Range: Checkbox ranges
 * 12. SIC & NAICS: Unified single search bar
 */
export interface SerialFiltersState {
  // 1. Name (First name, Last name)
  firstName: string;
  lastName: string;

  // 2. Email search bar
  emailSearch: string;

  // 3. Location (Address search + Smart City/State/Zip/Country suggestions)
  addressSearch: string;
  selectedLocations: string[]; // e.g. ["Pune, Maharashtra, India", "California, United States"]
  locationQuery: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;

  // 4. Address Link search bar
  addressLinkSearch: string;

  // 5. Phone no checkboxes & search
  phoneTypes: {
    corporate: boolean;
    mobile: boolean;
    other: boolean;
  };
  phoneSearch: string;

  // 6. Job Title paste (include / exclude)
  jobTitlePaste: string;
  jobTitleMode: 'include' | 'exclude';

  // 6B. Management Level checkboxes (Unique DB values)
  managementLevels: string[];

  // 6C. Job Level checkboxes (Seniority: C-Level, VP, Director, Manager, Senior, etc.)
  jobLevels: string[];

  // 7. Company Name paste (include / exclude)
  companyNamePaste: string;
  companyNameMode: 'include' | 'exclude';

  // 8. Company Domain paste (include / exclude)
  companyDomainPaste: string;
  companyDomainMode: 'include' | 'exclude';

  // 9. Employee Size checkbox ranges
  employeeSizes: string[];

  // 10. Industry Type multicheckbox
  industries: string[];

  // 11. Revenue range
  revenueRanges: string[];

  // 12. SIC & NAICS Unified Single Search Bar
  sicNaicsSearch: string;
}


export interface DownloadAuditLog {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: UserRole;
  campaignName?: string;
  campaignNotes?: string;
  datasetName?: string;
  recordCount: number;
  format: 'CSV' | 'EXCEL';
  filtersApplied: Record<string, any>;
  filtersSummary: string;
  ipAddress: string;
  timestamp: string;
}

export interface DatabaseConfig {
  host: string;
  port: number;
  database: string;
  username: string;
  ssl: boolean;
  isConnected: boolean;
  lastTestedAt?: string;
}

export interface DatabaseIssueItem {
  severity: 'critical' | 'warning' | 'info';
  title: string;
  message: string;
  code: string;
  suggestion?: string;
}

export interface DatabaseDiagnosticStatus {
  success: boolean;
  status: 'OPTIMAL' | 'ONLINE_EMPTY' | 'WARNING' | 'MAINTENANCE';
  conditionText: string;
  serverName: string;
  engine: string;
  database: string;
  cluster: string;
  host: string;
  table: string;
  columnsCount: number;
  totalRecords: number;
  memoryUsageMb: string;
  ssl: boolean;
  readLatencyMs: number;
  writeLatencyMs: number;
  encryption: string;
  lastHealthCheck: string;
  issues: DatabaseIssueItem[];
  columnKeys: string[];
}

export interface ExportGovernanceSettings {
  employeeMaxDownloadLimit: number; // default: 10000
  requireApprovalAboveLimit: boolean; // default: true
  allowEmployeeDownload: boolean; // default: true
}

export interface ExportApprovalRequest {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  user_role: UserRole;
  requested_count: number;
  file_format: 'CSV' | 'XLSX';
  campaign_name?: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'DOWNLOADED';
  admin_note?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  created_at: string;
  download_token?: string;
  filters_summary?: string;
  filters_snapshot?: any;
}

export interface EmailNotificationSettings {
  enabled: boolean;
  resendApiKey: string;
  senderEmail: string;
  recipientEmails: string[];
  notifyOnEmployeeExport: boolean;
  notifyOnApprovalRequest: boolean;
  notifyOnApprovalDecision: boolean;
  notifyOnBulkUpload: boolean;
  notifyOnSecurityAlert: boolean;
  lastUpdated?: string;
  lastUpdatedBy?: string;
}

export interface EmailDispatchLog {
  id: string;
  eventType: 'EMPLOYEE_EXPORT' | 'APPROVAL_REQUEST' | 'APPROVAL_DECISION' | 'BULK_UPLOAD' | 'SECURITY_ALERT' | 'TEST_EMAIL';
  recipient: string;
  subject: string;
  status: 'DELIVERED' | 'FAILED';
  resendId?: string;
  errorMessage?: string;
  details?: any;
  timestamp: string;
}

export {
  DEPARTMENT_OPTIONS,
  MANAGEMENT_LEVEL_OPTIONS,
  EMPLOYEE_SIZE_OPTIONS,
  REVENUE_RANGE_OPTIONS,
  TECHNOLOGY_OPTIONS,
} from '../services/enterpriseDb';

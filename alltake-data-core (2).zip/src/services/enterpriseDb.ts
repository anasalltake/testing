import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import {
  EnterpriseLeadRecord,
  EnterpriseColumnDef,
  EnterpriseFilterState,
  SerialFiltersState,
  EnterpriseUser,
  FieldVisibilityRule,
  FilterRuleConfig,
  DEFAULT_FILTER_RULES,
  DownloadAuditLog,
  DatabaseConfig,
  ExportGovernanceSettings,
  ExportApprovalRequest,
  EmailNotificationSettings,
  EmailDispatchLog,
} from '../types/enterprise';

export const DEPARTMENT_OPTIONS = [
  'C-Suite',
  'Product',
  'Engineering & Technical',
  'Design',
  'Education',
  'Finance',
  'Human Resources',
  'Information Technology',
  'Legal',
  'Marketing',
  'Medical & Health',
  'Operations',
  'Sales',
  'Consulting',
] as const;

export const MANAGEMENT_LEVEL_OPTIONS = [
  'Director',
  'Manager',
  'VP',
  'C-Suite',
  'Senior',
  'Head',
  'Founder',
  'Owner',
  'Entry Level',
  'Individual Contributor',
] as const;

export const JOB_LEVEL_OPTIONS = [
  'C-Level / Executive',
  'VP',
  'Director',
  'Head of Department',
  'Manager',
  'Senior',
  'Lead',
  'Specialist / Individual Contributor',
  'Entry Level',
  'Partner',
  'Owner / Founder',
] as const;

export const ALL_WORLD_COUNTRIES: string[] = [
  'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Australia', 'Austria',
  'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan',
  'Bolivia', 'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia',
  'Cameroon', 'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo', 'Costa Rica',
  'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt',
  'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon',
  'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana',
  'Haiti', 'Honduras', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel',
  'Italy', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'Kuwait', 'Kyrgyzstan', 'Laos',
  'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Madagascar', 'Malawi',
  'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Micronesia', 'Moldova',
  'Monaco', 'Mongolia', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands',
  'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'North Korea', 'North Macedonia', 'Norway', 'Oman', 'Pakistan', 'Palau',
  'Palestine', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania',
  'Russia', 'Rwanda', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal',
  'Serbia', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'South Korea',
  'South Sudan', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan',
  'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Tuvalu',
  'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela',
  'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'
];

export const EMPLOYEE_SIZE_OPTIONS = [
  '2-10 employees',
  '11-50 employees',
  '51-200 employees',
  '201-500 employees',
  '501-1,000 employees',
  '1,001-5,000 employees',
  '5,001-10,000 employees',
  '10,001+ employees',
] as const;

export interface EmployeeBracketDef {
  label: string;
  min: number;
  max: number;
}

export const EMPLOYEE_BRACKETS: EmployeeBracketDef[] = [
  { label: '2-10 employees', min: 2, max: 10 },
  { label: '11-50 employees', min: 11, max: 50 },
  { label: '51-200 employees', min: 51, max: 200 },
  { label: '201-500 employees', min: 201, max: 500 },
  { label: '501-1,000 employees', min: 501, max: 1000 },
  { label: '1,001-5,000 employees', min: 1001, max: 5000 },
  { label: '5,001-10,000 employees', min: 5001, max: 10000 },
  { label: '10,001+ employees', min: 10001, max: Infinity },
];

export const REVENUE_RANGE_OPTIONS = [
  'Less than $1M',
  '$1M to $5M',
  '$5M to $10M',
  '$10M to $25M',
  '$25M to $50M',
  '$50M to $100M',
  '$100M to $250M',
  '$250M to $500M',
  '$500M to $1B',
  '$1B+',
] as const;

export interface RevenueBracketDef {
  label: string;
  min: number;
  max: number;
  aliases: string[];
}

export const REVENUE_BRACKETS: RevenueBracketDef[] = [
  { label: 'Less than $1M', min: 0, max: 999999, aliases: ['<$1m', '<1m', 'less than $1m', 'under 1m'] },
  { label: '$1M to $5M', min: 1000000, max: 5000000, aliases: ['$1m to $5m', '$1m - $5m', '1m to 5m', '1m - 5m', '1m', '$1m'] },
  { label: '$5M to $10M', min: 5000000, max: 10000000, aliases: ['$5m to $10m', '$5m - $10m', '5m to 10m', '5m - 10m', '5m', '$5m'] },
  { label: '$10M to $25M', min: 10000000, max: 25000000, aliases: ['$10m to $25m', '$10m - $25m', '10m to 25m', '10m - 25m', '10m', '$10m'] },
  { label: '$25M to $50M', min: 25000000, max: 50000000, aliases: ['$25m to $50m', '$25m - $50m', '25m to 25m', '25m', '$25m'] },
  { label: '$50M to $100M', min: 50000000, max: 100000000, aliases: ['$50m to $100m', '$50m - $100m', '50m to 100m', '50m', '$50m'] },
  { label: '$100M to $250M', min: 100000000, max: 250000000, aliases: ['$100m to $250m', '$100m - $250m', '100m'] },
  { label: '$250M to $500M', min: 250000000, max: 500000000, aliases: ['$250m to $500m', '$250m - $500m', '250m'] },
  { label: '$500M to $1B', min: 500000000, max: 1000000000, aliases: ['$500m to $1b', '$500m - $1b', '500m', '$500m'] },
  { label: '$1B+', min: 1000000000, max: Infinity, aliases: ['$1b+', '1b+', '1b', '$1b', 'over 1b', '>1b'] },
];

/**
 * Robust numerical parser for Employee Count (handles numbers e.g. 45, strings e.g. "11-50 employees", "11 to 20")
 */
export function parseEmployeeNumbers(raw: string | number | undefined | null): { min: number; max: number } | null {
  if (raw === undefined || raw === null) return null;
  const str = String(raw).trim();
  if (!str) return null;

  const cleaned = str.replace(/,/g, '');
  const matches = cleaned.match(/\d+/g);
  if (!matches || matches.length === 0) return null;

  if (matches.length === 1) {
    const num = parseInt(matches[0], 10);
    if (str.includes('+') || str.toLowerCase().includes('more') || str.toLowerCase().includes('plus')) {
      return { min: num, max: Infinity };
    }
    if (str.includes('<') || str.toLowerCase().includes('less')) {
      return { min: 1, max: num };
    }
    return { min: num, max: num };
  }

  const num1 = parseInt(matches[0], 10);
  const num2 = parseInt(matches[1], 10);
  return { min: Math.min(num1, num2), max: Math.max(num1, num2) };
}

/**
 * Matches lead employeeSize accurately against user's checked Employee Size checkboxes
 * Handles both numeric integers (e.g. 45 -> matches 11-50 employees) and range strings.
 */
export function matchesEmployeeSizeFilter(
  leadValue: string | number | undefined | null,
  selectedFilters: string[]
): boolean {
  if (!selectedFilters || selectedFilters.length === 0) return true;
  if (!leadValue) return false;

  const leadStr = String(leadValue).trim().toLowerCase();

  // 1. Direct text / normalized string check
  for (const filter of selectedFilters) {
    const filterClean = filter.toLowerCase();
    const filterShort = filterClean.replace(/\s+employees$/, '').replace(/,/g, '');
    const leadClean = leadStr.replace(/,/g, '');

    if (leadClean === filterClean || leadClean === filterShort) return true;
    if (leadClean.includes(filterShort)) return true;
  }

  // 2. Numerical range check
  const parsed = parseEmployeeNumbers(leadValue);
  if (parsed) {
    for (const filter of selectedFilters) {
      const bracket = EMPLOYEE_BRACKETS.find((b) => b.label.toLowerCase() === filter.toLowerCase());
      if (bracket) {
        if (parsed.min === parsed.max) {
          if (parsed.min >= bracket.min && parsed.min <= bracket.max) {
            return true;
          }
        } else {
          const overlapMin = Math.max(parsed.min, bracket.min);
          const overlapMax = Math.min(parsed.max, bracket.max);
          if (overlapMin <= overlapMax) {
            return true;
          }
        }
      }
    }
  }

  return false;
}

/**
 * Parses revenue strings and numbers (e.g. 1000000, "1M", "$1M", "500K", "$25M to $50M")
 */
export function parseSingleRevenueNumber(input: string): number | null {
  const s = input.trim().toLowerCase().replace(/[$,]/g, '');
  if (!s) return null;

  if (s.endsWith('b') || s.includes('billion')) {
    const n = parseFloat(s.replace(/[^\d.]/g, ''));
    if (!isNaN(n)) return n * 1_000_000_000;
  }
  if (s.endsWith('m') || s.includes('million')) {
    const n = parseFloat(s.replace(/[^\d.]/g, ''));
    if (!isNaN(n)) return n * 1_000_000;
  }
  if (s.endsWith('k') || s.includes('thousand')) {
    const n = parseFloat(s.replace(/[^\d.]/g, ''));
    if (!isNaN(n)) return n * 1_000;
  }
  const n = parseFloat(s.replace(/[^\d.]/g, ''));
  if (!isNaN(n)) return n;

  return null;
}

export function parseRevenueToNumericRange(raw: string | number | undefined | null): { min: number; max: number } | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw === 'number') {
    return { min: raw, max: raw };
  }
  const str = String(raw).trim().toLowerCase();
  if (!str) return null;

  const rangeSplit = str.split(/\s*(?:to|-)\s*/);
  if (rangeSplit.length === 2) {
    const val1 = parseSingleRevenueNumber(rangeSplit[0]);
    const val2 = parseSingleRevenueNumber(rangeSplit[1]);
    if (val1 !== null && val2 !== null) {
      return { min: Math.min(val1, val2), max: Math.max(val1, val2) };
    }
  }

  const single = parseSingleRevenueNumber(str);
  if (single !== null) {
    if (str.includes('+') || str.includes('over') || str.includes('more than')) {
      return { min: single, max: Infinity };
    }
    if (str.includes('<') || str.includes('less') || str.includes('under')) {
      return { min: 0, max: single };
    }
    return { min: single, max: single };
  }

  return null;
}

/**
 * Matches lead revenueSize accurately against user's checked Revenue Range checkboxes
 * Handles both numeric integers (e.g. 1000000 or "1000000" -> maps to $1M to $5M) and textual strings.
 */
export function matchesRevenueFilter(
  leadValue: string | number | undefined | null,
  selectedFilters: string[]
): boolean {
  if (!selectedFilters || selectedFilters.length === 0) return true;
  if (!leadValue) return false;

  const leadStr = String(leadValue).trim().toLowerCase();

  // 1. Textual match
  for (const filter of selectedFilters) {
    const fClean = filter.toLowerCase().replace(/[$,\s]/g, '');
    const lClean = leadStr.replace(/[$,\s]/g, '');
    if (lClean === fClean || lClean.includes(fClean) || fClean.includes(lClean)) {
      return true;
    }

    const bracket = REVENUE_BRACKETS.find((b) => b.label.toLowerCase() === filter.toLowerCase());
    if (bracket && bracket.aliases.some((alias) => leadStr.includes(alias))) {
      return true;
    }
  }

  // 2. Numerical mapping (e.g. 1,000,000 mapped to $1M to $5M)
  const parsedLead = parseRevenueToNumericRange(leadValue);
  if (parsedLead) {
    for (const filter of selectedFilters) {
      const bracket = REVENUE_BRACKETS.find((b) => b.label.toLowerCase() === filter.toLowerCase());
      if (bracket) {
        if (parsedLead.min === parsedLead.max) {
          if (parsedLead.min >= bracket.min && parsedLead.min <= bracket.max) {
            return true;
          }
        } else {
          const overlapMin = Math.max(parsedLead.min, bracket.min);
          const overlapMax = Math.min(parsedLead.max, bracket.max);
          if (overlapMin <= overlapMax) {
            return true;
          }
        }
      }
    }
  }

  return false;
}

export const TECHNOLOGY_OPTIONS = [
  'Salesforce',
  'HubSpot',
  'Google Analytics',
  'AWS',
  'Shopify',
  'WordPress',
  'Microsoft 365',
  'React',
  'Python',
  'Node.js',
  'Oracle',
  'SAP',
  'Slack',
  'Stripe',
  'Zoom',
  'MongoDB',
  'PostgreSQL',
  'Docker',
  'Kubernetes',
] as const;

export const DEFAULT_SERIAL_FILTERS: SerialFiltersState = {
  firstName: '',
  lastName: '',
  emailSearch: '',
  addressSearch: '',
  selectedLocations: [],
  locationQuery: '',
  city: '',
  state: '',
  postalCode: '',
  country: '',
  addressLinkSearch: '',
  phoneTypes: { corporate: false, mobile: false, other: false },
  phoneSearch: '',
  jobTitlePaste: '',
  jobTitleMode: 'include',
  managementLevels: [],
  jobLevels: [],
  companyNamePaste: '',
  companyNameMode: 'include',
  companyDomainPaste: '',
  companyDomainMode: 'include',
  employeeSizes: [],
  industries: [],
  revenueRanges: [],
  sicNaicsSearch: '',
};

const DB_NAME = 'alltake_enterprise_db_v4';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

export const STANDARD_31_COLUMNS: { key: string; label: string; type: EnterpriseColumnDef['type'] }[] = [
  { key: 'firstName', label: 'First Name', type: 'text' },
  { key: 'lastName', label: 'Last Name', type: 'text' },
  { key: 'emailAddress', label: 'Email Address', type: 'email' },
  { key: 'jobTitle', label: 'Job Title', type: 'text' },
  { key: 'companyName', label: 'Company Name', type: 'text' },
  { key: 'managementLevel', label: 'Management Level', type: 'text' },
  { key: 'jobLevel', label: 'Job Level', type: 'text' },
  { key: 'emailStatus', label: 'Email Status', type: 'text' },
  { key: 'directNumber', label: 'Direct Number', type: 'phone' },
  { key: 'companyPhone', label: 'Company Phone', type: 'phone' },
  { key: 'otherNumber', label: 'Other Number', type: 'phone' },
  { key: 'city', label: 'City', type: 'text' },
  { key: 'state', label: 'State', type: 'text' },
  { key: 'country', label: 'Country', type: 'text' },
  { key: 'industryType', label: 'Industry Type', type: 'text' },
  { key: 'employeeSize', label: 'Employee Size', type: 'text' },
  { key: 'revenueSize', label: 'Revenue Size', type: 'text' },
  { key: 'leadType', label: 'Lead Type', type: 'text' },
  { key: 'uploadDate', label: 'Upload Date', type: 'text' },
  { key: 'addressLink', label: 'Address Link', type: 'url' },
  { key: 'addressLine1', label: 'Address Line 1', type: 'text' },
  { key: 'postalCode', label: 'Postal Code', type: 'text' },
  { key: 'jobTitleUrl', label: 'Job Title URL', type: 'url' },
  { key: 'companyUrl', label: 'Company URL', type: 'url' },
  { key: 'revenueSizeLink', label: 'Revenue Size Link', type: 'url' },
  { key: 'sicCode', label: 'SIC Code', type: 'text' },
  { key: 'naicsCode', label: 'NAICS Code', type: 'text' },
  { key: 'sicCodeUrl', label: 'SIC Code URL', type: 'url' },
  { key: 'naicsCodeUrl', label: 'NAICS Code URL', type: 'url' },
  { key: 'comment1', label: 'Comment 1', type: 'text' },
  { key: 'comment2', label: 'Comment 2', type: 'text' },
  { key: 'domain', label: 'Domain', type: 'text' },
];

export async function openEnterpriseDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('leads')) {
        const leadStore = db.createObjectStore('leads', { keyPath: 'id' });
        leadStore.createIndex('companyName', 'companyName', { unique: false });
        leadStore.createIndex('country', 'country', { unique: false });
        leadStore.createIndex('jobTitle', 'jobTitle', { unique: false });
        leadStore.createIndex('industryType', 'industryType', { unique: false });
      }
      if (!db.objectStoreNames.contains('users')) {
        db.createObjectStore('users', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('columns')) {
        db.createObjectStore('columns', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('visibilityRules')) {
        db.createObjectStore('visibilityRules', { keyPath: 'columnKey' });
      }
      if (!db.objectStoreNames.contains('downloadLogs')) {
        db.createObjectStore('downloadLogs', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('dbConfig')) {
        db.createObjectStore('dbConfig', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(request.result);
    };

    request.onerror = () => reject(request.error);
  });
}

// Initial 3 Default Users
export const INITIAL_USERS: EnterpriseUser[] = [
  {
    id: 'usr_admin',
    email: 'admin@alltake.com',
    username: 'admin',
    full_name: 'Anas (Super Administrator)',
    role: 'ADMIN',
    status: 'ACTIVE',
    created_at: new Date('2026-01-01').toISOString(),
    last_login_at: new Date().toISOString(),
  },
  {
    id: 'usr_manager',
    email: 'manager@alltake.com',
    username: 'manager',
    full_name: 'Data Operations Manager',
    role: 'DATA_MANAGER',
    status: 'ACTIVE',
    created_at: new Date('2026-01-15').toISOString(),
    last_login_at: null,
  },
  {
    id: 'usr_employee',
    email: 'employee@alltake.com',
    username: 'employee',
    full_name: 'Lead Prospect Analyst',
    role: 'EMPLOYEE',
    status: 'ACTIVE',
    created_at: new Date('2026-02-01').toISOString(),
    last_login_at: null,
  },
];

// Initial Field Visibility Rules for Employees
export const INITIAL_VISIBILITY_RULES: FieldVisibilityRule[] = STANDARD_31_COLUMNS.map((col) => {
  // Sensitive columns masked by default for employees
  const isSensitive = ['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(col.key);
  return {
    columnKey: col.key,
    columnLabel: col.label,
    employeeVisibility: isSensitive ? 'MASKED' : 'VISIBLE',
    enabledInTable: true,
    allowEmployeeDownload: !isSensitive, // Admin privilege: by default non-sensitive columns allowed for employee download
  };
});

// Seed Data with All 31 Standard Columns & Specific Serial Facets
export const INITIAL_SEED_LEADS: EnterpriseLeadRecord[] = [
  {
    id: 'lead_ent_001',
    uploadDate: '2026-10-01',
    leadType: 'Executive B2B',
    firstName: 'Bruce',
    lastName: 'Kasanoff',
    fullName: 'Bruce Kasanoff',
    emailAddress: 'bruce@kasanoff.com',
    emailStatus: 'Valid',
    jobTitle: 'Life Coach & Strategic Advisor',
    jobLevel: 'Founder / C-Level',
    department: 'Consulting',
    managementLevel: 'Owner',
    companyName: 'Kasanoff Advisory Group',
    addressLink: 'https://maps.google.com/?q=Bend,+Oregon',
    addressLine1: '742 Northwest Wall Street',
    city: 'Bend',
    state: 'Oregon',
    postalCode: '97701',
    country: 'United States',
    companyPhone: '+1 (541) 555-0142',
    directNumber: '+1 (541) 555-0199',
    otherNumber: '+1 (541) 555-0188',
    phoneType: 'corporate',
    employeeSize: '2-10 employees',
    industryType: 'Professional Training & Coaching',
    revenueSize: '$1M to $5M',
    jobTitleUrl: 'https://linkedin.com/in/brucekasanoff',
    companyUrl: 'https://kasanoff.com',
    revenueSizeLink: 'https://bloomberg.com/profile/company/KASANOFF',
    sicCode: '8748',
    naicsCode: '541611',
    sicCodeUrl: 'https://siccode.com/sic-code/8748',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541611',
    comment1: 'Keynote Speaker & Forbes Contributor',
    comment2: 'High Intent Lead Verified',
    domain: 'kasanoff.com',
    technologies: ['HubSpot', 'Google Analytics', 'WordPress'],
  },
  {
    id: 'lead_ent_002',
    uploadDate: '2026-10-02',
    leadType: 'Enterprise Media',
    firstName: 'Eric',
    lastName: 'Olander',
    fullName: 'Eric Olander',
    emailAddress: 'eric@chinaglobalsouth.com',
    emailStatus: 'Valid',
    jobTitle: 'Co-Founder and Editor in Chief',
    jobLevel: 'C-Level / Executive',
    department: 'Operations',
    managementLevel: 'Founder',
    companyName: 'The China Global South Project',
    addressLink: 'https://maps.google.com/?q=Washington,+DC',
    addressLine1: '1200 17th St NW, Suite 400',
    city: 'Washington',
    state: 'District of Columbia',
    postalCode: '20036',
    country: 'United States',
    companyPhone: '+1 (202) 555-0189',
    directNumber: '+1 (202) 555-0122',
    otherNumber: '+1 (202) 555-0133',
    phoneType: 'corporate',
    employeeSize: '11-50 employees',
    industryType: 'Media Production & Publishing',
    revenueSize: '5000000',
    jobTitleUrl: 'https://linkedin.com/in/ericolander',
    companyUrl: 'https://chinaglobalsouth.com',
    revenueSizeLink: 'https://bloomberg.com/profile/company/CGSP',
    sicCode: '2721',
    naicsCode: '511120',
    sicCodeUrl: 'https://siccode.com/sic-code/2721',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=511120',
    comment1: 'Global Policy Media Specialist',
    comment2: 'Subscribed to Enterprise Briefings',
    domain: 'chinaglobalsouth.com',
    technologies: ['WordPress', 'Slack', 'Zoom'],
  },
  {
    id: 'lead_ent_003',
    uploadDate: '2026-10-02',
    leadType: 'Tech Hardware',
    firstName: 'Ilya',
    lastName: 'Pozin',
    fullName: 'Ilya Pozin',
    emailAddress: 'ilya@freetelly.com',
    emailStatus: 'Valid',
    jobTitle: 'Founder & CEO',
    jobLevel: 'C-Level / Board',
    department: 'C-Suite',
    managementLevel: 'C suite',
    companyName: 'Telly TV Corporation',
    addressLink: 'https://maps.google.com/?q=Los+Angeles,+California',
    addressLine1: '12100 Wilshire Blvd, 8th Floor',
    city: 'Los Angeles',
    state: 'California',
    postalCode: '90025',
    country: 'United States',
    companyPhone: '+1 (310) 555-0177',
    directNumber: '+1 (310) 555-0185',
    otherNumber: '+1 (310) 555-0192',
    phoneType: 'mobile',
    employeeSize: '51-200 employees',
    industryType: 'Consumer Electronics & Software',
    revenueSize: '25000000',
    jobTitleUrl: 'https://linkedin.com/in/ilyapozin',
    companyUrl: 'https://freetelly.com',
    revenueSizeLink: 'https://crunchbase.com/organization/telly',
    sicCode: '3651',
    naicsCode: '334310',
    sicCodeUrl: 'https://siccode.com/sic-code/3651',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=334310',
    comment1: 'Pluto TV Co-Founder',
    comment2: 'Series B Growth Stage Target',
    domain: 'freetelly.com',
    technologies: ['React', 'Node.js', 'AWS', 'Python'],
  },
  {
    id: 'lead_ent_004',
    uploadDate: '2026-10-03',
    leadType: 'Real Estate SaaS',
    firstName: 'Heather',
    lastName: 'Elias',
    fullName: 'Heather Elias',
    emailAddress: 'heather@elmstreet.com',
    emailStatus: 'Catch-All',
    jobTitle: 'Chief Growth Officer',
    jobLevel: 'VP / Executive',
    department: 'Marketing',
    managementLevel: 'Vp',
    companyName: 'Elm Street Technology',
    addressLink: 'https://maps.google.com/?q=Ashburn,+Virginia',
    addressLine1: '44601 Village Drive, Suite 230',
    city: 'Ashburn',
    state: 'Virginia',
    postalCode: '20147',
    country: 'United States',
    companyPhone: '+1 (703) 555-0164',
    directNumber: '+1 (703) 555-0141',
    otherNumber: '',
    phoneType: 'mobile',
    employeeSize: '201-500 employees',
    industryType: 'Real Estate & PropTech',
    revenueSize: '$50M to $100M',
    jobTitleUrl: 'https://linkedin.com/in/heatherelias',
    companyUrl: 'https://elmstreet.com',
    revenueSizeLink: 'https://crunchbase.com/organization/elm-street-technology',
    sicCode: '7372',
    naicsCode: '511210',
    sicCodeUrl: 'https://siccode.com/sic-code/7372',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=511210',
    comment1: 'National Speaker & Author',
    comment2: 'Marketing Automation Evaluation',
    domain: 'elmstreet.com',
    technologies: ['Salesforce', 'HubSpot', 'Shopify'],
  },
  {
    id: 'lead_ent_005',
    uploadDate: '2026-10-03',
    leadType: 'Sports & Entertainment',
    firstName: 'Jonathan',
    lastName: 'Becher',
    fullName: 'Jonathan Becher',
    emailAddress: 'jbecher@sjsharks.com',
    emailStatus: 'Valid',
    jobTitle: 'President & Board Member',
    jobLevel: 'President / C-Level',
    department: 'C-Suite',
    managementLevel: 'C suite',
    companyName: 'Sharks Sports & Entertainment',
    addressLink: 'https://maps.google.com/?q=San+Jose,+California',
    addressLine1: '525 West Santa Clara Street',
    city: 'San Jose',
    state: 'California',
    postalCode: '95113',
    country: 'United States',
    companyPhone: '+1 (408) 555-0199',
    directNumber: '+1 (408) 555-0182',
    otherNumber: '+1 (408) 555-0111',
    phoneType: 'corporate',
    employeeSize: '501-1,000 employees',
    industryType: 'Sports, Media & Events',
    revenueSize: '$100M to $250M',
    jobTitleUrl: 'https://linkedin.com/in/jbecher',
    companyUrl: 'https://sjsharks.com',
    revenueSizeLink: 'https://forbes.com/teams/san-jose-sharks',
    sicCode: '7941',
    naicsCode: '711211',
    sicCodeUrl: 'https://siccode.com/sic-code/7941',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=711211',
    comment1: 'Former Chief Digital Officer at SAP',
    comment2: 'Sponsorship Inquiries Open',
    domain: 'sjsharks.com',
    technologies: ['SAP', 'Oracle', 'Microsoft 365'],
  },
  {
    id: 'lead_ent_006',
    uploadDate: '2026-10-04',
    leadType: 'Financial Capital',
    firstName: 'Betty',
    lastName: 'Liu',
    fullName: 'Betty Liu',
    emailAddress: 'betty.liu@apextreasury.com',
    emailStatus: 'Valid',
    jobTitle: 'Independent Director & Chair',
    jobLevel: 'Director / Board',
    department: 'Finance',
    managementLevel: 'Director',
    companyName: 'Apex Treasury Corporation',
    addressLink: 'https://maps.google.com/?q=New+York,+New+York',
    addressLine1: '375 Park Avenue, 24th Floor',
    city: 'New York',
    state: 'New York',
    postalCode: '10152',
    country: 'United States',
    companyPhone: '+1 (212) 555-0138',
    directNumber: '+1 (212) 555-0145',
    otherNumber: '+1 (212) 555-0170',
    phoneType: 'corporate',
    employeeSize: '11-50 employees',
    industryType: 'Financial Services & Capital Markets',
    revenueSize: '$50M to $100M',
    jobTitleUrl: 'https://linkedin.com/in/bettyliu',
    companyUrl: 'https://apextreasury.com',
    revenueSizeLink: 'https://bloomberg.com/profile/person/bettyliu',
    sicCode: '6211',
    naicsCode: '523110',
    sicCodeUrl: 'https://siccode.com/sic-code/6211',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=523110',
    comment1: 'Former NYSE Vice Chairman & Bloomberg Anchor',
    comment2: 'Executive Board Member',
    domain: 'apextreasury.com',
    technologies: ['Bloomberg', 'Microsoft 365', 'Salesforce'],
  },
  {
    id: 'lead_ent_007',
    uploadDate: '2026-10-04',
    leadType: 'Digital Marketing',
    firstName: 'Shay',
    lastName: 'Rowbottom',
    fullName: 'Shay Rowbottom',
    emailAddress: 'shay@shayrowbottom.com',
    emailStatus: 'Valid',
    jobTitle: 'Chief Executive Officer',
    jobLevel: 'Founder / C-Level',
    department: 'Marketing',
    managementLevel: 'Founder',
    companyName: 'Shay Rowbottom Marketing',
    addressLink: 'https://maps.google.com/?q=Miami,+Florida',
    addressLine1: '1111 Lincoln Road, Suite 500',
    city: 'Miami',
    state: 'Florida',
    postalCode: '33139',
    country: 'United States',
    companyPhone: '+1 (305) 555-0155',
    directNumber: '+1 (305) 555-0162',
    otherNumber: '',
    phoneType: 'mobile',
    employeeSize: '2-10 employees',
    industryType: 'Digital Media & Video Marketing',
    revenueSize: '1000000',
    jobTitleUrl: 'https://linkedin.com/in/shayrowbottom',
    companyUrl: 'https://shayrowbottom.com',
    revenueSizeLink: 'https://zoominfo.com/c/shay-rowbottom-marketing',
    sicCode: '7311',
    naicsCode: '541810',
    sicCodeUrl: 'https://siccode.com/sic-code/7311',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541810',
    comment1: 'LinkedIn Top Voice Video',
    comment2: 'B2B Creative Services',
    domain: 'shayrowbottom.com',
    technologies: ['HubSpot', 'Google Analytics', 'Shopify'],
  },
  {
    id: 'lead_ent_008',
    uploadDate: '2026-10-05',
    leadType: 'Healthcare Tech',
    firstName: 'David',
    lastName: 'Feinberg',
    fullName: 'David Feinberg',
    emailAddress: 'dfeinberg@cernerhealth.com',
    emailStatus: 'Valid',
    jobTitle: 'President & Chairman',
    jobLevel: 'C-Level / President',
    department: 'Medical & Health',
    managementLevel: 'C suite',
    companyName: 'Cerner Oracle Health',
    addressLink: 'https://maps.google.com/?q=Kansas+City,+Missouri',
    addressLine1: '2800 Rockcreek Parkway',
    city: 'Kansas City',
    state: 'Missouri',
    postalCode: '64117',
    country: 'United States',
    companyPhone: '+1 (816) 555-0120',
    directNumber: '+1 (816) 555-0144',
    otherNumber: '+1 (816) 555-0199',
    phoneType: 'corporate',
    employeeSize: '10,001+ employees',
    industryType: 'Hospital & Healthcare IT',
    revenueSize: '$1B+',
    jobTitleUrl: 'https://linkedin.com/in/davidfeinberg',
    companyUrl: 'https://oracle.com/health',
    revenueSizeLink: 'https://finance.yahoo.com/quote/ORCL',
    sicCode: '7373',
    naicsCode: '541512',
    sicCodeUrl: 'https://siccode.com/sic-code/7373',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541512',
    comment1: 'Former Geisinger Health CEO & Google Health VP',
    comment2: 'Enterprise Cloud Transformation Account',
    domain: 'oracle.com',
    technologies: ['Oracle', 'AWS', 'Docker', 'Kubernetes'],
  },
  {
    id: 'lead_ent_009',
    uploadDate: '2026-10-05',
    leadType: 'Cloud Infrastructure',
    firstName: 'Sarah',
    lastName: 'Chen',
    fullName: 'Sarah Chen',
    emailAddress: 'sarah.chen@cloudscale.io',
    emailStatus: 'Valid',
    jobTitle: 'VP of Engineering & Technical Systems',
    jobLevel: 'VP',
    department: 'Engineering & Technical',
    managementLevel: 'Vp',
    companyName: 'CloudScale Infrastructure',
    addressLink: 'https://maps.google.com/?q=Seattle,+Washington',
    addressLine1: '400 Pine Street, Suite 900',
    city: 'Seattle',
    state: 'Washington',
    postalCode: '98101',
    country: 'United States',
    companyPhone: '+1 (206) 555-0112',
    directNumber: '+1 (206) 555-0189',
    otherNumber: '',
    phoneType: 'mobile',
    employeeSize: '51-200 employees',
    industryType: 'Cloud Computing & DevOps',
    revenueSize: '$10M to $25M',
    jobTitleUrl: 'https://linkedin.com/in/sarahchen-dev',
    companyUrl: 'https://cloudscale.io',
    revenueSizeLink: 'https://crunchbase.com/organization/cloudscale',
    sicCode: '7371',
    naicsCode: '541511',
    sicCodeUrl: 'https://siccode.com/sic-code/7371',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541511',
    comment1: 'Kubernetes contributor and speaker',
    comment2: 'High infrastructure budget',
    domain: 'cloudscale.io',
    technologies: ['AWS', 'Docker', 'Kubernetes', 'Python', 'React'],
  },
  {
    id: 'lead_ent_010',
    uploadDate: '2026-10-06',
    leadType: 'FinTech Growth',
    firstName: 'Marcus',
    lastName: 'Vance',
    fullName: 'Marcus Vance',
    emailAddress: 'mvance@paystream.com',
    emailStatus: 'Invalid',
    jobTitle: 'Head of Product Management',
    jobLevel: 'Head',
    department: 'Product',
    managementLevel: 'Head',
    companyName: 'PayStream Global',
    addressLink: 'https://maps.google.com/?q=Chicago,+Illinois',
    addressLine1: '233 S Wacker Dr, Suite 4400',
    city: 'Chicago',
    state: 'Illinois',
    postalCode: '60606',
    country: 'United States',
    companyPhone: '+1 (312) 555-0145',
    directNumber: '',
    otherNumber: '',
    phoneType: 'corporate',
    employeeSize: '201-500 employees',
    industryType: 'Financial Technology & Payments',
    revenueSize: '$25M to $50M',
    jobTitleUrl: 'https://linkedin.com/in/marcusvance',
    companyUrl: 'https://paystream.com',
    revenueSizeLink: 'https://crunchbase.com/organization/paystream',
    sicCode: '6099',
    naicsCode: '522320',
    sicCodeUrl: 'https://siccode.com/sic-code/6099',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=522320',
    comment1: 'Product roadmap leader',
    comment2: 'Evaluating billing engines',
    domain: 'paystream.com',
    technologies: ['Stripe', 'React', 'Node.js', 'PostgreSQL'],
  },
  {
    id: 'lead_ent_011',
    uploadDate: '2026-10-06',
    leadType: 'Enterprise Sales',
    firstName: 'Elena',
    lastName: 'Rostova',
    fullName: 'Elena Rostova',
    emailAddress: 'elena@cyberdefend.com',
    emailStatus: 'Valid',
    jobTitle: 'Head of Global Enterprise Sales',
    jobLevel: 'Head',
    department: 'Sales',
    managementLevel: 'Head',
    companyName: 'CyberDefend Security',
    addressLink: 'https://maps.google.com/?q=Austin,+Texas',
    addressLine1: '500 W 2nd St, Floor 18',
    city: 'Austin',
    state: 'Texas',
    postalCode: '78701',
    country: 'United States',
    companyPhone: '+1 (512) 555-0178',
    directNumber: '+1 (512) 555-0199',
    otherNumber: '+1 (512) 555-0160',
    phoneType: 'mobile',
    employeeSize: '1,001-5,000 employees',
    industryType: 'Computer & Network Security',
    revenueSize: '100000000',
    jobTitleUrl: 'https://linkedin.com/in/elenarostova',
    companyUrl: 'https://cyberdefend.com',
    revenueSizeLink: 'https://bloomberg.com/profile/company/CYBERDEFEND',
    sicCode: '7373',
    naicsCode: '541519',
    sicCodeUrl: 'https://siccode.com/sic-code/7373',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541519',
    comment1: 'Global channel partnership focus',
    comment2: 'High growth quota carrier',
    domain: 'cyberdefend.com',
    technologies: ['Salesforce', 'Slack', 'HubSpot', 'Zoom'],
  },
  {
    id: 'lead_ent_012',
    uploadDate: '2026-10-06',
    leadType: 'People & Culture',
    firstName: 'Jessica',
    lastName: 'Miller',
    fullName: 'Jessica Miller',
    emailAddress: 'jessica.m@edulearn.org',
    emailStatus: 'Catch-All',
    jobTitle: 'Director of Human Resources & Talent',
    jobLevel: 'Director',
    department: 'Human Resources',
    managementLevel: 'Director',
    companyName: 'EduLearn Global Foundation',
    addressLink: 'https://maps.google.com/?q=Boston,+Massachusetts',
    addressLine1: '100 Federal Street, Suite 1200',
    city: 'Boston',
    state: 'Massachusetts',
    postalCode: '02110',
    country: 'United States',
    companyPhone: '+1 (617) 555-0133',
    directNumber: '+1 (617) 555-0166',
    otherNumber: '',
    phoneType: 'corporate',
    employeeSize: '51-200 employees',
    industryType: 'Education Management & E-learning',
    revenueSize: '$10M to $25M',
    jobTitleUrl: 'https://linkedin.com/in/jessicamiller-hr',
    companyUrl: 'https://edulearn.org',
    revenueSizeLink: 'https://charitynavigator.org/ein/edulearn',
    sicCode: '8299',
    naicsCode: '611710',
    sicCodeUrl: 'https://siccode.com/sic-code/8299',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=611710',
    comment1: 'Talent acquisition head',
    comment2: 'Recruiting ATS software trial',
    domain: 'edulearn.org',
    technologies: ['Microsoft 365', 'Slack', 'Zoom'],
  },
  {
    id: 'lead_ent_013',
    uploadDate: '2026-10-07',
    leadType: 'Software Engineering',
    firstName: 'Rajesh',
    lastName: 'Sharma',
    fullName: 'Rajesh Sharma',
    emailAddress: 'rsharma@techspherepune.in',
    emailStatus: 'Valid',
    jobTitle: 'VP Technology & Engineering',
    jobLevel: 'VP',
    department: 'Engineering & Technical',
    managementLevel: 'Vp',
    companyName: 'TechSphere Solutions India',
    addressLink: 'https://maps.google.com/?q=Magarpatta+Cybercity,+Pune,+Maharashtra,+India',
    addressLine1: 'Tower 4, Magarpatta Cybercity, Hadapsar',
    city: 'Pune',
    state: 'Maharashtra',
    postalCode: '411028',
    country: 'India',
    companyPhone: '+91 20 6712 4000',
    directNumber: '+91 98230 45678',
    otherNumber: '+91 20 6712 4001',
    phoneType: 'corporate',
    employeeSize: '501-1,000 employees',
    industryType: 'Information Technology & Cloud Services',
    revenueSize: '$25M to $50M',
    jobTitleUrl: 'https://linkedin.com/in/rajeshsharma-pune',
    companyUrl: 'https://techspherepune.in',
    revenueSizeLink: 'https://zaubacorp.com/company/TECHSPHERE-SOLUTIONS',
    sicCode: '7371',
    naicsCode: '541511',
    sicCodeUrl: 'https://siccode.com/sic-code/7371',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541511',
    comment1: 'Cloud migration leader & offshore center head',
    comment2: 'Evaluating enterprise DevOps platforms',
    domain: 'techspherepune.in',
    technologies: ['AWS', 'React', 'Node.js', 'PostgreSQL', 'Docker'],
  },
  {
    id: 'lead_ent_014',
    uploadDate: '2026-10-07',
    leadType: 'European SaaS',
    firstName: 'Pierre',
    lastName: 'Dubois',
    fullName: 'Pierre Dubois',
    emailAddress: 'pierre.dubois@luminadata.fr',
    emailStatus: 'Valid',
    jobTitle: 'Managing Director France & EMEA',
    jobLevel: 'Managing Director',
    department: 'Operations',
    managementLevel: 'Director',
    companyName: 'Lumina Data Paris',
    addressLink: 'https://maps.google.com/?q=Paris,+France',
    addressLine1: '28 Boulevard Haussmann',
    city: 'Paris',
    state: 'Île-de-France',
    postalCode: '75009',
    country: 'France',
    companyPhone: '+33 1 42 68 55 00',
    directNumber: '+33 6 12 34 56 78',
    otherNumber: '',
    phoneType: 'mobile',
    employeeSize: '51-200 employees',
    industryType: 'Enterprise Software & Analytics',
    revenueSize: '10000000',
    jobTitleUrl: 'https://linkedin.com/in/pierredubois-paris',
    companyUrl: 'https://luminadata.fr',
    revenueSizeLink: 'https://societe.com/societe/lumina-data',
    sicCode: '7372',
    naicsCode: '511210',
    sicCodeUrl: 'https://siccode.com/sic-code/7372',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=511210',
    comment1: 'European market growth architect',
    comment2: 'GDPR compliance certified lead',
    domain: 'luminadata.fr',
    technologies: ['Salesforce', 'HubSpot', 'Google Analytics'],
  },
  {
    id: 'lead_ent_015',
    uploadDate: '2026-10-07',
    leadType: 'Silicon Valley AI',
    firstName: 'Patricia',
    lastName: 'Chen',
    fullName: 'Patricia Chen',
    emailAddress: 'patricia@paloaltocloud.com',
    emailStatus: 'Valid',
    jobTitle: 'Head of Product Strategy',
    jobLevel: 'Head',
    department: 'Product',
    managementLevel: 'Head',
    companyName: 'Palo Alto Cloud Intelligence',
    addressLink: 'https://maps.google.com/?q=Palo+Alto,+California',
    addressLine1: '3000 El Camino Real, Building 4',
    city: 'Palo Alto',
    state: 'California',
    postalCode: '94306',
    country: 'United States',
    companyPhone: '+1 (650) 555-0188',
    directNumber: '+1 (650) 555-0125',
    otherNumber: '',
    phoneType: 'corporate',
    employeeSize: '51-200 employees',
    industryType: 'Artificial Intelligence & Machine Learning',
    revenueSize: '$10M to $25M',
    jobTitleUrl: 'https://linkedin.com/in/patriciachen-pa',
    companyUrl: 'https://paloaltocloud.com',
    revenueSizeLink: 'https://crunchbase.com/organization/palo-alto-cloud',
    sicCode: '7373',
    naicsCode: '541519',
    sicCodeUrl: 'https://siccode.com/sic-code/7373',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=541519',
    comment1: 'Stanford Alum, AI research lead',
    comment2: 'Seed stage to Series B scaling',
    domain: 'paloaltocloud.com',
    technologies: ['Python', 'AWS', 'PostgreSQL', 'Kubernetes'],
  },
  {
    id: 'lead_ent_016',
    uploadDate: '2026-10-07',
    leadType: 'Desert Logistics',
    firstName: 'Philip',
    lastName: 'Evans',
    fullName: 'Philip Evans',
    emailAddress: 'pevans@phoenixsupply.com',
    emailStatus: 'Valid',
    jobTitle: 'Chief Operating Officer',
    jobLevel: 'COO / C-Level',
    department: 'Operations',
    managementLevel: 'C suite',
    companyName: 'Phoenix Supply & Logistics Group',
    addressLink: 'https://maps.google.com/?q=Phoenix,+Arizona',
    addressLine1: '2400 E Camelback Rd, Suite 700',
    city: 'Phoenix',
    state: 'Arizona',
    postalCode: '85016',
    country: 'United States',
    companyPhone: '+1 (602) 555-0144',
    directNumber: '+1 (602) 555-0192',
    otherNumber: '',
    phoneType: 'corporate',
    employeeSize: '201-500 employees',
    industryType: 'Logistics & Supply Chain Management',
    revenueSize: '$50M to $100M',
    jobTitleUrl: 'https://linkedin.com/in/philipevans-phx',
    companyUrl: 'https://phoenixsupply.com',
    revenueSizeLink: 'https://bloomberg.com/profile/company/PHXSUPPLY',
    sicCode: '4213',
    naicsCode: '484121',
    sicCodeUrl: 'https://siccode.com/sic-code/4213',
    naicsCodeUrl: 'https://naics.com/naics-code-description/?code=484121',
    comment1: 'Southwest distribution hub manager',
    comment2: 'Fleet management software deployment',
    domain: 'phoenixsupply.com',
    technologies: ['Oracle', 'Microsoft 365', 'Salesforce'],
  },
];

/**
 * Initializes the database:
 * - Creates standard users (Admin, Data Manager, Employee)
 * - Seeds 31-column lead dataset
 * - Initializes column definitions with unique values
 * - Initializes employee field visibility rules
 */
export async function initializeEnterpriseDatabase(): Promise<{
  leads: EnterpriseLeadRecord[];
  columns: EnterpriseColumnDef[];
  users: EnterpriseUser[];
  visibilityRules: FieldVisibilityRule[];
  filterRules?: FilterRuleConfig[];
}> {
  const db = await openEnterpriseDB();

  // 1. Users
  const existingUsers = await getAllUsers(db);
  if (existingUsers.length === 0) {
    await saveBatch(db, 'users', INITIAL_USERS);
  }
  const users = await getAllUsers(db);

  // 2. Leads: Authoritative database records from backend API /api/leads
  let leads: EnterpriseLeadRecord[] = [];
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    const res = await fetch('/api/leads?limit=500000', {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const payload = await res.json();
      if (payload.data && Array.isArray(payload.data)) {
        leads = payload.data;
        await clearStore(db, 'leads');
        if (leads.length > 0) {
          await saveBatch(db, 'leads', leads);
        }
      }
    }
  } catch {
    // Offline fallback to IndexedDB cache
    leads = await getAllLeads(db);
  }

  if (leads.length === 0) {
    leads = await getAllLeads(db);
  }

  // 3. Columns: Load from backend /api/columns (Admin-configured series order)
  let baseCols: any[] = [];
  try {
    const colRes = await fetch('/api/columns');
    if (colRes.ok) {
      const colPayload = await colRes.json();
      if (colPayload.columns && Array.isArray(colPayload.columns) && colPayload.columns.length > 0) {
        baseCols = colPayload.columns;
      }
    }
  } catch {
    // fallback
  }

  if (baseCols.length === 0) {
    const cachedCols = await getAllColumns(db);
    baseCols = cachedCols.length > 0 ? cachedCols : STANDARD_31_COLUMNS;
  }

  const computed = computeColumnsWithUniqueValues(baseCols, leads);
  await clearStore(db, 'columns');
  await saveBatch(db, 'columns', computed);
  const columns = computed.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));

  // 4. Visibility Rules: Always sync with backend
  let visibilityRules: FieldVisibilityRule[] = [];
  try {
    const visRes = await fetch('/api/visibility-rules');
    if (visRes.ok) {
      const visPayload = await visRes.json();
      if (visPayload.rules && Array.isArray(visPayload.rules) && visPayload.rules.length > 0) {
        visibilityRules = visPayload.rules;
        await clearStore(db, 'visibilityRules');
        await saveBatch(db, 'visibilityRules', visibilityRules);
      }
    }
  } catch {
    // fallback
  }

  if (visibilityRules.length === 0) {
    const cachedRules = await getAllFromStore<FieldVisibilityRule>(db, 'visibilityRules');
    if (cachedRules.length > 0) {
      visibilityRules = cachedRules;
    } else {
      await saveBatch(db, 'visibilityRules', INITIAL_VISIBILITY_RULES);
      visibilityRules = INITIAL_VISIBILITY_RULES;
    }
  }

  // 5. Filter Rules (Admin-controlled filter visibility)
  const filterRules = await getFilterRules(db);

  return { leads, columns, users, visibilityRules, filterRules };
}

export async function getAllLeads(db?: IDBDatabase): Promise<EnterpriseLeadRecord[]> {
  const database = db || (await openEnterpriseDB());
  return getAllFromStore<EnterpriseLeadRecord>(database, 'leads');
}

export async function getAllUsers(db?: IDBDatabase): Promise<EnterpriseUser[]> {
  const database = db || (await openEnterpriseDB());
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    const res = await fetch('/api/admin/users', {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.users)) {
        for (const u of data.users) {
          await putInStore(database, 'users', u).catch(() => {});
        }
        return data.users;
      }
    }
  } catch (err) {
    console.warn('Could not fetch users directly from server DB:', err);
  }
  return getAllFromStore<EnterpriseUser>(database, 'users');
}

export async function getAllColumns(db?: IDBDatabase): Promise<EnterpriseColumnDef[]> {
  const database = db || (await openEnterpriseDB());
  const cols = await getAllFromStore<EnterpriseColumnDef>(database, 'columns');
  return cols.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
}

/**
 * Admin Action: Update column ordering & employee visibility
 * Persists to IndexedDB and syncs to backend /api/admin/columns
 */
export async function updateColumnOrderAndVisibility(
  updatedColumns: EnterpriseColumnDef[]
): Promise<EnterpriseColumnDef[]> {
  const db = await openEnterpriseDB();
  
  // Re-index orders strictly 1..N
  const ordered = updatedColumns.map((c, i) => ({
    ...c,
    order: i + 1,
    employeeVisible: c.employeeVisible !== false,
  }));

  await clearStore(db, 'columns');
  await saveBatch(db, 'columns', ordered);

  // Sync with backend API
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/admin/columns', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ columns: ordered }),
    });
  } catch (err) {
    console.warn('[enterpriseDb] Backend column sync skipped:', err);
  }

  return ordered;
}

/**
 * Admin Action: Reorder single column forward (UP/LEFT) or backward (DOWN/RIGHT)
 */
export async function reorderColumn(
  columnKey: string,
  direction: 'UP' | 'DOWN' | 'TOP' | 'BOTTOM'
): Promise<EnterpriseColumnDef[]> {
  const db = await openEnterpriseDB();
  const current = await getAllColumns(db);
  const idx = current.findIndex((c) => c.key === columnKey);
  if (idx === -1) return current;

  const next = [...current];
  const [target] = next.splice(idx, 1);

  if (direction === 'TOP') {
    next.unshift(target);
  } else if (direction === 'BOTTOM') {
    next.push(target);
  } else if (direction === 'UP' && idx > 0) {
    next.splice(idx - 1, 0, target);
  } else if (direction === 'DOWN' && idx < next.length) {
    next.splice(idx + 1, 0, target);
  } else {
    next.splice(idx, 0, target);
  }

  return updateColumnOrderAndVisibility(next);
}

/**
 * Admin Action: Toggle Employee Visibility for a Column
 */
export async function toggleColumnEmployeeVisibility(
  columnKey: string
): Promise<EnterpriseColumnDef[]> {
  const db = await openEnterpriseDB();
  const current = await getAllColumns(db);
  const updated = current.map((c) => {
    if (c.key === columnKey) {
      return { ...c, employeeVisible: c.employeeVisible === false ? true : false };
    }
    return c;
  });

  return updateColumnOrderAndVisibility(updated);
}

/**
 * Admin Action: Reset Column Order to Standard Default (1 to 31)
 */
export async function resetColumnOrderToDefault(): Promise<EnterpriseColumnDef[]> {
  const db = await openEnterpriseDB();
  const current = await getAllColumns(db);
  const leads = await getAllLeads(db);

  const defaultOrdered = STANDARD_31_COLUMNS.map((std, i) => {
    const existing = current.find((c) => c.key === std.key);
    return {
      ...(existing || {
        key: std.key,
        label: std.label,
        isCore: true,
        visible: true,
        type: std.type,
        uniqueValues: [],
      }),
      order: i + 1,
      employeeVisible: true,
    };
  });

  const computed = computeColumnsWithUniqueValues(defaultOrdered, leads);
  return updateColumnOrderAndVisibility(computed);
}

export async function getFieldVisibilityRules(db?: IDBDatabase): Promise<FieldVisibilityRule[]> {
  const database = db || (await openEnterpriseDB());
  try {
    const res = await fetch('/api/visibility-rules');
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.rules) && data.rules.length > 0) {
        await clearStore(database, 'visibilityRules');
        await saveBatch(database, 'visibilityRules', data.rules);
        return data.rules;
      }
    }
  } catch (err) {
    console.warn('Could not fetch visibility rules from server:', err);
  }
  return getAllFromStore<FieldVisibilityRule>(database, 'visibilityRules');
}

/**
 * Filter Rules Management (Admin-Controlled Filter Settings)
 * Fetches authoritative settings from PostgreSQL / backend with disk persistence
 */
export async function getFilterRules(db?: IDBDatabase, userRole?: string): Promise<FilterRuleConfig[]> {
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    const endpoint = userRole === 'ADMIN' ? '/api/admin/filters' : '/api/filters';
    const res = await fetch(endpoint, {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.filters)) {
        return data.filters;
      }
    }
  } catch (err) {
    console.warn('Could not fetch filter rules from server:', err);
  }

  // Fallback to DEFAULT_FILTER_RULES
  if (userRole === 'ADMIN') {
    return DEFAULT_FILTER_RULES;
  }
  return DEFAULT_FILTER_RULES.filter((f) => f.enabled && f.visibleToEmployees);
}

export async function updateFilterRules(rules: FilterRuleConfig[]): Promise<FilterRuleConfig[]> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/admin/filters', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ filters: rules }),
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.message || `Failed to update filter rules (HTTP ${res.status})`);
  }

  const data = await res.json();
  return data.filters || rules;
}

export async function resetFilterRulesToDefault(): Promise<FilterRuleConfig[]> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/admin/filters/reset', {
    method: 'POST',
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  if (!res.ok) {
    throw new Error('Failed to reset filter rules');
  }

  const data = await res.json();
  return data.filters || DEFAULT_FILTER_RULES;
}

export async function getAllDownloadLogs(db?: IDBDatabase): Promise<DownloadAuditLog[]> {
  const database = db || (await openEnterpriseDB());
  const logs = await getAllFromStore<DownloadAuditLog>(database, 'downloadLogs');
  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

/**
 * Admin Action: Create New User / Employee
 * Directly persists to Server Database (data/users_db.json) and syncs locally
 */
export async function createEnterpriseUser(
  user: Omit<EnterpriseUser, 'id' | 'created_at' | 'last_login_at'> & { password?: string; temporary_password?: string }
): Promise<EnterpriseUser> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  
  // 1. Direct Server Database Persistence
  try {
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        email: user.email,
        username: user.username,
        full_name: user.full_name,
        role: user.role,
        password: user.password || user.temporary_password || 'Password@123',
      }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.message || `Failed to create user (HTTP ${res.status})`);
    }

    const data = await res.json();
    if (data.success && data.user) {
      const db = await openEnterpriseDB();
      const serverUser: EnterpriseUser = {
        id: data.user.id,
        email: data.user.email,
        username: data.user.username,
        full_name: data.user.full_name,
        role: data.user.role,
        status: data.user.status,
        created_at: data.user.created_at,
        last_login_at: data.user.last_login_at,
      };
      await putInStore(db, 'users', serverUser);
      return serverUser;
    }
  } catch (err: any) {
    console.error('Failed to save user directly to server DB:', err);
    throw err;
  }

  // Fallback local creation if completely disconnected
  const db = await openEnterpriseDB();
  const newUser: EnterpriseUser = {
    ...user,
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    status: user.status || 'ACTIVE',
    created_at: new Date().toISOString(),
    last_login_at: null,
  };
  await putInStore(db, 'users', newUser);
  return newUser;
}

/**
 * Admin Action: Block or Unblock Employee
 */
export async function toggleBlockUser(userId: string): Promise<EnterpriseUser | null> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const db = await openEnterpriseDB();

  try {
    const res = await fetch(`/api/admin/users/${userId}/toggle-block`, {
      method: 'PATCH',
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.user) {
        await putInStore(db, 'users', data.user);
        return data.user;
      }
    }
  } catch (err) {
    console.warn('Server toggle block failed, updating local fallback:', err);
  }

  const users = await getAllUsers(db);
  const target = users.find((u) => u.id === userId);
  if (!target) return null;

  const updated: EnterpriseUser = {
    ...target,
    status: target.status === 'ACTIVE' ? 'BLOCKED' : 'ACTIVE',
  };

  await putInStore(db, 'users', updated);
  return updated;
}

/**
 * Admin Action: Delete User
 */
export async function deleteEnterpriseUser(userId: string): Promise<boolean> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const db = await openEnterpriseDB();

  try {
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: 'DELETE',
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      await deleteFromStore(db, 'users', userId);
      return true;
    }
  } catch (err) {
    console.warn('Server delete failed, updating local store:', err);
  }

  return deleteFromStore(db, 'users', userId);
}

/**
 * Admin Action: Reset User Password
 */
export async function resetEnterpriseUserPassword(
  userId: string,
  newPassword?: string
): Promise<{ success: boolean; message: string; new_password?: string }> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');

  const res = await fetch(`/api/admin/users/${userId}/reset-password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ new_password: newPassword }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Failed to reset password (HTTP ${res.status})`);
  }

  return data;
}

/**
 * Admin Action: Update Employee/User Profile (Name, Email, Username, Role, Status, and Password)
 */
export async function updateEnterpriseUser(
  userId: string,
  payload: {
    full_name?: string;
    email?: string;
    username?: string;
    role?: 'ADMIN' | 'DATA_MANAGER' | 'EMPLOYEE';
    status?: 'ACTIVE' | 'BLOCKED';
    new_password?: string;
  }
): Promise<{ success: boolean; message: string; user: EnterpriseUser }> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch(`/api/admin/users/${userId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Failed to update user profile (HTTP ${res.status})`);
  }

  // Update local IndexedDB cache
  try {
    const db = await openEnterpriseDB();
    if (data.user) {
      await putInStore(db, 'users', data.user);
    }
  } catch (err) {
    console.warn('Failed to update local user store:', err);
  }

  return data;
}

/**
 * Admin Action: Fetch Login History for a specific User
 */
export async function getUserLoginHistory(
  userId: string
): Promise<Array<{ id: string; user_id: string; email: string; role: string; ip_address: string; user_agent?: string; status: string; created_at: string }>> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch(`/api/admin/users/${userId}/logins`, {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  if (!res.ok) {
    return [];
  }

  const data = await res.json().catch(() => ({}));
  return Array.isArray(data.logins) ? data.logins : [];
}

/**
 * Self-Service Profile Update (Name, Email, Password)
 */
export async function updateCurrentUserProfile(payload: {
  full_name?: string;
  email?: string;
  current_password?: string;
  new_password?: string;
}): Promise<{ success: boolean; message: string; user: EnterpriseUser }> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/auth/profile', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Failed to update profile (HTTP ${res.status})`);
  }

  return data;
}

/**
 * Export Governance & Limit Controls
 */
export async function getExportGovernanceSettings(): Promise<ExportGovernanceSettings> {
  try {
    const res = await fetch('/api/exports/settings');
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.settings) {
        return data.settings;
      }
    }
  } catch (err) {
    console.warn('Could not fetch export settings:', err);
  }
  return {
    employeeMaxDownloadLimit: 10000,
    requireApprovalAboveLimit: true,
    allowEmployeeDownload: true,
  };
}

export async function updateExportGovernanceSettings(
  settings: Partial<ExportGovernanceSettings>
): Promise<ExportGovernanceSettings> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/admin/exports/settings', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(settings),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || 'Failed to update export governance policy');
  }
  const data = await res.json();
  return data.settings;
}

export async function validateExportLimit(recordCount: number): Promise<{
  allowed: boolean;
  requiresApproval: boolean;
  reason?: string;
  message?: string;
  limit: number;
  requestedCount?: number;
}> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  try {
    const res = await fetch('/api/exports/validate-limit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ recordCount }),
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('Validate limit API call failed:', err);
  }
  const defaultLimit = 10000;
  if (recordCount > defaultLimit) {
    return {
      allowed: false,
      requiresApproval: true,
      reason: 'EXCEEDS_LIMIT',
      message: `Requested ${recordCount.toLocaleString()} leads exceeds employee download quota (${defaultLimit.toLocaleString()}). Administrator approval required.`,
      limit: defaultLimit,
      requestedCount: recordCount,
    };
  }
  return { allowed: true, requiresApproval: false, limit: defaultLimit, requestedCount: recordCount };
}

export async function submitExportApprovalRequest(payload: {
  requestedCount: number;
  fileFormat: 'CSV' | 'XLSX';
  campaign_name?: string;
  reason: string;
  filtersSummary?: string;
  filtersSnapshot?: any;
}): Promise<ExportApprovalRequest> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/exports/request-approval', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || 'Failed to submit export approval request');
  }
  const data = await res.json();
  return data.request;
}

export async function getExportApprovalRequests(): Promise<ExportApprovalRequest[]> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  try {
    const res = await fetch('/api/exports/requests', {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const data = await res.json();
      return data.requests || [];
    }
  } catch (err) {
    console.warn('Could not fetch export requests:', err);
  }
  return [];
}

export async function reviewExportApprovalRequest(
  requestId: string,
  status: 'APPROVED' | 'REJECTED',
  admin_note?: string
): Promise<ExportApprovalRequest> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch(`/api/admin/exports/requests/${requestId}/review`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ status, admin_note }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || 'Failed to review export request');
  }
  const data = await res.json();
  return data.request;
}

/**
 * Admin Action: Update Employee Field Visibility & Masking Setting
 */
export async function updateFieldVisibilityRule(
  columnKey: string,
  visibility: 'VISIBLE' | 'MASKED' | 'HIDDEN',
  allowEmployeeDownload?: boolean
): Promise<void> {
  const db = await openEnterpriseDB();
  const rules = await getAllFromStore<FieldVisibilityRule>(db, 'visibilityRules');
  const existingIndex = rules.findIndex((r) => r.columnKey === columnKey);
  
  if (existingIndex >= 0) {
    rules[existingIndex].employeeVisibility = visibility;
    if (allowEmployeeDownload !== undefined) {
      rules[existingIndex].allowEmployeeDownload = allowEmployeeDownload;
    }
  } else {
    rules.push({
      columnKey,
      columnLabel: columnKey,
      employeeVisibility: visibility,
      enabledInTable: true,
      allowEmployeeDownload: allowEmployeeDownload ?? true,
    });
  }

  await clearStore(db, 'visibilityRules');
  await saveBatch(db, 'visibilityRules', rules);

  // Sync to backend database
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/admin/visibility-rules', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ rules }),
    });
  } catch (err) {
    console.warn('[enterpriseDb] Visibility rule backend sync skipped:', err);
  }
}

/**
 * Admin Privilege Action: Configure whether employees are permitted to export this column
 */
export async function toggleColumnEmployeeDownloadRule(
  columnKey: string,
  allowDownload: boolean
): Promise<void> {
  const db = await openEnterpriseDB();
  const rules = await getAllFromStore<FieldVisibilityRule>(db, 'visibilityRules');
  const existingIndex = rules.findIndex((r) => r.columnKey === columnKey);
  
  if (existingIndex >= 0) {
    rules[existingIndex].allowEmployeeDownload = allowDownload;
  } else {
    rules.push({
      columnKey,
      columnLabel: columnKey,
      employeeVisibility: 'VISIBLE',
      enabledInTable: true,
      allowEmployeeDownload: allowDownload,
    });
  }

  await clearStore(db, 'visibilityRules');
  await saveBatch(db, 'visibilityRules', rules);

  // Sync to backend database
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/admin/visibility-rules', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ rules }),
    });
  } catch (err) {
    console.warn('[enterpriseDb] Column download rule backend sync skipped:', err);
  }
}

/**
 * Audit Logging: Record Download Event
 */
export async function recordDownloadAuditLog(
  log: Omit<DownloadAuditLog, 'id' | 'timestamp'>
): Promise<DownloadAuditLog> {
  const db = await openEnterpriseDB();
  const newLog: DownloadAuditLog = {
    ...log,
    id: `log_dl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
  };

  await putInStore(db, 'downloadLogs', newLog);
  return newLog;
}

export interface IngestEnterpriseOptions {
  datasetName?: string;
  importMode?: 'APPEND' | 'UPDATE' | 'REPLACE';
  duplicateStrategy?: 'email' | 'phone' | 'full_row';
  handleDuplicates?: 'SKIP' | 'UPDATE' | 'IMPORT_ALL';
  replaceExisting?: boolean;
}

/**
 * Universal Ingest File (CSV, XLSX, XLS, TSV, TXT, JSON) directly through authoritative Backend
 * Enforces PostgreSQL / backend database as single source of truth.
 * APPEND is the default mode to preserve existing records.
 */
export async function ingestEnterpriseFile(
  file: File,
  options?: IngestEnterpriseOptions
): Promise<{
  addedCount: number;
  leads: EnterpriseLeadRecord[];
  columns: EnterpriseColumnDef[];
  stats?: any;
  message?: string;
}> {
  if (!file) {
    throw new Error('No file provided for database ingestion.');
  }

  const importMode = options?.importMode || (options?.replaceExisting ? 'REPLACE' : 'APPEND');
  const duplicateStrategy = options?.duplicateStrategy || 'email';
  const handleDuplicates = options?.handleDuplicates || 'SKIP';
  const datasetName = options?.datasetName || file.name.replace(/\.[^/.]+$/, '');

  // 1. Authoritative Backend Upload (Multipart form to /api/uploads/confirm)
  const formData = new FormData();
  formData.append('file', file);
  formData.append('dataset_name', datasetName);
  formData.append('import_mode', importMode);
  formData.append('duplicate_strategy', duplicateStrategy);
  formData.append('handle_duplicates', handleDuplicates);

  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');

  const res = await fetch('/api/uploads/confirm', {
    method: 'POST',
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: formData,
  });

  const resData = await res.json().catch(() => ({}));

  if (!res.ok || !resData.success) {
    const errorMsg = resData.message || resData.error || `Database ingestion failed with HTTP ${res.status}`;
    throw new Error(errorMsg);
  }

  // 2. Fetch authoritative database leads & columns directly from backend
  const leadsRes = await fetch('/api/leads?limit=500000', {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  let freshLeads: EnterpriseLeadRecord[] = [];
  let freshColumns: EnterpriseColumnDef[] = [];

  if (leadsRes.ok) {
    const leadsJson = await leadsRes.json();
    freshLeads = leadsJson.data || leadsJson.items || [];
    freshColumns = leadsJson.columns || [];
  }

  // 3. Sync client IndexedDB cache with verified database records
  const db = await openEnterpriseDB();
  if (freshLeads.length > 0) {
    await clearStore(db, 'leads');
    await saveBatch(db, 'leads', freshLeads);
  }
  if (freshColumns.length > 0) {
    await clearStore(db, 'columns');
    await saveBatch(db, 'columns', freshColumns);
  }

  const addedCount = resData.stats?.valid_rows ?? (resData.stats?.added_rows ?? freshLeads.length);

  return {
    addedCount,
    leads: freshLeads,
    columns: freshColumns,
    stats: resData.stats,
    message: resData.message,
  };
}

function formatHeaderLabel(key: string): string {
  // If already contains spaces or special cases
  if (key.includes(' ') || key.includes('-')) {
    return key
      .split(/[\s-_]+/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

function detectFieldType(key: string, sampleVal: any): EnterpriseColumnDef['type'] {
  const k = key.toLowerCase();
  if (k.includes('email') || k.includes('mail')) return 'email';
  if (k.includes('phone') || k.includes('mobile') || k.includes('tel') || k.includes('fax')) return 'phone';
  if (k.includes('url') || k.includes('link') || k.includes('website') || k.includes('domain') || k.includes('http')) return 'url';
  if (typeof sampleVal === 'number' || (!isNaN(Number(sampleVal)) && sampleVal !== '' && !k.includes('zip') && !k.includes('code') && !k.includes('phone'))) {
    return 'number';
  }
  return 'text';
}

async function processAndStoreRawRows(
  rawRows: Record<string, any>[],
  fileName: string,
  replaceExisting = false
): Promise<{ addedCount: number; leads: EnterpriseLeadRecord[]; columns: EnterpriseColumnDef[] }> {
  const db = await openEnterpriseDB();
  const existingLeads = await getAllLeads(db);
  const existingColumns = await getAllColumns(db);

  if (rawRows.length === 0) {
    return { addedCount: 0, leads: existingLeads, columns: existingColumns };
  }

  const rawHeaders = Object.keys(rawRows[0] || {});
  const headerMap: Record<string, string> = {};

  // Standard key normalization aliases
  for (const header of rawHeaders) {
    const norm = header.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    let matchedKey: string = header.trim();

    if (norm === 'uploaddate' || norm === 'date') matchedKey = 'uploadDate';
    else if (norm === 'leadtype' || norm === 'type') matchedKey = 'leadType';
    else if (norm === 'firstname' || norm === 'fname') matchedKey = 'firstName';
    else if (norm === 'lastname' || norm === 'lname') matchedKey = 'lastName';
    else if (norm === 'emailaddress' || norm === 'email' || norm === 'emailid') matchedKey = 'emailAddress';
    else if (norm === 'emailstatus') matchedKey = 'emailStatus';
    else if (norm === 'jobtitle' || norm === 'title' || norm === 'designation' || norm === 'position') matchedKey = 'jobTitle';
    else if (norm === 'joblevel' || norm === 'level' || norm === 'seniority') matchedKey = 'jobLevel';
    else if (norm === 'companyname' || norm === 'company' || norm === 'organization' || norm === 'org') matchedKey = 'companyName';
    else if (norm === 'addresslink') matchedKey = 'addressLink';
    else if (norm === 'addressline1' || norm === 'address' || norm === 'street') matchedKey = 'addressLine1';
    else if (norm === 'city') matchedKey = 'city';
    else if (norm === 'state' || norm === 'province') matchedKey = 'state';
    else if (norm === 'postalcode' || norm === 'zipcode' || norm === 'zip') matchedKey = 'postalCode';
    else if (norm === 'country' || norm === 'nation') matchedKey = 'country';
    else if (norm === 'companyphone' || norm === 'phone' || norm === 'telephone') matchedKey = 'companyPhone';
    else if (norm === 'directnumber' || norm === 'directphone' || norm === 'mobile' || norm === 'cell') matchedKey = 'directNumber';
    else if (norm === 'othernumber' || norm === 'altphone') matchedKey = 'otherNumber';
    else if (norm === 'employeesize' || norm === 'employees' || norm === 'headcount') matchedKey = 'employeeSize';
    else if (norm === 'industrytype' || norm === 'industry' || norm === 'sector') matchedKey = 'industryType';
    else if (norm === 'revenuesize' || norm === 'revenue') matchedKey = 'revenueSize';
    else if (norm === 'jobtitleurl') matchedKey = 'jobTitleUrl';
    else if (norm === 'companyurl' || norm === 'website' || norm === 'site') matchedKey = 'companyUrl';
    else if (norm === 'revenuesizelink') matchedKey = 'revenueSizeLink';
    else if (norm === 'siccode' || norm === 'sic') matchedKey = 'sicCode';
    else if (norm === 'naicscode' || norm === 'naics') matchedKey = 'naicsCode';
    else if (norm === 'siccodeurl') matchedKey = 'sicCodeUrl';
    else if (norm === 'naicscodeurl') matchedKey = 'naicsCodeUrl';
    else if (norm === 'comment1') matchedKey = 'comment1';
    else if (norm === 'comment2') matchedKey = 'comment2';
    else if (norm === 'domain') matchedKey = 'domain';

    headerMap[header] = matchedKey;
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const newLeads: EnterpriseLeadRecord[] = [];
  const timestamp = Date.now();

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i];
    const id = `lead_up_${timestamp}_${i}`;
    const lead: EnterpriseLeadRecord = {
      id,
      uploadDate: todayStr,
      leadType: 'Ingested Dataset',
      firstName: '',
      lastName: '',
      emailAddress: '',
      emailStatus: 'Active',
      jobTitle: '',
      jobLevel: '',
      companyName: '',
      addressLink: '',
      addressLine1: '',
      city: '',
      state: '',
      postalCode: '',
      country: '',
      companyPhone: '',
      directNumber: '',
      otherNumber: '',
      employeeSize: '',
      industryType: '',
      revenueSize: '',
      jobTitleUrl: '',
      companyUrl: '',
      revenueSizeLink: '',
      sicCode: '',
      naicsCode: '',
      sicCodeUrl: '',
      naicsCodeUrl: '',
      comment1: `Uploaded via ${fileName}`,
      comment2: '',
      domain: '',
    };

    // Copy every raw field from input row with exact values
    for (const [header, val] of Object.entries(row)) {
      const targetKey = headerMap[header] || header.trim();
      const strVal = String(val ?? '').trim();
      lead[targetKey] = strVal;
    }

    if (!lead.fullName) {
      const parts = [lead.firstName, lead.lastName].filter(Boolean);
      lead.fullName = parts.length > 0 ? parts.join(' ') : (lead.companyName || 'Prospect Lead');
    }

    if (!lead.domain && lead.companyUrl) {
      try {
        const u = new URL(lead.companyUrl.startsWith('http') ? lead.companyUrl : `https://${lead.companyUrl}`);
        lead.domain = u.hostname.replace(/^www\./, '');
      } catch {
        lead.domain = lead.companyUrl;
      }
    }

    newLeads.push(lead);
  }

  if (replaceExisting) {
    await clearStore(db, 'leads');
  }

  const finalLeads = replaceExisting ? newLeads : [...newLeads, ...existingLeads];
  await saveBatch(db, 'leads', finalLeads);

  // Dynamically detect ALL column keys present in the dataset (No 31-column hardcoded restriction!)
  const allDataKeys = new Set<string>();
  for (const lead of finalLeads) {
    for (const k of Object.keys(lead)) {
      if (k !== 'id') allDataKeys.add(k);
    }
  }

  // Build map of existing column definitions to preserve admin customization
  const existingMap = new Map<string, EnterpriseColumnDef>(existingColumns.map((c) => [c.key, c]));
  let nextOrder = 1;
  const dynamicCols: EnterpriseColumnDef[] = [];

  for (const key of allDataKeys) {
    const existing = existingMap.get(key);
    const sampleVal = finalLeads[0]?.[key];
    const uniqueValuesSet = new Set<string>();

    for (const l of finalLeads) {
      const v = String(l[key] ?? '').trim();
      if (v) uniqueValuesSet.add(v);
      if (uniqueValuesSet.size >= 50) break; // Keep sample unique values concise
    }

    if (existing) {
      dynamicCols.push({
        ...existing,
        order: existing.order ?? nextOrder++,
        uniqueValues: Array.from(uniqueValuesSet).sort(),
      });
    } else {
      dynamicCols.push({
        key,
        label: formatHeaderLabel(key),
        isCore: ['firstName', 'lastName', 'emailAddress', 'companyName', 'jobTitle'].includes(key),
        visible: true,
        employeeVisible: true,
        order: nextOrder++,
        type: detectFieldType(key, sampleVal),
        uniqueValues: Array.from(uniqueValuesSet).sort(),
      });
    }
  }

  // Sort columns strictly by configured order
  dynamicCols.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));

  await clearStore(db, 'columns');
  await saveBatch(db, 'columns', dynamicCols);

  // Sync with backend API storage
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/leads/upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ leads: newLeads, replaceExisting }),
    });
  } catch (err) {
    console.warn('[enterpriseDb] Backend upload sync skipped:', err);
  }

  return {
    addedCount: newLeads.length,
    leads: finalLeads,
    columns: dynamicCols,
  };
}

/**
 * Admin / Manager Action: Clear all sample/seeded demo data so database only contains real records
 */
export async function clearSampleSeedDataFromDB(): Promise<{ remainingCount: number; leads: EnterpriseLeadRecord[] }> {
  const db = await openEnterpriseDB();
  await clearStore(db, 'leads');

  // Purge backend database as well
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/data/purge', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
  } catch (err) {
    console.warn('[enterpriseDb] Backend purge sync error:', err);
  }

  return { remainingCount: 0, leads: [] };
}

/**
 * Helper to split pasted lines/commas/tabs
 */
export function parsePastedTerms(raw: string): string[] {
  return raw
    .split(/[\n,;\t]+/)
    .map((s) => s.trim().toLowerCase())
    .filter((s) => s.length > 0);
}

/**
 * Checks if at least ONE serial filter is active
 */
export function hasAnyActiveSerialFilter(filters: SerialFiltersState): boolean {
  if (filters.firstName.trim() || filters.lastName.trim()) return true;
  if (filters.emailSearch.trim()) return true;
  if (filters.addressSearch.trim()) return true;
  if (filters.selectedLocations.length > 0) return true;
  if (filters.locationQuery.trim()) return true;
  if (filters.city.trim() || filters.state.trim() || filters.postalCode.trim() || filters.country.trim()) return true;
  if (filters.addressLinkSearch.trim()) return true;
  if (filters.phoneTypes.corporate || filters.phoneTypes.mobile || filters.phoneTypes.other || filters.phoneSearch.trim()) return true;
  if (filters.jobTitlePaste.trim()) return true;
  if (filters.managementLevels && filters.managementLevels.length > 0) return true;
  if (filters.jobLevels && filters.jobLevels.length > 0) return true;
  if (filters.companyNamePaste.trim()) return true;
  if (filters.companyDomainPaste.trim()) return true;
  if (filters.employeeSizes.length > 0) return true;
  if (filters.industries.length > 0) return true;
  if (filters.revenueRanges.length > 0) return true;
  if (filters.sicNaicsSearch.trim()) return true;
  return false;
}

export interface LocationSuggestion {
  id: string;
  label: string; // e.g. "Pune, Maharashtra, India"
  city?: string;
  state?: string;
  country?: string;
  count: number;
}

/**
 * Apollo-Style Location Autocompletion Engine:
 * Generates smart suggestions for City, State, Country, or Postal Code based on real database records
 * AND provides instantaneous autocompletion across ALL 195+ world countries in the Alltake Global Registry.
 */
export function getLocationSuggestions(leads: EnterpriseLeadRecord[], rawQuery: string): LocationSuggestion[] {
  const q = rawQuery.trim().toLowerCase();
  if (!q) return [];

  const suggestionMap = new Map<string, { label: string; city?: string; state?: string; country?: string; count: number }>();

  // 1. Scan actual leads for verified matches
  for (const lead of leads) {
    const city = (lead.city || '').trim();
    const state = (lead.state || '').trim();
    const country = (lead.country || '').trim();
    const postal = (lead.postalCode || '').trim();

    // 1. Full City + State + Country format: "Pune, Maharashtra, India"
    if (city) {
      const fullLabel = [city, state, country].filter(Boolean).join(', ');
      if (
        city.toLowerCase().startsWith(q) ||
        city.toLowerCase().includes(q) ||
        fullLabel.toLowerCase().includes(q)
      ) {
        const existing = suggestionMap.get(fullLabel) || { label: fullLabel, city, state, country, count: 0 };
        existing.count++;
        suggestionMap.set(fullLabel, existing);
      }
    }

    // 2. State + Country format: "California, United States"
    if (state && !city.toLowerCase().startsWith(q)) {
      const stateLabel = [state, country].filter(Boolean).join(', ');
      if (state.toLowerCase().startsWith(q) || state.toLowerCase().includes(q)) {
        const existing = suggestionMap.get(stateLabel) || { label: stateLabel, state, country, count: 0 };
        existing.count++;
        suggestionMap.set(stateLabel, existing);
      }
    }

    // 3. Country format from lead
    if (country && (country.toLowerCase().startsWith(q) || country.toLowerCase().includes(q))) {
      const existing = suggestionMap.get(country) || { label: country, country, count: 0 };
      existing.count++;
      suggestionMap.set(country, existing);
    }

    // 4. Postal Code match
    if (postal && postal.toLowerCase().startsWith(q)) {
      const zipLabel = `${postal} (${[city, state].filter(Boolean).join(', ')})`;
      const existing = suggestionMap.get(zipLabel) || { label: zipLabel, city, state, country, count: 0 };
      existing.count++;
      suggestionMap.set(zipLabel, existing);
    }
  }

  // 2. Seamlessly scan ALL 195+ world countries from ALL_WORLD_COUNTRIES registry
  for (const country of ALL_WORLD_COUNTRIES) {
    if (country.toLowerCase().startsWith(q) || country.toLowerCase().includes(q)) {
      if (!suggestionMap.has(country)) {
        suggestionMap.set(country, { label: country, country, count: 0 });
      }
    }
  }

  // Sort by record frequency first, then alphabetically; return top 15 matches
  return Array.from(suggestionMap.entries())
    .map(([id, val]) => ({ id, ...val }))
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label))
    .slice(0, 15);
}

/**
 * Streamlined Lead Filter Evaluator matching User Requirements:
 */
export function evaluateSerialFilterMatches(
  lead: EnterpriseLeadRecord,
  filters: SerialFiltersState
): boolean {
  // 1. Name: First Name & Last Name (message area removed!)
  if (filters.firstName.trim()) {
    const q = filters.firstName.trim().toLowerCase();
    if (!lead.firstName.toLowerCase().includes(q)) return false;
  }
  if (filters.lastName.trim()) {
    const q = filters.lastName.trim().toLowerCase();
    if (!lead.lastName.toLowerCase().includes(q)) return false;
  }

  // 2. Email Address Search Bar
  if (filters.emailSearch.trim()) {
    const q = filters.emailSearch.trim().toLowerCase();
    const email = (lead.emailAddress || '').toLowerCase();
    if (!email.includes(q)) return false;
  }

  // 3. Location: Address Search & Apollo-style Suggestions & City/State/Zip/Country
  if (filters.addressSearch.trim()) {
    const q = filters.addressSearch.trim().toLowerCase();
    const addr = (lead.addressLine1 || '').toLowerCase();
    if (!addr.includes(q)) return false;
  }

  // Selected Apollo-style location tags
  if (filters.selectedLocations.length > 0) {
    const leadCity = (lead.city || '').toLowerCase();
    const leadState = (lead.state || '').toLowerCase();
    const leadCountry = (lead.country || '').toLowerCase();
    const fullCombined = `${leadCity}, ${leadState}, ${leadCountry}`.toLowerCase();

    const matchesAny = filters.selectedLocations.some((loc) => {
      const locClean = loc.toLowerCase();
      return (
        fullCombined.includes(locClean) ||
        locClean.includes(leadCity) ||
        locClean.includes(leadState) ||
        locClean.includes(leadCountry)
      );
    });
    if (!matchesAny) return false;
  }

  // Typing in location query before clicking
  if (filters.locationQuery.trim() && filters.selectedLocations.length === 0) {
    const q = filters.locationQuery.trim().toLowerCase();
    const fullLoc = `${lead.city || ''} ${lead.state || ''} ${lead.country || ''} ${lead.postalCode || ''}`.toLowerCase();
    if (!fullLoc.includes(q)) return false;
  }

  // Granular City/State/Zip/Country fields
  if (filters.city.trim()) {
    if (!(lead.city || '').toLowerCase().includes(filters.city.trim().toLowerCase())) return false;
  }
  if (filters.state.trim()) {
    if (!(lead.state || '').toLowerCase().includes(filters.state.trim().toLowerCase())) return false;
  }
  if (filters.postalCode.trim()) {
    if (!(lead.postalCode || '').toLowerCase().includes(filters.postalCode.trim().toLowerCase())) return false;
  }
  if (filters.country.trim()) {
    if (!(lead.country || '').toLowerCase().includes(filters.country.trim().toLowerCase())) return false;
  }

  // 4. Address Link Search Bar
  if (filters.addressLinkSearch.trim()) {
    const q = filters.addressLinkSearch.trim().toLowerCase();
    const link = (lead.addressLink || '').toLowerCase();
    if (!link.includes(q)) return false;
  }

  // 5. Phone Checkbox & Search
  const hasPhoneFilter =
    filters.phoneTypes.corporate || filters.phoneTypes.mobile || filters.phoneTypes.other;
  if (hasPhoneFilter) {
    let matchesPhone = false;
    if (filters.phoneTypes.corporate && (lead.companyPhone || lead.phoneType === 'corporate')) {
      matchesPhone = true;
    }
    if (filters.phoneTypes.mobile && (lead.directNumber || lead.phoneType === 'mobile')) {
      matchesPhone = true;
    }
    if (filters.phoneTypes.other && (lead.otherNumber || lead.phoneType === 'other')) {
      matchesPhone = true;
    }
    if (!matchesPhone) return false;
  }

  if (filters.phoneSearch.trim()) {
    const q = filters.phoneSearch.trim().replace(/\D/g, '');
    const combinedPhone = `${lead.companyPhone || ''} ${lead.directNumber || ''} ${lead.otherNumber || ''}`.replace(/\D/g, '');
    if (!combinedPhone.includes(q)) return false;
  }

  // 6. Job Title (Include / Exclude Paste)
  if (filters.jobTitlePaste.trim()) {
    const terms = parsePastedTerms(filters.jobTitlePaste);
    const title = (lead.jobTitle || '').toLowerCase();
    const hasMatch = terms.some((term) => title.includes(term));

    if (filters.jobTitleMode === 'include' && !hasMatch) return false;
    if (filters.jobTitleMode === 'exclude' && hasMatch) return false;
  }

  // 6B. Management Level (Unique values from database records - Director, VP, Manager, C-Suite, etc.)
  if (filters.managementLevels && filters.managementLevels.length > 0) {
    const rawVal = (lead.managementLevel || lead.jobLevel || '').trim().toLowerCase();
    const titleVal = (lead.jobTitle || '').trim().toLowerCase();
    const hasMatch = filters.managementLevels.some((ml) => {
      const mlLower = ml.trim().toLowerCase();
      if (rawVal === mlLower || rawVal.includes(mlLower)) return true;
      if (mlLower === 'director' && (titleVal.includes('director') || rawVal.includes('director'))) return true;
      if (mlLower === 'manager' && (titleVal.includes('manager') || rawVal.includes('manager'))) return true;
      if (mlLower === 'vp' && (titleVal.includes('vp') || titleVal.includes('vice president') || rawVal.includes('vp'))) return true;
      if (mlLower === 'c-suite' && (titleVal.includes('chief') || titleVal.includes('ceo') || titleVal.includes('cto') || titleVal.includes('cfo') || rawVal.includes('c suite') || rawVal.includes('c-suite') || titleVal.includes('president'))) return true;
      if (mlLower === 'head' && (titleVal.includes('head') || rawVal.includes('head'))) return true;
      return false;
    });
    if (!hasMatch) return false;
  }

  // 6C. Job Level (Seniority filter: C-Level, VP, Director, Manager, Senior, Specialist, etc.)
  if (filters.jobLevels && filters.jobLevels.length > 0) {
    const rawLevel = (lead.jobLevel || '').trim().toLowerCase();
    const rawMgmt = (lead.managementLevel || '').trim().toLowerCase();
    const rawTitle = (lead.jobTitle || '').trim().toLowerCase();

    const matchesJobLevel = filters.jobLevels.some((jl) => {
      const q = jl.trim().toLowerCase();
      if (rawLevel === q || rawLevel.includes(q)) return true;
      if (rawMgmt === q || rawMgmt.includes(q)) return true;
      if (q.includes('c-level') || q.includes('executive')) {
        return rawLevel.includes('c-') || rawTitle.includes('chief') || rawTitle.includes('ceo') || rawTitle.includes('cto') || rawTitle.includes('cfo') || rawTitle.includes('president') || rawMgmt.includes('c-suite');
      }
      if (q.includes('vp') || q.includes('vice president')) {
        return rawLevel.includes('vp') || rawTitle.includes('vp') || rawTitle.includes('vice president');
      }
      if (q.includes('director')) {
        return rawLevel.includes('director') || rawTitle.includes('director');
      }
      if (q.includes('head')) {
        return rawLevel.includes('head') || rawTitle.includes('head');
      }
      if (q.includes('manager')) {
        return rawLevel.includes('manager') || rawTitle.includes('manager');
      }
      if (q.includes('senior') || q.includes('lead')) {
        return rawLevel.includes('senior') || rawLevel.includes('lead') || rawTitle.includes('senior') || rawTitle.includes('lead');
      }
      if (q.includes('specialist') || q.includes('contributor')) {
        return rawLevel.includes('specialist') || rawLevel.includes('contributor') || rawLevel.includes('analyst');
      }
      if (q.includes('entry')) {
        return rawLevel.includes('entry') || rawLevel.includes('junior');
      }
      if (q.includes('partner')) {
        return rawLevel.includes('partner') || rawTitle.includes('partner');
      }
      if (q.includes('founder') || q.includes('owner')) {
        return rawLevel.includes('founder') || rawLevel.includes('owner') || rawTitle.includes('founder') || rawTitle.includes('owner');
      }
      return rawTitle.includes(q);
    });

    if (!matchesJobLevel) return false;
  }

  // 7. Company Name (Include / Exclude Paste)
  if (filters.companyNamePaste.trim()) {
    const terms = parsePastedTerms(filters.companyNamePaste);
    const company = (lead.companyName || '').toLowerCase();
    const hasMatch = terms.some((term) => company.includes(term));

    if (filters.companyNameMode === 'include' && !hasMatch) return false;
    if (filters.companyNameMode === 'exclude' && hasMatch) return false;
  }

  // 8. Company Domain (Include / Exclude Paste)
  if (filters.companyDomainPaste.trim()) {
    const terms = parsePastedTerms(filters.companyDomainPaste);
    const domain = (lead.domain || lead.companyUrl || '').toLowerCase();
    const hasMatch = terms.some((term) => domain.includes(term));

    if (filters.companyDomainMode === 'include' && !hasMatch) return false;
    if (filters.companyDomainMode === 'exclude' && hasMatch) return false;
  }

  // 9. Employee Size (Exact brackets + numeric range evaluation)
  if (filters.employeeSizes.length > 0) {
    if (!matchesEmployeeSizeFilter(lead.employeeSize, filters.employeeSizes)) {
      return false;
    }
  }

  // 10. Industry Type (Matches unique industry types from dataset)
  if (filters.industries.length > 0) {
    const leadInd = (lead.industryType || '').trim().toLowerCase();
    const matchesInd = filters.industries.some((ind) => {
      const target = ind.trim().toLowerCase();
      return leadInd === target || leadInd.includes(target);
    });
    if (!matchesInd) return false;
  }

  // 11. Revenue Range (Exact brackets + raw number mapping e.g. 1000000 -> 1M)
  if (filters.revenueRanges.length > 0) {
    if (!matchesRevenueFilter(lead.revenueSize, filters.revenueRanges)) {
      return false;
    }
  }

  // 12. SIC & NAICS Unified Single Search Bar
  if (filters.sicNaicsSearch.trim()) {
    const q = filters.sicNaicsSearch.trim().toLowerCase();
    const sic = (lead.sicCode || '').toLowerCase();
    const naics = (lead.naicsCode || '').toLowerCase();
    const sicUrl = (lead.sicCodeUrl || '').toLowerCase();
    const naicsUrl = (lead.naicsCodeUrl || '').toLowerCase();
    if (!sic.includes(q) && !naics.includes(q) && !sicUrl.includes(q) && !naicsUrl.includes(q)) {
      return false;
    }
  }

  return true;
}

/**
 * Aggregates statistics for Admin & Employee Lead Dashboard
 */
export function getDashboardAnalytics(leads: EnterpriseLeadRecord[]) {
  const totalLeads = leads.length;

  // Email status breakdown
  let validEmails = 0;
  let catchAllEmails = 0;
  let invalidEmails = 0;

  // Phone coverage
  let withPhone = 0;
  let withDirect = 0;

  // Department counts
  const departmentCounts: Record<string, number> = {};
  DEPARTMENT_OPTIONS.forEach((d) => (departmentCounts[d] = 0));

  // Management Level counts
  const managementLevelCounts: Record<string, number> = {};
  MANAGEMENT_LEVEL_OPTIONS.forEach((m) => (managementLevelCounts[m] = 0));

  // Employee Size counts
  const employeeSizeCounts: Record<string, number> = {};
  EMPLOYEE_SIZE_OPTIONS.forEach((s) => (employeeSizeCounts[s] = 0));

  // Industry counts
  const industryCounts: Record<string, number> = {};

  // Company and domain sets
  const companySet = new Set<string>();
  const countrySet = new Set<string>();

  // Country counts
  const countryCounts: Record<string, number> = {};

  // Upload date timeline counts
  const dateCounts: Record<string, number> = {};

  for (const lead of leads) {
    if (lead.companyName) companySet.add(lead.companyName);
    const countryName = lead.country || (lead.state ? `${lead.state}, US` : 'United States');
    countrySet.add(countryName);
    countryCounts[countryName] = (countryCounts[countryName] || 0) + 1;

    const dateKey = lead.uploadDate || new Date().toISOString().split('T')[0];
    dateCounts[dateKey] = (dateCounts[dateKey] || 0) + 1;

    const emailStatus = (lead.emailStatus || '').toLowerCase();
    if (emailStatus.includes('valid') || emailStatus.includes('verified')) validEmails++;
    else if (emailStatus.includes('catch') || emailStatus.includes('pending')) catchAllEmails++;
    else invalidEmails++;

    if (lead.companyPhone) withPhone++;
    if (lead.directNumber) withDirect++;

    // Map department
    const dept = lead.department || 'Operations';
    departmentCounts[dept] = (departmentCounts[dept] || 0) + 1;

    // Map management level (accurately classified from database fields, never defaults to Manager)
    let mgmt = (lead.managementLevel || lead.jobLevel || '').trim();
    if (!mgmt && lead.jobTitle) {
      const t = lead.jobTitle.toLowerCase();
      if (t.includes('director')) mgmt = 'Director';
      else if (t.includes('vp') || t.includes('vice president')) mgmt = 'VP';
      else if (t.includes('chief') || t.includes('ceo') || t.includes('cto') || t.includes('cfo') || t.includes('president')) mgmt = 'C-Suite';
      else if (t.includes('manager')) mgmt = 'Manager';
      else if (t.includes('head')) mgmt = 'Head';
      else if (t.includes('founder')) mgmt = 'Founder';
      else if (t.includes('owner')) mgmt = 'Owner';
      else if (t.includes('lead') || t.includes('senior')) mgmt = 'Senior';
      else mgmt = 'Individual Contributor';
    } else if (mgmt) {
      const lower = mgmt.toLowerCase();
      if (lower === 'c suite' || lower === 'c-suite' || lower === 'c level' || lower === 'executive') mgmt = 'C-Suite';
      else if (lower === 'vp' || lower === 'vice president') mgmt = 'VP';
      else if (lower.includes('director')) mgmt = 'Director';
      else if (lower.includes('manager')) mgmt = 'Manager';
      else if (lower.includes('head')) mgmt = 'Head';
      else if (lower.includes('founder')) mgmt = 'Founder';
      else if (lower.includes('owner')) mgmt = 'Owner';
      else if (lower.includes('senior')) mgmt = 'Senior';
      else mgmt = mgmt.charAt(0).toUpperCase() + mgmt.slice(1);
    } else {
      mgmt = 'Individual Contributor';
    }
    managementLevelCounts[mgmt] = (managementLevelCounts[mgmt] || 0) + 1;

    // Map employee size
    const size = lead.employeeSize || '1 to 10';
    employeeSizeCounts[size] = (employeeSizeCounts[size] || 0) + 1;

    // Map industry
    const ind = lead.industryType || 'Technology';
    industryCounts[ind] = (industryCounts[ind] || 0) + 1;
  }

  return {
    totalLeads,
    validEmails,
    catchAllEmails,
    invalidEmails,
    emailVerificationRate: totalLeads > 0 ? Math.round((validEmails / totalLeads) * 100) : 0,
    withPhone,
    withDirect,
    totalCompanies: companySet.size,
    totalCountries: countrySet.size,
    countryCounts,
    dateCounts,
    departmentCounts,
    managementLevelCounts,
    employeeSizeCounts,
    industryCounts,
  };
}

/**
 * Download CSV: Dynamically exports ALL columns in the dataset without 31-column restriction
 */
export function downloadEnterpriseCsv(
  leads: EnterpriseLeadRecord[],
  filename = 'Alltake_Leads_Export.csv',
  columns?: EnterpriseColumnDef[],
  options?: {
    isEmployee?: boolean;
    visibilityRules?: FieldVisibilityRule[];
  }
) {
  if (leads.length === 0) return;

  // Determine export columns and labels
  let colsToExport: { key: string; label: string }[] = [];

  if (columns && columns.length > 0) {
    const sorted = [...columns].sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
    colsToExport = sorted.map((c) => ({ key: c.key, label: c.label }));
  } else {
    // Dynamically extract all keys present across leads
    const allKeys = new Set<string>();
    for (const l of leads.slice(0, 100)) {
      for (const k of Object.keys(l)) {
        if (k !== 'id') allKeys.add(k);
      }
    }
    colsToExport = Array.from(allKeys).map((k) => ({
      key: k,
      label: formatHeaderLabel(k),
    }));
  }

  // Admin Privilege Enforced: If employee, only export columns permitted by Admin!
  if (options?.isEmployee && options?.visibilityRules && options.visibilityRules.length > 0) {
    const rulesMap = new Map(options.visibilityRules.map((r) => [r.columnKey, r]));
    colsToExport = colsToExport.filter((col) => {
      const rule = rulesMap.get(col.key);
      if (!rule) return true;
      if (rule.allowEmployeeDownload === false) return false;
      if (rule.employeeVisibility === 'HIDDEN') return false;
      return true;
    });
  }

  const rulesMap = options?.visibilityRules && options.visibilityRules.length > 0
    ? new Map(options.visibilityRules.map((r) => [r.columnKey, r]))
    : null;

  const exportRows = leads.map((lead) => {
    const rowObj: Record<string, any> = {};
    for (const col of colsToExport) {
      let val = lead[col.key] ?? '';
      if (options?.isEmployee && rulesMap) {
        const rule = rulesMap.get(col.key);
        if (rule?.employeeVisibility === 'MASKED' && val !== '' && val !== null && val !== undefined) {
          const strVal = String(val).trim();
          if (strVal) {
            const k = col.key.toLowerCase();
            if (k.includes('email')) {
              val = '***@***.***';
            } else if (k.includes('phone') || k.includes('number')) {
              val = '***-***-****';
            } else {
              val = strVal.length > 3 ? `${strVal.slice(0, 2)}***${strVal.slice(-1)}` : '***';
            }
          }
        }
      }
      rowObj[col.label] = val;
    }
    return rowObj;
  });

  const csv = Papa.unparse(exportRows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Fetch Live Database Status & Diagnostics from Backend Cluster
 */
export async function fetchDatabaseStatus() {
  const res = await fetch('/api/database/status');
  if (!res.ok) throw new Error(`Database status endpoint returned HTTP ${res.status}`);
  return res.json();
}

/**
 * Execute on-demand live database latency & throughput test
 */
export async function testDatabaseDiagnostics() {
  const res = await fetch('/api/database/test', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  if (!res.ok) throw new Error(`Database test failed with HTTP ${res.status}`);
  return res.json();
}

/**
 * Download Sample 31-Column Template for Users to populate
 */
export function downloadSample31Template() {
  const headers = STANDARD_31_COLUMNS.map((c) => c.label);
  const sampleRow: Record<string, string> = {
    'Upload Date': '2026-10-06',
    'Lead Type': 'Executive B2B',
    'First Name': 'Bruce',
    'Last Name': 'Kasanoff',
    'Email Address': 'bruce@kasanoff.com',
    'Email Status': 'Verified',
    'Job Title': 'Founder & Managing Partner',
    'Job Level': 'C-Level',
    'Company Name': 'Kasanoff Advisory Group',
    'Address Link': 'https://maps.google.com/?q=Bend,+Oregon',
    'Address Line 1': '742 Northwest Wall Street',
    City: 'Bend',
    State: 'Oregon',
    'Postal Code': '97701',
    Country: 'United States',
    'Company Phone': '+1 (541) 555-0142',
    'Direct Number': '+1 (541) 555-0199',
    'Other Number': '+1 (541) 555-0188',
    'Employee Size': '1-10 Employees',
    'Industry Type': 'Professional Training & Coaching',
    'Revenue Size': '$1M - $5M',
    'Job Title URL': 'https://linkedin.com/in/brucekasanoff',
    'Company URL': 'https://kasanoff.com',
    'Revenue Size Link': 'https://bloomberg.com/profile/company/KASANOFF',
    'SIC Code': '8748',
    'NAICS Code': '541611',
    'SIC Code URL': 'https://siccode.com/sic-code/8748',
    'NAICS Code URL': 'https://naics.com/naics-code-description/?code=541611',
    'Comment 1': 'Forbes Author',
    'Comment 2': 'High Priority Target',
    Domain: 'kasanoff.com',
  };

  const csv = Papa.unparse([sampleRow], { columns: headers });
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'Alltake_31_Columns_Template.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Helpers
function computeColumnsWithUniqueValues(
  standards: {
    key: string;
    label: string;
    type: EnterpriseColumnDef['type'];
    employeeVisible?: boolean;
    order?: number;
  }[],
  leads: EnterpriseLeadRecord[]
): EnterpriseColumnDef[] {
  return standards.map((col, idx) => {
    const set = new Set<string>();
    for (const lead of leads) {
      const val = (lead as any)[col.key];
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        set.add(String(val).trim());
      }
    }
    return {
      key: col.key,
      label: col.label,
      isCore: true,
      visible: true,
      employeeVisible: col.employeeVisible !== false,
      order: typeof col.order === 'number' ? col.order : idx + 1,
      type: col.type,
      uniqueValues: Array.from(set).sort((a, b) => a.localeCompare(b)),
    };
  });
}

async function getAllFromStore<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction([storeName], 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function saveBatch<T>(db: IDBDatabase, storeName: string, items: T[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction([storeName], 'readwrite');
    const store = tx.objectStore(storeName);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    for (const item of items) {
      store.put(item);
    }
  });
}

async function putInStore<T>(db: IDBDatabase, storeName: string, item: T): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction([storeName], 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function deleteFromStore(db: IDBDatabase, storeName: string, key: string): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction([storeName], 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(key);
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

export async function clearStore(db: IDBDatabase, storeName: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction([storeName], 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

/**
 * Fetches leads directly from Flask or Express backend API and syncs into local engine
 */
export async function syncLeadsFromBackendApi(endpoint = '/api/data'): Promise<{
  syncedCount: number;
  leads: EnterpriseLeadRecord[];
  columns: EnterpriseColumnDef[];
}> {
  const db = await openEnterpriseDB();
  try {
    const res = await fetch(endpoint);
    if (!res.ok) throw new Error(`Backend API returned HTTP ${res.status}`);
    const data = await res.json();
    const records: any[] = Array.isArray(data) ? data : data.data || data.leads || [];

    if (records.length > 0) {
      const mappedLeads: EnterpriseLeadRecord[] = records.map((r, i) => ({
        id: r.id || `lead_api_${Date.now()}_${i}`,
        uploadDate: r.upload_date || r.uploadDate || new Date().toISOString().split('T')[0],
        leadType: r.lead_type || r.leadType || 'Inbound B2B',
        firstName: r.first_name || r.firstName || (r.name ? r.name.split(' ')[0] : 'Prospect'),
        lastName: r.last_name || r.lastName || (r.name ? r.name.split(' ').slice(1).join(' ') : ''),
        fullName: r.full_name || r.fullName || r.name || `${r.first_name || ''} ${r.last_name || ''}`.trim(),
        emailAddress: r.email_address || r.emailAddress || r.email || '',
        emailStatus: r.email_status || r.emailStatus || 'Valid',
        jobTitle: r.job_title || r.jobTitle || '',
        jobLevel: r.job_level || r.jobLevel || 'Specialist',
        companyName: r.company_name || r.companyName || r.company || 'Enterprise Corp',
        addressLink: r.address_link || r.addressLink || '',
        addressLine1: r.address_line_1 || r.addressLine1 || r.address || '',
        city: r.city || '',
        state: r.state || '',
        postalCode: r.postal_code || r.postalCode || '',
        country: r.country || 'United States',
        companyPhone: r.company_phone || r.companyPhone || r.phone || '',
        directNumber: r.direct_number || r.directNumber || '',
        otherNumber: r.other_number || r.otherNumber || '',
        employeeSize: r.employee_size || r.employeeSize || '11-50 employees',
        industryType: r.industry_type || r.industryType || 'Information Technology',
        revenueSize: r.revenue_size || r.revenueSize || '$10M to $25M',
        jobTitleUrl: r.job_title_url || r.jobTitleUrl || '',
        companyUrl: r.company_url || r.companyUrl || '',
        revenueSizeLink: r.revenue_size_link || r.revenueSizeLink || '',
        sicCode: r.sic_code || r.sicCode || '',
        naicsCode: r.naics_code || r.naicsCode || '',
        sicCodeUrl: r.sic_code_url || r.sicCodeUrl || '',
        naicsCodeUrl: r.naics_code_url || r.naicsCodeUrl || '',
        comment1: r.comment_1 || r.comment1 || '',
        comment2: r.comment_2 || r.comment2 || '',
        domain: r.domain || '',
      }));

      await saveBatch(db, 'leads', mappedLeads);
      const computedCols = computeColumnsWithUniqueValues(STANDARD_31_COLUMNS, mappedLeads);
      await saveBatch(db, 'columns', computedCols);

      return {
        syncedCount: mappedLeads.length,
        leads: mappedLeads,
        columns: computedCols,
      };
    }
  } catch (err) {
    console.warn('[enterpriseDb] Direct API sync fallback to local store:', err);
  }

  const existing = await getAllLeads(db);
  const cols = await getAllColumns(db);
  return {
    syncedCount: existing.length,
    leads: existing,
    columns: cols,
  };
}

/**
 * -------------------------------------------------------------
 * Email Notification Engine & Resend Integration Service
 * -------------------------------------------------------------
 */

export async function fetchEmailSettings(): Promise<{
  settings: EmailNotificationSettings;
  recentLogs: EmailDispatchLog[];
}> {
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    const res = await fetch('/api/admin/email-settings', {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });
    if (res.ok) {
      const data = await res.json();
      return {
        settings: data.settings,
        recentLogs: data.recentLogs || [],
      };
    }
  } catch (err) {
    console.warn('[enterpriseDb] Error fetching email settings from backend:', err);
  }

  // Fallback defaults
  return {
    settings: {
      enabled: true,
      resendApiKey: 're_QvqTztdy_9Eh19Q76ynziRNkPJPjSWN2t',
      senderEmail: 'Alltake Alerts <onboarding@resend.dev>',
      recipientEmails: ['anasalltake@gmail.com'],
      notifyOnEmployeeExport: true,
      notifyOnApprovalRequest: true,
      notifyOnApprovalDecision: true,
      notifyOnBulkUpload: true,
      notifyOnSecurityAlert: true,
    },
    recentLogs: [],
  };
}

export async function updateEmailSettings(
  settings: Partial<EmailNotificationSettings>
): Promise<EmailNotificationSettings> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/admin/email-settings', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(settings),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Failed to update email settings (HTTP ${res.status})`);
  }
  return data.settings;
}

export async function sendTestNotificationEmail(): Promise<{
  success: boolean;
  resendId?: string;
  recipients?: string[];
  message: string;
}> {
  const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
  const res = await fetch('/api/admin/email-settings/test', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || 'Failed to dispatch test email');
  }
  return data;
}

export async function notifyExportEvent(eventData: {
  recordCount: number;
  format: string;
  campaignName?: string;
  notes?: string;
  filtersSummary?: string;
  datasetName?: string;
}): Promise<void> {
  try {
    const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
    await fetch('/api/exports/notify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(eventData),
    });
  } catch (err) {
    console.warn('[enterpriseDb] Could not send export notification to backend:', err);
  }
}


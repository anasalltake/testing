import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { LeadRecord, ColumnDef, FilterState } from '../types/apollo';

const DB_NAME = 'alltake_apollo_db_v2';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

export async function openApolloDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('leads')) {
        const leadStore = db.createObjectStore('leads', { keyPath: 'id' });
        leadStore.createIndex('name', 'name', { unique: false });
        leadStore.createIndex('company', 'company', { unique: false });
        leadStore.createIndex('location', 'location', { unique: false });
        leadStore.createIndex('country', 'country', { unique: false });
        leadStore.createIndex('jobTitle', 'jobTitle', { unique: false });
      }
      if (!db.objectStoreNames.contains('columns')) {
        db.createObjectStore('columns', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('datasets')) {
        db.createObjectStore('datasets', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

// Default seed data strictly mirroring the uploaded Apollo screenshot (1.png)
export const INITIAL_SEED_LEADS: LeadRecord[] = [
  {
    id: 'lead_001',
    name: 'Bruce Kasanoff',
    firstName: 'Bruce',
    lastName: 'Kasanoff',
    jobTitle: 'Life Coach',
    company: 'Kasanoff.com',
    companyDomain: 'kasanoff.com',
    companyLogo: 'https://logo.clearbit.com/kasanoff.com',
    email: 'bruce@kasanoff.com',
    phone: '+1 (541) 555-0142',
    location: 'Bend, Oregon',
    country: 'United States',
    state: 'Oregon',
    city: 'Bend',
    companyEmployees: '5',
    companyIndustries: ['Professional Training & Coaching', 'Management'],
    seniority: 'Owner / Founder',
    departments: ['Executive', 'Coaching'],
    linkedinUrl: 'https://linkedin.com/in/brucekasanoff',
    companyLinkedinUrl: 'https://linkedin.com/company/kasanoff',
    websiteUrl: 'https://kasanoff.com',
    twitterUrl: 'https://x.com/brucekasanoff',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_002',
    name: 'Eric Olander',
    firstName: 'Eric',
    lastName: 'Olander',
    jobTitle: 'Co-Founder and Editor in Chief',
    company: 'The China Global South Project',
    companyDomain: 'chinaglobalsouth.com',
    companyLogo: '',
    email: 'eric@chinaglobalsouth.com',
    phone: '+1 (202) 555-0189',
    location: 'United States',
    country: 'United States',
    state: '',
    city: '',
    companyEmployees: '20',
    companyIndustries: ['Media Production', 'Online Media', 'Publishing'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Editorial'],
    linkedinUrl: 'https://linkedin.com/in/ericolander',
    companyLinkedinUrl: 'https://linkedin.com/company/china-global-south',
    websiteUrl: 'https://chinaglobalsouth.com',
    twitterUrl: 'https://x.com/eolander',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_003',
    name: 'Ilya Pozin',
    firstName: 'Ilya',
    lastName: 'Pozin',
    jobTitle: 'Founder & CEO',
    company: 'Telly TV',
    companyDomain: 'freetelly.com',
    companyLogo: '',
    email: 'ilya@freetelly.com',
    phone: '+1 (310) 555-0177',
    location: 'Los Angeles, California',
    country: 'United States',
    state: 'California',
    city: 'Los Angeles',
    companyEmployees: '170',
    companyIndustries: ['Information Technology & Services', 'Consumer Electronics'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive'],
    linkedinUrl: 'https://linkedin.com/in/ilyapozin',
    companyLinkedinUrl: 'https://linkedin.com/company/telly',
    websiteUrl: 'https://freetelly.com',
    twitterUrl: 'https://x.com/ilyapozin',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_004',
    name: 'Heather Elias',
    firstName: 'Heather',
    lastName: 'Elias',
    jobTitle: 'Chief Growth Officer',
    company: 'Elm Street',
    companyDomain: 'elmstreet.com',
    companyLogo: '',
    email: 'heather@elmstreet.com',
    phone: '+1 (703) 555-0164',
    location: 'Ashburn, Virginia',
    country: 'United States',
    state: 'Virginia',
    city: 'Ashburn',
    companyEmployees: '360',
    companyIndustries: ['Real Estate', 'Computer Software', 'Internet'],
    seniority: 'VP / C-Suite',
    departments: ['Growth', 'Marketing'],
    linkedinUrl: 'https://linkedin.com/in/heatherelias',
    companyLinkedinUrl: 'https://linkedin.com/company/elm-street',
    websiteUrl: 'https://elmstreet.com',
    twitterUrl: 'https://x.com/heatherelias',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_005',
    name: 'Jonathan Becher',
    firstName: 'Jonathan',
    lastName: 'Becher',
    jobTitle: 'President, Board Member',
    company: 'San Jose Sharks',
    companyDomain: 'sjsharks.com',
    companyLogo: '',
    email: 'jbecher@sjsharks.com',
    phone: '+1 (408) 555-0199',
    location: 'Mountain View, California',
    country: 'United States',
    state: 'California',
    city: 'Mountain View',
    companyEmployees: '420',
    companyIndustries: ['Sports', 'Entertainment'],
    seniority: 'President / C-Suite',
    departments: ['Executive', 'Operations'],
    linkedinUrl: 'https://linkedin.com/in/jbecher',
    companyLinkedinUrl: 'https://linkedin.com/company/san-jose-sharks',
    websiteUrl: 'https://sjsharks.com',
    twitterUrl: 'https://x.com/jbecher',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_006',
    name: 'Betty Liu',
    firstName: 'Betty',
    lastName: 'Liu',
    jobTitle: 'Independent Director',
    company: 'Apex Treasury Corporation',
    companyDomain: 'apextreasury.com',
    companyLogo: '',
    email: 'betty.liu@apextreasury.com',
    phone: '+1 (212) 555-0138',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '4',
    companyIndustries: ['Financial Services', 'Capital Markets'],
    seniority: 'Director / Board Member',
    departments: ['Executive', 'Finance'],
    linkedinUrl: 'https://linkedin.com/in/bettyliu',
    companyLinkedinUrl: 'https://linkedin.com/company/apex-treasury',
    websiteUrl: 'https://apextreasury.com',
    twitterUrl: 'https://x.com/bettyliu',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_007',
    name: 'Shay Rowbottom',
    firstName: 'Shay',
    lastName: 'Rowbottom',
    jobTitle: 'CEO',
    company: 'Shay Rowbottom Marketing',
    companyDomain: 'shayrowbottom.com',
    companyLogo: '',
    email: 'shay@shayrowbottom.com',
    phone: '+1 (305) 555-0155',
    location: 'Miami, Florida',
    country: 'United States',
    state: 'Florida',
    city: 'Miami',
    companyEmployees: '7',
    companyIndustries: ['Marketing & Advertising', 'Professional Training'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Marketing'],
    linkedinUrl: 'https://linkedin.com/in/shayrowbottom',
    companyLinkedinUrl: 'https://linkedin.com/company/shay-rowbottom-marketing',
    websiteUrl: 'https://shayrowbottom.com',
    twitterUrl: 'https://x.com/shayrowbottom',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_008',
    name: 'Steve Faktor',
    firstName: 'Steve',
    lastName: 'Faktor',
    jobTitle: 'Strategist / Innovator / Futurist',
    company: 'IdeaFaktory',
    companyDomain: 'ideafaktory.com',
    companyLogo: '',
    email: 'steve@ideafaktory.com',
    phone: '+1 (212) 555-0122',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '1',
    companyIndustries: ['Management Consulting', 'Venture Capital'],
    seniority: 'Owner / Principal',
    departments: ['Consulting'],
    linkedinUrl: 'https://linkedin.com/in/stevefaktor',
    companyLinkedinUrl: 'https://linkedin.com/company/ideafaktory',
    websiteUrl: 'https://ideafaktory.com',
    twitterUrl: 'https://x.com/stevefaktor',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_009',
    name: 'Jill Schlesinger',
    firstName: 'Jill',
    lastName: 'Schlesinger',
    jobTitle: 'Business Analyst & Commentator',
    company: 'CBS News',
    companyDomain: 'cbsnews.com',
    companyLogo: '',
    email: 'jill.schlesinger@cbsnews.com',
    phone: '+1 (212) 555-0183',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '2600',
    companyIndustries: ['Media Production', 'Broadcast Media'],
    seniority: 'Senior / Specialist',
    departments: ['Editorial', 'Media'],
    linkedinUrl: 'https://linkedin.com/in/jillschlesinger',
    companyLinkedinUrl: 'https://linkedin.com/company/cbs-news',
    websiteUrl: 'https://cbsnews.com',
    twitterUrl: 'https://x.com/jillonmoney',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_010',
    name: 'Neil Patel',
    firstName: 'Neil',
    lastName: 'Patel',
    jobTitle: 'Co-Founder',
    company: 'NP Digital',
    companyDomain: 'npdigital.com',
    companyLogo: '',
    email: 'neil@npdigital.com',
    phone: '+1 (858) 555-0111',
    location: 'Los Angeles, California',
    country: 'United States',
    state: 'California',
    city: 'Los Angeles',
    companyEmployees: '1000',
    companyIndustries: ['Marketing & Advertising', 'Online Media'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Marketing'],
    linkedinUrl: 'https://linkedin.com/in/neilkpatel',
    companyLinkedinUrl: 'https://linkedin.com/company/np-digital',
    websiteUrl: 'https://npdigital.com',
    twitterUrl: 'https://x.com/neilpatel',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_011',
    name: 'Maria Bartiromo',
    firstName: 'Maria',
    lastName: 'Bartiromo',
    jobTitle: 'Anchor Global Markets Editor',
    company: 'Fox Business Network',
    companyDomain: 'foxbusiness.com',
    companyLogo: '',
    email: 'maria.bartiromo@foxbusiness.com',
    phone: '+1 (212) 555-0194',
    location: 'Englewood Cliffs, New Jersey',
    country: 'United States',
    state: 'New Jersey',
    city: 'Englewood Cliffs',
    companyEmployees: '630',
    companyIndustries: ['Media Production', 'Broadcast Media'],
    seniority: 'Director / Lead Anchor',
    departments: ['Media', 'Editorial'],
    linkedinUrl: 'https://linkedin.com/in/mariabartiromo',
    companyLinkedinUrl: 'https://linkedin.com/company/fox-business-network',
    websiteUrl: 'https://foxbusiness.com',
    twitterUrl: 'https://x.com/mariabartiromo',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_012',
    name: 'Cristina Junqueira',
    firstName: 'Cristina',
    lastName: 'Junqueira',
    jobTitle: 'Co-Founder',
    company: 'Nubank',
    companyDomain: 'nubank.com.br',
    companyLogo: '',
    email: 'cristina@nubank.com.br',
    phone: '+1 (305) 555-0172',
    location: 'Miami, Florida',
    country: 'United States',
    state: 'Florida',
    city: 'Miami',
    companyEmployees: '8100',
    companyIndustries: ['Financial Services', 'Banking', 'Fintech'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Operations'],
    linkedinUrl: 'https://linkedin.com/in/cristinajunqueira',
    companyLinkedinUrl: 'https://linkedin.com/company/nubank',
    websiteUrl: 'https://nubank.com.br',
    twitterUrl: 'https://x.com/crisjunqueira',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_013',
    name: 'Amy Holzheimer',
    firstName: 'Amy',
    lastName: 'Holzheimer',
    jobTitle: 'Sr Regional HR Director, West',
    company: 'Altium Packaging',
    companyDomain: 'altiumpkg.com',
    companyLogo: '',
    email: 'amy.h@altiumpkg.com',
    phone: '+1 (208) 555-0149',
    location: 'Meridian, Idaho',
    country: 'United States',
    state: 'Idaho',
    city: 'Meridian',
    companyEmployees: '4100',
    companyIndustries: ['Packaging & Containers', 'Manufacturing'],
    seniority: 'Director',
    departments: ['Human Resources'],
    linkedinUrl: 'https://linkedin.com/in/amyholzheimer',
    companyLinkedinUrl: 'https://linkedin.com/company/altium-packaging',
    websiteUrl: 'https://altiumpkg.com',
    twitterUrl: '',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_014',
    name: 'Joerg Storm',
    firstName: 'Joerg',
    lastName: 'Storm',
    jobTitle: 'CEO & Founder',
    company: 'Dr. Storm Advisory GmbH',
    companyDomain: 'dr-storm.de',
    companyLogo: '',
    email: 'joerg@dr-storm.de',
    phone: '+49 171 5550183',
    location: 'United States',
    country: 'United States',
    state: '',
    city: '',
    companyEmployees: '3',
    companyIndustries: ['Management Consulting', 'Automotive IT'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Consulting'],
    linkedinUrl: 'https://linkedin.com/in/joergstorm',
    companyLinkedinUrl: 'https://linkedin.com/company/dr-storm-advisory',
    websiteUrl: 'https://dr-storm.de',
    twitterUrl: '',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_015',
    name: "Tim O'Reilly",
    firstName: 'Tim',
    lastName: "O'Reilly",
    jobTitle: 'Founder, Chairman and CEO',
    company: "O'Reilly Media",
    companyDomain: 'oreilly.com',
    companyLogo: '',
    email: 'tim@oreilly.com',
    phone: '+1 (707) 555-0130',
    location: 'Sebastopol, California',
    country: 'United States',
    state: 'California',
    city: 'Sebastopol',
    companyEmployees: '1400',
    companyIndustries: ['E-learning', 'Publishing', 'Technology'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive'],
    linkedinUrl: 'https://linkedin.com/in/timoreilly',
    companyLinkedinUrl: 'https://linkedin.com/company/oreilly-media',
    websiteUrl: 'https://oreilly.com',
    twitterUrl: 'https://x.com/timoreilly',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_016',
    name: 'Mike Cohn',
    firstName: 'Mike',
    lastName: 'Cohn',
    jobTitle: 'Editor-in-Chief, AccountingToday',
    company: 'Arizent',
    companyDomain: 'arizent.com',
    companyLogo: '',
    email: 'mike.cohn@arizent.com',
    phone: '+1 (212) 555-0167',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '280',
    companyIndustries: ['Information Services', 'Publishing', 'Finance'],
    seniority: 'Director / Editor in Chief',
    departments: ['Editorial', 'Content'],
    linkedinUrl: 'https://linkedin.com/in/mikecohn',
    companyLinkedinUrl: 'https://linkedin.com/company/arizent',
    websiteUrl: 'https://arizent.com',
    twitterUrl: 'https://x.com/mikecohn',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_017',
    name: 'Chester Elton',
    firstName: 'Chester',
    lastName: 'Elton',
    jobTitle: '#1 New York Times Bestselling Author',
    company: 'The Culture Works',
    companyDomain: 'thecultureworks.com',
    companyLogo: '',
    email: 'chester@thecultureworks.com',
    phone: '+1 (973) 555-0125',
    location: 'Summit, New Jersey',
    country: 'United States',
    state: 'New Jersey',
    city: 'Summit',
    companyEmployees: '7',
    companyIndustries: ['Professional Training & Coaching', 'Author'],
    seniority: 'Partner / Founder',
    departments: ['Executive'],
    linkedinUrl: 'https://linkedin.com/in/chesterelton',
    companyLinkedinUrl: 'https://linkedin.com/company/the-culture-works',
    websiteUrl: 'https://thecultureworks.com',
    twitterUrl: 'https://x.com/chesterelton',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_018',
    name: 'Katie Couric',
    firstName: 'Katie',
    lastName: 'Couric',
    jobTitle: 'Co-Founder',
    company: 'Katie Couric Media',
    companyDomain: 'katiecouric.com',
    companyLogo: '',
    email: 'katie@katiecouric.com',
    phone: '+1 (212) 555-0190',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '48',
    companyIndustries: ['Media Production', 'Online Media'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Media'],
    linkedinUrl: 'https://linkedin.com/in/katiecouric',
    companyLinkedinUrl: 'https://linkedin.com/company/katie-couric-media',
    websiteUrl: 'https://katiecouric.com',
    twitterUrl: 'https://x.com/katiecouric',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_019',
    name: 'Jeff Selingo',
    firstName: 'Jeff',
    lastName: 'Selingo',
    jobTitle: 'Management Committee Member',
    company: 'EdPlus at Arizona State University',
    companyDomain: 'edplus.asu.edu',
    companyLogo: '',
    email: 'jeff.selingo@asu.edu',
    phone: '+1 (202) 555-0176',
    location: 'Washington, District of Columbia',
    country: 'United States',
    state: 'District of Columbia',
    city: 'Washington',
    companyEmployees: '500',
    companyIndustries: ['Higher Education', 'E-learning'],
    seniority: 'Advisor / Board',
    departments: ['Higher Ed', 'Advisory'],
    linkedinUrl: 'https://linkedin.com/in/jeffselingo',
    companyLinkedinUrl: 'https://linkedin.com/company/arizona-state-university',
    websiteUrl: 'https://edplus.asu.edu',
    twitterUrl: 'https://x.com/jselingo',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_020',
    name: 'Cassie Kozyrkov',
    firstName: 'Cassie',
    lastName: 'Kozyrkov',
    jobTitle: 'Chief Executive Officer',
    company: 'Kozyr',
    companyDomain: 'kozyr.io',
    companyLogo: '',
    email: 'cassie@kozyr.io',
    phone: '+1 (305) 555-0182',
    location: 'Miami, Florida',
    country: 'United States',
    state: 'Florida',
    city: 'Miami',
    companyEmployees: '10',
    companyIndustries: ['Information Technology & Services', 'AI & Machine Learning'],
    seniority: 'C-Suite / Founder',
    departments: ['Executive', 'Engineering'],
    linkedinUrl: 'https://linkedin.com/in/kozyrkov',
    companyLinkedinUrl: 'https://linkedin.com/company/kozyr',
    websiteUrl: 'https://kozyr.io',
    twitterUrl: 'https://x.com/quaesita',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_021',
    name: 'Tiffany Dufu',
    firstName: 'Tiffany',
    lastName: 'Dufu',
    jobTitle: 'President',
    company: 'Tory Burch Foundation',
    companyDomain: 'toryburchfoundation.org',
    companyLogo: '',
    email: 'tdufu@toryburchfoundation.org',
    phone: '+1 (212) 555-0158',
    location: 'New York, New York',
    country: 'United States',
    state: 'New York',
    city: 'New York',
    companyEmployees: '50',
    companyIndustries: ['Nonprofit Organization Management', 'Philanthropy'],
    seniority: 'President / C-Suite',
    departments: ['Executive', 'Foundation'],
    linkedinUrl: 'https://linkedin.com/in/tiffanydufu',
    companyLinkedinUrl: 'https://linkedin.com/company/tory-burch-foundation',
    websiteUrl: 'https://toryburchfoundation.org',
    twitterUrl: 'https://x.com/tdufu',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
  {
    id: 'lead_022',
    name: 'Alex Hormozi',
    firstName: 'Alex',
    lastName: 'Hormozi',
    jobTitle: 'Managing Partner',
    company: 'Acquisition.com',
    companyDomain: 'acquisition.com',
    companyLogo: '',
    email: 'alex@acquisition.com',
    phone: '+1 (702) 555-0144',
    location: 'Las Vegas, Nevada',
    country: 'United States',
    state: 'Nevada',
    city: 'Las Vegas',
    companyEmployees: '200',
    companyIndustries: ['Venture Capital & Private Equity', 'Software'],
    seniority: 'Managing Partner / Founder',
    departments: ['Executive', 'Investment'],
    linkedinUrl: 'https://linkedin.com/in/alexhormozi',
    companyLinkedinUrl: 'https://linkedin.com/company/acquisition-com',
    websiteUrl: 'https://acquisition.com',
    twitterUrl: 'https://x.com/alexhormozi',
    isEmailRevealed: false,
    isPhoneRevealed: false,
  },
];

export const CORE_APOLLO_COLUMNS: ColumnDef[] = [
  { key: 'name', label: 'NAME', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'firstName', label: 'FIRST NAME', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'lastName', label: 'LAST NAME', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'jobTitle', label: 'JOB TITLE', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'company', label: 'COMPANY', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'email', label: 'EMAILS', isCore: true, visible: true, type: 'email', uniqueValues: [] },
  { key: 'phone', label: 'PHONE NUMBERS', isCore: true, visible: true, type: 'phone', uniqueValues: [] },
  { key: 'location', label: 'LOCATION', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'companyEmployees', label: 'COMPANY # EMPLOYEES', isCore: true, visible: true, type: 'number', uniqueValues: [] },
  { key: 'companyIndustries', label: 'COMPANY INDUSTRIES', isCore: true, visible: true, type: 'array', uniqueValues: [] },
  { key: 'links', label: 'LINKS', isCore: true, visible: true, type: 'text', uniqueValues: [] },
  { key: 'companyLinks', label: 'COMPANY LINKS', isCore: true, visible: true, type: 'text', uniqueValues: [] },
];

/**
 * Initializes database with initial seed if empty
 */
export async function initializeDatabase(): Promise<{ leads: LeadRecord[]; columns: ColumnDef[] }> {
  const db = await openApolloDB();

  // Check if leads exist
  const existingLeads = await getAllLeads(db);
  if (existingLeads.length === 0) {
    await saveLeadsBatch(db, INITIAL_SEED_LEADS);
  }

  // Load columns
  let columns = await getAllColumns(db);
  if (columns.length === 0) {
    // Populate unique values for core columns
    const initialLeads = existingLeads.length > 0 ? existingLeads : INITIAL_SEED_LEADS;
    const computedColumns = computeColumnUniqueValues(CORE_APOLLO_COLUMNS, initialLeads);
    await saveColumnsBatch(db, computedColumns);
    columns = computedColumns;
  }

  const finalLeads = await getAllLeads(db);
  return { leads: finalLeads, columns };
}

export async function getAllLeads(db?: IDBDatabase): Promise<LeadRecord[]> {
  const database = db || (await openApolloDB());
  return new Promise((resolve, reject) => {
    const tx = database.transaction(['leads'], 'readonly');
    const store = tx.objectStore('leads');
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function saveLeadsBatch(db: IDBDatabase, leads: LeadRecord[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['leads'], 'readwrite');
    const store = tx.objectStore('leads');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    for (const lead of leads) {
      store.put(lead);
    }
  });
}

export async function getAllColumns(db?: IDBDatabase): Promise<ColumnDef[]> {
  const database = db || (await openApolloDB());
  return new Promise((resolve, reject) => {
    const tx = database.transaction(['columns'], 'readonly');
    const store = tx.objectStore('columns');
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function saveColumnsBatch(db: IDBDatabase, columns: ColumnDef[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['columns'], 'readwrite');
    const store = tx.objectStore('columns');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    for (const col of columns) {
      store.put(col);
    }
  });
}

export function computeColumnUniqueValues(columns: ColumnDef[], leads: LeadRecord[]): ColumnDef[] {
  return columns.map((col) => {
    const valuesSet = new Set<string>();

    for (const lead of leads) {
      let val: any = (lead as any)[col.key];
      if (val === undefined && lead.dynamicFields) {
        val = lead.dynamicFields[col.key];
      }

      if (Array.isArray(val)) {
        val.forEach((item) => {
          if (item && String(item).trim()) valuesSet.add(String(item).trim());
        });
      } else if (val !== null && val !== undefined && String(val).trim()) {
        valuesSet.add(String(val).trim());
      }
    }

    return {
      ...col,
      uniqueValues: Array.from(valuesSet).sort((a, b) => a.localeCompare(b)),
    };
  });
}

/**
 * Universal Ingest File (CSV, XLSX, XLS, TXT, JSON):
 * - Parses all rows and detects all headers
 * - Creates/updates columns in DB so every heading becomes a filter accordion
 * - Saves lead records into DB
 */
export async function ingestUploadedFile(
  file: File
): Promise<{ addedCount: number; newColumnsCount: number; leads: LeadRecord[]; columns: ColumnDef[] }> {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';

  if (['xlsx', 'xls'].includes(ext)) {
    return ingestExcelFile(file);
  } else if (ext === 'json') {
    return ingestJsonFile(file);
  } else {
    // Default to CSV / TSV / TXT
    return ingestCsvFile(file);
  }
}

export async function ingestJsonFile(
  file: File
): Promise<{ addedCount: number; newColumnsCount: number; leads: LeadRecord[]; columns: ColumnDef[] }> {
  const text = await file.text();
  const rawData = JSON.parse(text);
  const rows = Array.isArray(rawData) ? rawData : [rawData];
  return processRawRowsIntoDb(rows);
}

export async function ingestExcelFile(
  file: File
): Promise<{ addedCount: number; newColumnsCount: number; leads: LeadRecord[]; columns: ColumnDef[] }> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    throw new Error('Excel workbook has no sheets');
  }
  const worksheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });
  return processRawRowsIntoDb(rows);
}

async function processRawRowsIntoDb(
  rawRows: Record<string, any>[]
): Promise<{ addedCount: number; newColumnsCount: number; leads: LeadRecord[]; columns: ColumnDef[] }> {
  const db = await openApolloDB();
  const existingColumns = await getAllColumns(db);
  const existingLeads = await getAllLeads(db);

  if (rawRows.length === 0) {
    return { addedCount: 0, newColumnsCount: 0, leads: existingLeads, columns: existingColumns };
  }

  const rawHeaders = Object.keys(rawRows[0] || {});
  const columnMap: Record<string, string> = {};
  const newColumnsToAdd: ColumnDef[] = [];
  const existingColKeySet = new Set(existingColumns.map((c) => c.key.toLowerCase()));

  for (const header of rawHeaders) {
    const cleanHeader = header.trim();
    if (!cleanHeader) continue;

    const normalized = cleanHeader
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/^_+|_+$/g, '');

    let targetKey = normalized;
    if (['full_name', 'lead_name', 'person_name'].includes(normalized)) targetKey = 'name';
    else if (['first_name', 'fname'].includes(normalized)) targetKey = 'firstName';
    else if (['last_name', 'lname', 'surname'].includes(normalized)) targetKey = 'lastName';
    else if (['title', 'designation', 'position', 'role'].includes(normalized)) targetKey = 'jobTitle';
    else if (['company_name', 'organization', 'org'].includes(normalized)) targetKey = 'company';
    else if (['email_address', 'business_email', 'work_email'].includes(normalized)) targetKey = 'email';
    else if (['phone_number', 'mobile', 'telephone'].includes(normalized)) targetKey = 'phone';
    else if (['location_name', 'address', 'geo'].includes(normalized)) targetKey = 'location';
    else if (['nation'].includes(normalized)) targetKey = 'country';
    else if (['employees', 'team_size', 'headcount'].includes(normalized)) targetKey = 'companyEmployees';
    else if (['industry', 'vertical'].includes(normalized)) targetKey = 'companyIndustries';

    columnMap[cleanHeader] = targetKey;

    if (!existingColKeySet.has(targetKey.toLowerCase())) {
      const newCol: ColumnDef = {
        key: targetKey,
        label: cleanHeader.toUpperCase(),
        isCore: false,
        visible: true,
        type: 'text',
        uniqueValues: [],
      };
      newColumnsToAdd.push(newCol);
      existingColKeySet.add(targetKey.toLowerCase());
    }
  }

  const newLeads: LeadRecord[] = [];
  const timestamp = Date.now();

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i];
    const id = `lead_up_${timestamp}_${i}`;

    const dynamicFields: Record<string, any> = {};
    let name = '';
    let firstName = '';
    let lastName = '';
    let jobTitle = '';
    let company = '';
    let email = '';
    let phone = '';
    let location = '';
    let country = 'United States';
    let state = '';
    let city = '';
    let companyEmployees = '';
    let companyIndustries: string[] = [];

    for (const [header, val] of Object.entries(row)) {
      const valStr = String(val || '').trim();
      const key = columnMap[header] || header;

      if (key === 'name') name = valStr;
      else if (key === 'firstName') firstName = valStr;
      else if (key === 'lastName') lastName = valStr;
      else if (key === 'jobTitle') jobTitle = valStr;
      else if (key === 'company') company = valStr;
      else if (key === 'email') email = valStr;
      else if (key === 'phone') phone = valStr;
      else if (key === 'location') location = valStr;
      else if (key === 'country') country = valStr;
      else if (key === 'state') state = valStr;
      else if (key === 'city') city = valStr;
      else if (key === 'companyEmployees') companyEmployees = valStr;
      else if (key === 'companyIndustries') {
        companyIndustries = valStr.split(/[,;|]/).map((s) => s.trim()).filter(Boolean);
      } else {
        dynamicFields[key] = valStr;
      }
    }

    if (!name && (firstName || lastName)) {
      name = `${firstName} ${lastName}`.trim();
    } else if (name && (!firstName || !lastName)) {
      const parts = name.split(' ');
      firstName = parts[0] || '';
      lastName = parts.slice(1).join(' ') || '';
    }

    if (!location && (city || state)) {
      location = [city, state, country].filter(Boolean).join(', ');
    }

    const lead: LeadRecord = {
      id,
      name: name || 'Lead Prospect',
      firstName: firstName || name.split(' ')[0] || '',
      lastName: lastName || name.split(' ').slice(1).join(' ') || '',
      jobTitle: jobTitle || 'Professional',
      company: company || 'Enterprise',
      companyDomain: company ? `${company.toLowerCase().replace(/[^a-z0-9]/g, '')}.com` : '',
      companyLogo: '',
      email: email || `contact@${company.toLowerCase().replace(/[^a-z0-9]/g, '') || 'company'}.com`,
      phone: phone || '+1 (555) 010-0000',
      location: location || country || 'United States',
      country: country || 'United States',
      state: state || '',
      city: city || '',
      companyEmployees: companyEmployees || '50',
      companyIndustries: companyIndustries.length > 0 ? companyIndustries : ['Technology'],
      seniority: 'Executive',
      departments: ['Operations'],
      linkedinUrl: `https://linkedin.com/search/results/all/?keywords=${encodeURIComponent(name || company)}`,
      companyLinkedinUrl: `https://linkedin.com/company/${encodeURIComponent(company)}`,
      websiteUrl: `https://${company ? company.toLowerCase().replace(/[^a-z0-9]/g, '') : 'example'}.com`,
      twitterUrl: '',
      isEmailRevealed: false,
      isPhoneRevealed: false,
      dynamicFields,
    };

    newLeads.push(lead);
  }

  const allLeadsCombined = [...newLeads, ...existingLeads];
  await saveLeadsBatch(db, allLeadsCombined);

  const updatedColumns = [...existingColumns, ...newColumnsToAdd];
  const computedCols = computeColumnUniqueValues(updatedColumns, allLeadsCombined);
  await saveColumnsBatch(db, computedCols);

  return {
    addedCount: newLeads.length,
    newColumnsCount: newColumnsToAdd.length,
    leads: allLeadsCombined,
    columns: computedCols,
  };
}

/**
 * Ingest CSV File dynamically:
 * - Parses all rows
 * - Detects all CSV headers
 * - Creates/updates columns in DB so every heading becomes a filter accordion
 * - Saves lead records into DB
 */
export async function ingestCsvFile(
  file: File
): Promise<{ addedCount: number; newColumnsCount: number; leads: LeadRecord[]; columns: ColumnDef[] }> {
  return new Promise((resolve, reject) => {
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const res = await processRawRowsIntoDb(results.data);
          resolve(res);
        } catch (err) {
          reject(err);
        }
      },
      error: (err) => reject(err),
    });
  });
}

/**
 * Export leads to CSV file
 */
export function exportLeadsToCsv(leads: LeadRecord[], filename = 'apollo_leads_export.csv') {
  const exportData = leads.map((l) => ({
    Name: l.name,
    'First Name': l.firstName,
    'Last Name': l.lastName,
    'Job Title': l.jobTitle,
    Company: l.company,
    Domain: l.companyDomain || '',
    Email: l.email,
    Phone: l.phone,
    Location: l.location,
    Country: l.country,
    State: l.state || '',
    City: l.city || '',
    Employees: l.companyEmployees,
    Industries: l.companyIndustries.join(', '),
    Seniority: l.seniority || '',
    LinkedIn: l.linkedinUrl || '',
    Website: l.websiteUrl || '',
    ...(l.dynamicFields || {}),
  }));

  const csv = Papa.unparse(exportData);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Export leads to Excel XLSX file
 */
export function exportLeadsToExcel(leads: LeadRecord[], filename = 'apollo_leads_export.xlsx') {
  const exportData = leads.map((l) => ({
    Name: l.name,
    'Job Title': l.jobTitle,
    Company: l.company,
    Email: l.email,
    Phone: l.phone,
    Location: l.location,
    Country: l.country,
    Employees: l.companyEmployees,
    Industries: l.companyIndustries.join(', '),
    Seniority: l.seniority || '',
    Website: l.websiteUrl || '',
    ...(l.dynamicFields || {}),
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Leads');
  XLSX.writeFile(workbook, filename);
}

/**
 * Filter evaluation engine supporting:
 * - Direct Include matches
 * - Direct Exclude matches
 * - Real-time Search query
 * - Dynamic CSV attributes
 */
export function evaluateLeadMatches(lead: LeadRecord, filterState: FilterState): boolean {
  const { includes, excludes, searchQuery } = filterState;

  // 1. Search Query
  if (searchQuery && searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    const searchMatch =
      lead.name.toLowerCase().includes(q) ||
      lead.company.toLowerCase().includes(q) ||
      lead.jobTitle.toLowerCase().includes(q) ||
      lead.location.toLowerCase().includes(q) ||
      lead.email.toLowerCase().includes(q) ||
      lead.phone.toLowerCase().includes(q);

    if (!searchMatch) return false;
  }

  // 2. Check Excludes (if lead matches ANY excluded criteria, drop immediately)
  for (const [key, excludedValues] of Object.entries(excludes)) {
    if (!excludedValues || excludedValues.length === 0) continue;

    const leadVal = getLeadValue(lead, key);
    if (leadVal === undefined || leadVal === null) continue;

    const exSet = new Set(excludedValues.map((v) => v.toLowerCase().trim()));

    if (Array.isArray(leadVal)) {
      const hasExcluded = leadVal.some((item) => exSet.has(String(item).toLowerCase().trim()));
      if (hasExcluded) return false;
    } else {
      const strVal = String(leadVal).toLowerCase().trim();
      // Exact or substring match for safety
      const hasExcluded = Array.from(exSet).some((ex) => strVal === ex || strVal.includes(ex));
      if (hasExcluded) return false;
    }
  }

  // 3. Check Includes (lead MUST match all included attribute groups)
  for (const [key, includedValues] of Object.entries(includes)) {
    if (!includedValues || includedValues.length === 0) continue;

    const leadVal = getLeadValue(lead, key);
    if (leadVal === undefined || leadVal === null) return false;

    const incSet = new Set(includedValues.map((v) => v.toLowerCase().trim()));

    if (Array.isArray(leadVal)) {
      const hasIncluded = leadVal.some((item) => incSet.has(String(item).toLowerCase().trim()));
      if (!hasIncluded) return false;
    } else {
      const strVal = String(leadVal).toLowerCase().trim();
      const hasIncluded = Array.from(incSet).some((inc) => strVal === inc || strVal.includes(inc));
      if (!hasIncluded) return false;
    }
  }

  return true;
}

function getLeadValue(lead: LeadRecord, key: string): any {
  if (key in lead) {
    return (lead as any)[key];
  }
  if (lead.dynamicFields && key in lead.dynamicFields) {
    return lead.dynamicFields[key];
  }
  // Try case-insensitive lookup
  if (lead.dynamicFields) {
    const foundKey = Object.keys(lead.dynamicFields).find(
      (k) => k.toLowerCase() === key.toLowerCase()
    );
    if (foundKey) return lead.dynamicFields[foundKey];
  }
  return undefined;
}

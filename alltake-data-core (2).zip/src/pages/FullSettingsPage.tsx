import React, { useState, useEffect } from 'react';
import {
  Mail,
  ShieldAlert,
  Send,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Bell,
  Users,
  Database,
  SlidersHorizontal,
  Eye,
  FileSpreadsheet,
  Clock,
  RotateCw,
  Plus,
  Trash2,
  Check,
  ChevronRight,
  Shield,
  Zap,
  Info,
  Server,
  KeyRound,
  Download,
  Ban,
  Activity,
  Pencil,
  ArrowLeft
} from 'lucide-react';
import { UserEditModal } from '../components/admin/UserEditModal';
import { UserLoginHistoryModal } from '../components/admin/UserLoginHistoryModal';
import { SetPasswordModal } from '../components/auth/SetPasswordModal';
import {
  fetchEmailSettings,
  updateEmailSettings,
  sendTestNotificationEmail,
  getExportGovernanceSettings,
  updateExportGovernanceSettings,
  getExportApprovalRequests,
  reviewExportApprovalRequest,
  getAllUsers,
  createEnterpriseUser,
  toggleBlockUser,
  deleteEnterpriseUser,
  fetchDatabaseStatus,
  getAllDownloadLogs,
} from '../services/enterpriseDb';
import {
  EmailNotificationSettings,
  EmailDispatchLog,
  ExportGovernanceSettings,
  ExportApprovalRequest,
  EnterpriseUser,
  DatabaseDiagnosticStatus,
  DownloadAuditLog,
} from '../types/enterprise';

interface FullSettingsPageProps {
  onBackToExplorer: () => void;
  onBackToDashboard: () => void;
  onNotify: (msg: string) => void;
  initialTab?: 'notifications' | 'exports' | 'users' | 'database' | 'logs';
}

export const FullSettingsPage: React.FC<FullSettingsPageProps> = ({
  onBackToExplorer,
  onBackToDashboard,
  onNotify,
  initialTab = 'notifications',
}) => {
  const [activeTab, setActiveTab] = useState<'notifications' | 'exports' | 'users' | 'database' | 'logs'>(initialTab);

  // Email & Resend state
  const [emailSettings, setEmailSettings] = useState<EmailNotificationSettings>({
    enabled: true,
    resendApiKey: 're_QvqTztdy_9Eh19Q76ynziRNkPJPjSWN2t',
    senderEmail: 'Alltake Alerts <onboarding@resend.dev>',
    recipientEmails: ['anasalltake@gmail.com'],
    notifyOnEmployeeExport: true,
    notifyOnApprovalRequest: true,
    notifyOnApprovalDecision: true,
    notifyOnBulkUpload: true,
    notifyOnSecurityAlert: true,
  });
  const [emailLogs, setEmailLogs] = useState<EmailDispatchLog[]>([]);
  const [newRecipientInput, setNewRecipientInput] = useState('');
  const [isSavingEmail, setIsSavingEmail] = useState(false);
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; resendId?: string } | null>(null);

  // Export Governance state
  const [exportSettings, setExportSettings] = useState<ExportGovernanceSettings>({
    employeeMaxDownloadLimit: 10000,
    requireApprovalAboveLimit: true,
    allowEmployeeDownload: true,
  });
  const [approvalRequests, setApprovalRequests] = useState<ExportApprovalRequest[]>([]);
  const [isSavingExport, setIsSavingExport] = useState(false);

  // Users state
  const [users, setUsers] = useState<EnterpriseUser[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserLoginId, setNewUserLoginId] = useState('');
  const [newUserRole, setNewUserRole] = useState<'EMPLOYEE' | 'DATA_MANAGER' | 'ADMIN'>('EMPLOYEE');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [editingUser, setEditingUser] = useState<EnterpriseUser | null>(null);
  const [loginHistoryUser, setLoginHistoryUser] = useState<EnterpriseUser | null>(null);
  const [passwordResetUser, setPasswordResetUser] = useState<EnterpriseUser | null>(null);

  // Database status
  const [dbStatus, setDbStatus] = useState<DatabaseDiagnosticStatus | null>(null);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<DownloadAuditLog[]>([]);

  // Load initial data
  const loadData = async () => {
    try {
      const emailData = await fetchEmailSettings();
      if (emailData?.settings) setEmailSettings(emailData.settings);
      if (emailData?.recentLogs) setEmailLogs(emailData.recentLogs);

      const expData = await getExportGovernanceSettings();
      if (expData) setExportSettings(expData);

      const reqs = await getExportApprovalRequests();
      if (reqs) setApprovalRequests(reqs);

      const userList = await getAllUsers();
      if (userList) setUsers(userList);

      const dStatus = await fetchDatabaseStatus();
      if (dStatus) setDbStatus(dStatus);

      const logs = await getAllDownloadLogs();
      if (logs) setAuditLogs(logs);
    } catch (e) {
      console.error('Error loading settings:', e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Add recipient handler
  const handleAddRecipient = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newRecipientInput.trim().toLowerCase();
    if (!clean || !clean.includes('@') || !clean.includes('.')) {
      onNotify('Please enter a valid email address.');
      return;
    }
    if (emailSettings.recipientEmails.includes(clean)) {
      onNotify('Email address is already in the recipient list.');
      return;
    }

    setEmailSettings({
      ...emailSettings,
      recipientEmails: [...emailSettings.recipientEmails, clean],
    });
    setNewRecipientInput('');
  };

  // Remove recipient handler
  const handleRemoveRecipient = (emailToRemove: string) => {
    if (emailSettings.recipientEmails.length <= 1) {
      onNotify('At least one notification recipient email is required.');
      return;
    }
    setEmailSettings({
      ...emailSettings,
      recipientEmails: emailSettings.recipientEmails.filter((e) => e !== emailToRemove),
    });
  };

  // Save email settings
  const handleSaveEmailSettings = async () => {
    setIsSavingEmail(true);
    setTestResult(null);
    try {
      const updated = await updateEmailSettings(emailSettings);
      setEmailSettings(updated);
      onNotify('Email alert configuration saved successfully.');
    } catch (err: any) {
      onNotify(err.message || 'Failed to save email settings.');
    } finally {
      setIsSavingEmail(false);
    }
  };

  // Send test email
  const handleSendTestEmail = async () => {
    setIsSendingTest(true);
    setTestResult(null);
    try {
      const res = await sendTestNotificationEmail();
      setTestResult({
        success: true,
        message: res.message || 'Test email dispatched successfully!',
        resendId: res.resendId,
      });
      onNotify('Test email sent successfully via Resend API.');
      // Refresh logs
      const updated = await fetchEmailSettings();
      if (updated?.recentLogs) setEmailLogs(updated.recentLogs);
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Failed to send test email.',
      });
      onNotify('Test email delivery failed: ' + (err.message || 'Check API key'));
    } finally {
      setIsSendingTest(false);
    }
  };

  // Save export settings
  const handleSaveExportSettings = async () => {
    setIsSavingExport(true);
    try {
      const updated = await updateExportGovernanceSettings(exportSettings);
      setExportSettings(updated);
      onNotify('Export limits & governance policies updated.');
    } catch (err: any) {
      onNotify(err.message || 'Failed to update export policies.');
    } finally {
      setIsSavingExport(false);
    }
  };

  // Review approval request
  const handleReviewRequest = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    try {
      await reviewExportApprovalRequest(id, status, `Reviewed in Full Settings page (${status})`);
      onNotify(`Request has been marked as ${status}.`);
      const updated = await getExportApprovalRequests();
      setApprovalRequests(updated);
    } catch (err: any) {
      onNotify(err.message || 'Failed to update request.');
    }
  };

  // Add User
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserEmail || !newUserLoginId || !newUserName || !newUserPassword) {
      onNotify('Please complete all required user fields.');
      return;
    }
    try {
      await createEnterpriseUser({
        email: newUserEmail,
        username: newUserLoginId,
        full_name: newUserName,
        role: newUserRole,
        status: 'ACTIVE',
        password: newUserPassword,
      });
      onNotify(`User account created for ${newUserName} (${newUserRole}).`);
      setIsAddUserOpen(false);
      setNewUserEmail('');
      setNewUserLoginId('');
      setNewUserName('');
      setNewUserPassword('');
      const updatedUsers = await getAllUsers();
      setUsers(updatedUsers);
    } catch (err: any) {
      onNotify(err.message || 'Failed to create user account.');
    }
  };

  // Toggle user block
  const handleToggleBlock = async (userId: string) => {
    try {
      await toggleBlockUser(userId);
      const updatedUsers = await getAllUsers();
      setUsers(updatedUsers);
      onNotify(`User status updated.`);
    } catch (err: any) {
      onNotify(err.message || 'Failed to toggle user status.');
    }
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    try {
      await deleteEnterpriseUser(userId);
      setUsers(users.filter((u) => u.id !== userId));
      onNotify(`User account for ${userName} removed.`);
    } catch (err: any) {
      onNotify(err.message || 'Failed to delete user account.');
    }
  };

  return (
    <div className="min-h-full bg-slate-900/5 relative flex flex-col font-sans">
      {/* Background ambient lighting for blur glass effects */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-blue-500/10 blur-3xl" />
        <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="absolute -bottom-20 left-1/4 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      {/* Page Title & Navigation Banner (Integrated cleanly below TopNav without double navbar) */}
      <div className="px-6 sm:px-8 pt-6 pb-2 max-w-7xl w-full mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Enterprise Administration & Security Governance
            </h1>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Live Cluster
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Configure Resend email notifications, employee export limits, user permissions, and compliance audits
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onBackToExplorer}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-white/90 hover:bg-white text-slate-700 border border-slate-200/90 shadow-2xs transition-all cursor-pointer flex items-center gap-1.5 hover:shadow-xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Lead Explorer</span>
          </button>
          <button
            onClick={onBackToDashboard}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#0071E3] hover:bg-blue-600 text-white shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>Dashboard</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content Layout with Frosted Glass Panels */}
      <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto flex flex-col md:flex-row gap-6">
        {/* Left Navigation Sidebar (Glassmorphic) */}
        <aside className="w-full md:w-64 shrink-0">
          <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-3 sticky top-24 space-y-1">
            <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Control Center
            </div>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${
                activeTab === 'notifications'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-white/80 hover:text-slate-900'
              }`}
            >
              <Mail className="w-4 h-4 shrink-0" />
              <div className="flex-1 leading-tight">
                <span>Email Alerts & Resend</span>
                <span className={`block text-[10px] font-normal ${activeTab === 'notifications' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Instant export triggers
                </span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('exports')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${
                activeTab === 'exports'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-white/80 hover:text-slate-900'
              }`}
            >
              <Download className="w-4 h-4 shrink-0" />
              <div className="flex-1 leading-tight">
                <span>Export & Limits</span>
                <span className={`block text-[10px] font-normal ${activeTab === 'exports' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Max 10K quota & approvals
                </span>
              </div>
              {approvalRequests.filter((r) => r.status === 'PENDING').length > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {approvalRequests.filter((r) => r.status === 'PENDING').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${
                activeTab === 'users'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-white/80 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <div className="flex-1 leading-tight">
                <span>Users & Roles (RBAC)</span>
                <span className={`block text-[10px] font-normal ${activeTab === 'users' ? 'text-blue-100' : 'text-slate-400'}`}>
                  {users.length} active team accounts
                </span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('database')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${
                activeTab === 'database'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-white/80 hover:text-slate-900'
              }`}
            >
              <Database className="w-4 h-4 shrink-0" />
              <div className="flex-1 leading-tight">
                <span>Database Cluster</span>
                <span className={`block text-[10px] font-normal ${activeTab === 'database' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Vault health & latency
                </span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${
                activeTab === 'logs'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-white/80 hover:text-slate-900'
              }`}
            >
              <Activity className="w-4 h-4 shrink-0" />
              <div className="flex-1 leading-tight">
                <span>Audit & Security Logs</span>
                <span className={`block text-[10px] font-normal ${activeTab === 'logs' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Download & access audit
                </span>
              </div>
            </button>
          </div>
        </aside>

        {/* Right Content Body (Frosted Glass Container) */}
        <main className="flex-1 min-w-0">
          {/* TAB 1: EMAIL NOTIFICATIONS & RESEND CONFIG */}
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              {/* Header Card */}
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-md shrink-0">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">
                        Resend Email Notification Engine
                      </h2>
                      <p className="text-xs text-slate-500">
                        Automatically alerts Administrators whenever employees export data or request downloads
                      </p>
                    </div>
                  </div>

                  {/* Master Switch */}
                  <label className="flex items-center gap-3 cursor-pointer select-none bg-slate-50 border border-slate-200/80 px-4 py-2 rounded-xl">
                    <span className="text-xs font-semibold text-slate-700">Email Alerts</span>
                    <input
                      type="checkbox"
                      checked={emailSettings.enabled}
                      onChange={(e) => setEmailSettings({ ...emailSettings, enabled: e.target.checked })}
                      className="sr-only"
                    />
                    <div
                      className={`w-11 h-6 rounded-full transition-colors relative flex items-center ${
                        emailSettings.enabled ? 'bg-blue-600' : 'bg-slate-300'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ml-0.5 ${
                          emailSettings.enabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </div>
                  </label>
                </div>

                {/* Resend API Key Card */}
                <div className="mt-6 bg-gradient-to-r from-blue-50/60 to-indigo-50/40 border border-blue-200/60 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Resend Production API Integration Active
                      </span>
                      <span className="font-mono text-[11px] text-blue-700">
                        re_QvqTztdy_*** (Verified & Ready)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSendTestEmail}
                      disabled={isSendingTest}
                      className="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-blue-700 text-xs font-semibold rounded-lg border border-blue-200 shadow-2xs transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
                    >
                      {isSendingTest ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Delivering...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Test Email</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {testResult && (
                  <div
                    className={`mt-4 p-4 rounded-xl text-xs flex items-start gap-3 border ${
                      testResult.success
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-rose-50 border-rose-200 text-rose-800'
                    }`}
                  >
                    {testResult.success ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <span className="font-bold block">
                        {testResult.success ? 'Resend Dispatch Success' : 'Dispatch Failure'}
                      </span>
                      <p className="mt-0.5 leading-relaxed">{testResult.message}</p>
                      {testResult.resendId && (
                        <p className="font-mono text-[11px] text-emerald-700 mt-1">
                          Resend ID: {testResult.resendId}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Recipients Management Card (User specified requirement) */}
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Notification Recipients (Who gets the alert)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Emails entered here will receive immediate alerts whenever an employee triggers an export event
                    </p>
                  </div>
                  <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                    {emailSettings.recipientEmails.length} recipient{emailSettings.recipientEmails.length !== 1 ? 's' : ''}
                  </span>
                </div>

                {/* Add new email input */}
                <form onSubmit={handleAddRecipient} className="flex gap-2">
                  <div className="relative flex-1">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={newRecipientInput}
                      onChange={(e) => setNewRecipientInput(e.target.value)}
                      placeholder="Add admin or security officer email (e.g. anasalltake@gmail.com)..."
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Email</span>
                  </button>
                </form>

                {/* Recipient Chips */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {emailSettings.recipientEmails.map((email) => (
                    <div
                      key={email}
                      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs text-xs font-medium text-slate-800"
                    >
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <span>{email}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveRecipient(email)}
                        className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer ml-1"
                        title="Remove recipient"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Sender Address */}
                <div className="pt-4 border-t border-slate-100">
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Sender Identity (Resend From Field)
                  </label>
                  <input
                    type="text"
                    value={emailSettings.senderEmail}
                    onChange={(e) => setEmailSettings({ ...emailSettings, senderEmail: e.target.value })}
                    className="w-full max-w-md px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-blue-600 font-mono"
                    placeholder="Alltake Alerts <onboarding@resend.dev>"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Free Resend tier uses <code className="text-slate-600 font-mono">onboarding@resend.dev</code>. You can configure your custom domain on Resend.
                  </p>
                </div>
              </div>

              {/* Event Triggers Matrix (User specified requirement: "kya kya hone par email trigger hone mangta") */}
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Event Triggers Matrix (What actions trigger an email alert)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Select exactly which actions and thresholds will fire real-time email notifications to administrators
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  {/* Trigger 1: Employee Data Export */}
                  <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200/80 bg-white/60 hover:bg-white transition-all cursor-pointer">
                    <input
                      type="checkbox"
                      checked={emailSettings.notifyOnEmployeeExport}
                      onChange={(e) =>
                        setEmailSettings({ ...emailSettings, notifyOnEmployeeExport: e.target.checked })
                      }
                      className="mt-1 w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Employee Data Export Performed
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        Fires immediately when an employee downloads leads in CSV or Excel, with full row count, filters, and user details.
                      </p>
                    </div>
                  </label>

                  {/* Trigger 2: Approval Requests */}
                  <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200/80 bg-white/60 hover:bg-white transition-all cursor-pointer">
                    <input
                      type="checkbox"
                      checked={emailSettings.notifyOnApprovalRequest}
                      onChange={(e) =>
                        setEmailSettings({ ...emailSettings, notifyOnApprovalRequest: e.target.checked })
                      }
                      className="mt-1 w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Mass Export Approval Request Submitted
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        Fires when an employee attempts to export above the 10,000 threshold and submits justification.
                      </p>
                    </div>
                  </label>

                  {/* Trigger 3: Approval Decision */}
                  <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200/80 bg-white/60 hover:bg-white transition-all cursor-pointer">
                    <input
                      type="checkbox"
                      checked={emailSettings.notifyOnApprovalDecision}
                      onChange={(e) =>
                        setEmailSettings({ ...emailSettings, notifyOnApprovalDecision: e.target.checked })
                      }
                      className="mt-1 w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Approval Decision Confirmation
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        Sends confirmation email whenever an administrator approves or denies an export request.
                      </p>
                    </div>
                  </label>

                  {/* Trigger 4: Bulk Dataset Upload */}
                  <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200/80 bg-white/60 hover:bg-white transition-all cursor-pointer">
                    <input
                      type="checkbox"
                      checked={emailSettings.notifyOnBulkUpload}
                      onChange={(e) =>
                        setEmailSettings({ ...emailSettings, notifyOnBulkUpload: e.target.checked })
                      }
                      className="mt-1 w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        New Dataset Ingestion & Upload
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        Fires when a new daily lead file or bulk CSV is ingested into the database repository.
                      </p>
                    </div>
                  </label>
                </div>

                {/* Save Button Bar */}
                <div className="pt-4 flex justify-end">
                  <button
                    type="button"
                    onClick={handleSaveEmailSettings}
                    disabled={isSavingEmail}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-2"
                  >
                    {isSavingEmail ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Saving Configuration...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Save Email Policy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Recent Email Dispatch Logs Card */}
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Recent Resend Dispatch Logs
                    </h3>
                    <p className="text-xs text-slate-500">
                      Live audit of automated emails sent to administrators
                    </p>
                  </div>
                  <button
                    onClick={async () => {
                      const updated = await fetchEmailSettings();
                      if (updated?.recentLogs) setEmailLogs(updated.recentLogs);
                    }}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border border-slate-200 bg-white"
                    title="Refresh logs"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {emailLogs.length === 0 ? (
                  <div className="py-8 text-center bg-slate-50/60 rounded-xl border border-slate-200/60 text-slate-400 text-xs">
                    No email dispatches recorded yet. Try sending a test email above!
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 text-slate-400 font-semibold text-[11px]">
                          <th className="py-2.5 px-3">Event Type</th>
                          <th className="py-2.5 px-3">Recipients</th>
                          <th className="py-2.5 px-3">Subject</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3">Timestamp</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {emailLogs.map((log) => (
                          <tr key={log.id} className="hover:bg-white/60">
                            <td className="py-2.5 px-3 font-semibold text-slate-800">
                              {log.eventType}
                            </td>
                            <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 truncate max-w-xs">
                              {log.recipient}
                            </td>
                            <td className="py-2.5 px-3 text-slate-700 truncate max-w-xs">
                              {log.subject}
                            </td>
                            <td className="py-2.5 px-3">
                              <span
                                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                  log.status === 'DELIVERED'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                                }`}
                              >
                                {log.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">
                              {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: EXPORTS & COMPLIANCE GOVERNANCE */}
          {activeTab === 'exports' && (
            <div className="space-y-6">
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    Export Quota & Mass Extraction Prevention
                  </h2>
                  <p className="text-xs text-slate-500">
                    Enforce strict download caps for employee accounts to prevent full dataset leakage
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border border-slate-200/90 bg-white/60 space-y-2">
                    <label className="block text-xs font-bold text-slate-900">
                      Employee Max Single Download Limit
                    </label>
                    <input
                      type="number"
                      value={exportSettings.employeeMaxDownloadLimit}
                      onChange={(e) =>
                        setExportSettings({
                          ...exportSettings,
                          employeeMaxDownloadLimit: Number(e.target.value) || 10000,
                        })
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg font-mono font-semibold text-slate-900"
                    />
                    <p className="text-[11px] text-slate-500">
                      Standard policy: 10,000 maximum records per export without administrator approval.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-200/90 bg-white/60 flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Strict Administrator Approval Gate
                      </span>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Requires approval when employee requests exceed quota limit.
                      </p>
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer mt-3">
                      <input
                        type="checkbox"
                        checked={exportSettings.requireApprovalAboveLimit}
                        onChange={(e) =>
                          setExportSettings({
                            ...exportSettings,
                            requireApprovalAboveLimit: e.target.checked,
                          })
                        }
                        className="w-4 h-4 rounded text-blue-600 border-slate-300"
                      />
                      <span className="text-xs font-semibold text-slate-800">
                        Enable Approval Requirement
                      </span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={handleSaveExportSettings}
                    disabled={isSavingExport}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    {isSavingExport ? 'Saving...' : 'Save Export Policies'}
                  </button>
                </div>
              </div>

              {/* Pending Approvals Table */}
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900">
                    Export Approval Requests ({approvalRequests.length})
                  </h3>
                  <span className="text-xs font-mono text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                    {approvalRequests.filter((r) => r.status === 'PENDING').length} Pending
                  </span>
                </div>

                {approvalRequests.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center">No export approval requests filed yet.</p>
                ) : (
                  <div className="space-y-3">
                    {approvalRequests.map((req) => (
                      <div
                        key={req.id}
                        className="p-4 rounded-xl border border-slate-200/90 bg-white/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-slate-900">{req.user_name}</span>
                            <span className="text-[11px] text-slate-400">({req.user_email})</span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.2 rounded ${
                                req.status === 'APPROVED'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : req.status === 'REJECTED'
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}
                            >
                              {req.status}
                            </span>
                          </div>
                          {req.campaign_name && (
                            <div className="mt-1">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                                🎯 Campaign: {req.campaign_name}
                              </span>
                            </div>
                          )}
                          <p className="text-xs text-slate-600 mt-1">
                            Requested <strong>{req.requested_count.toLocaleString()} leads</strong> in {req.file_format} format
                          </p>
                          <p className="text-[11px] text-slate-500 italic mt-0.5">
                            "{req.reason}"
                          </p>
                        </div>

                        {req.status === 'PENDING' && (
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => handleReviewRequest(req.id, 'APPROVED')}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleReviewRequest(req.id, 'REJECTED')}
                              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg border border-rose-200 transition-colors"
                            >
                              Reject
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: USER MANAGEMENT & RBAC */}
          {activeTab === 'users' && (
            <div className="space-y-6">
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">
                      Enterprise Team & User Access Control
                    </h2>
                    <p className="text-xs text-slate-500">
                      Manage employee logins, super admin privileges, and account security
                    </p>
                  </div>
                  <button
                    onClick={() => setIsAddUserOpen(!isAddUserOpen)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAddUserOpen ? 'Cancel' : 'Add New User'}</span>
                  </button>
                </div>

                {isAddUserOpen && (
                  <form onSubmit={handleCreateUser} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                    <span className="text-xs font-bold text-slate-800 block">Create Enterprise Account</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          value={newUserName}
                          onChange={(e) => setNewUserName(e.target.value)}
                          placeholder="e.g. Sarah Jenkins"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Email Address</label>
                        <input
                          type="email"
                          required
                          value={newUserEmail}
                          onChange={(e) => setNewUserEmail(e.target.value)}
                          placeholder="sarah@alltake.com"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Login Username</label>
                        <input
                          type="text"
                          required
                          value={newUserLoginId}
                          onChange={(e) => setNewUserLoginId(e.target.value)}
                          placeholder="sarah.jenkins"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Role Tier</label>
                        <select
                          value={newUserRole}
                          onChange={(e: any) => setNewUserRole(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg"
                        >
                          <option value="EMPLOYEE">Employee (Protected Export & Masking)</option>
                          <option value="DATA_MANAGER">Data Manager (Dataset Uploads)</option>
                          <option value="ADMIN">Super Administrator (Full Access)</option>
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">Initial Password</label>
                        <input
                          type="password"
                          required
                          value={newUserPassword}
                          onChange={(e) => setNewUserPassword(e.target.value)}
                          placeholder="Enter secure initial password..."
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg font-mono"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end pt-2">
                      <button
                        type="submit"
                        className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl"
                      >
                        Create & Activate Account
                      </button>
                    </div>
                  </form>
                )}

                {/* Users List */}
                <div className="divide-y divide-slate-100">
                  {users.map((u) => (
                    <div
                      key={u.id}
                      className="py-3.5 px-2 hover:bg-slate-50/70 rounded-xl transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-xs shadow-2xs shrink-0">
                          {u.full_name?.slice(0, 2).toUpperCase() || 'US'}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs text-slate-900">{u.full_name}</span>
                            <span
                              className={`text-[10px] font-semibold px-2 py-0.2 rounded ${
                                u.role === 'ADMIN'
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                  : u.role === 'DATA_MANAGER'
                                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {u.role}
                            </span>
                            {u.status === 'BLOCKED' ? (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 border border-rose-200">
                                SUSPENDED
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 font-mono flex-wrap">
                            <span>{u.email}</span>
                            <span>·</span>
                            <span>ID: {u.username}</span>
                            {u.last_login_at && (
                              <>
                                <span>·</span>
                                <span className="text-slate-400">
                                  Last Login: {new Date(u.last_login_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 self-end md:self-center flex-wrap">
                        {/* Edit Account */}
                        <button
                          type="button"
                          onClick={() => setEditingUser(u)}
                          className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="Edit employee details, email, username & password"
                        >
                          <Pencil className="w-3.5 h-3.5 text-blue-600" />
                          <span>Edit</span>
                        </button>

                        {/* Direct Password Reset */}
                        <button
                          type="button"
                          onClick={() => setPasswordResetUser(u)}
                          className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="Direct password reset override"
                        >
                          <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Password</span>
                        </button>

                        {/* Login History */}
                        <button
                          type="button"
                          onClick={() => setLoginHistoryUser(u)}
                          className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="View authentication audit & login history"
                        >
                          <Clock className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Logins</span>
                        </button>

                        {/* Suspend / Unblock */}
                        {u.role !== 'ADMIN' && (
                          <button
                            type="button"
                            onClick={() => handleToggleBlock(u.id)}
                            className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                              u.status === 'BLOCKED'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200'
                            }`}
                          >
                            {u.status === 'BLOCKED' ? 'Unblock' : 'Suspend'}
                          </button>
                        )}

                        {/* Delete User */}
                        {u.role !== 'ADMIN' && (
                          <button
                            type="button"
                            onClick={() => handleDeleteUser(u.id, u.full_name)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 bg-white transition-colors cursor-pointer"
                            title="Delete user account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DATABASE STATUS */}
          {activeTab === 'database' && (
            <div className="space-y-6">
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <h2 className="text-lg font-bold text-slate-900">Database Cluster & Diagnostics</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[11px] text-slate-500 block">Status</span>
                    <span className="text-sm font-bold text-emerald-600">Connected & Ready</span>
                  </div>
                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[11px] text-slate-500 block">Encryption</span>
                    <span className="text-sm font-bold text-slate-900">AES-256 / SHA-256</span>
                  </div>
                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[11px] text-slate-500 block">Read Latency</span>
                    <span className="text-sm font-bold text-blue-600">{dbStatus?.readLatencyMs || 2} ms</span>
                  </div>
                  <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[11px] text-slate-500 block">Disk Vault</span>
                    <span className="text-sm font-bold text-slate-900">data/leads_db.json</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: AUDIT LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-6">
              <div className="backdrop-blur-xl bg-white/75 border border-white/80 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] p-6 space-y-4">
                <h2 className="text-lg font-bold text-slate-900">Compliance Audit Trail</h2>
                <p className="text-xs text-slate-500">
                  Comprehensive log of all lead download jobs and security events
                </p>

                <div className="space-y-2">
                  {auditLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white/60 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{log.userName}</span>
                          <span className="text-[11px] text-slate-400">({log.userEmail})</span>
                          <span className="font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded text-[10px]">
                            {log.recordCount.toLocaleString()} leads exported
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 block mt-0.5">
                          Criteria: {log.filtersSummary}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Employee Management Modals */}
      <UserEditModal
        isOpen={!!editingUser}
        user={editingUser}
        onClose={() => setEditingUser(null)}
        onSuccess={(updated, msg) => {
          setUsers(users.map((u) => (u.id === updated.id ? updated : u)));
          onNotify(msg);
        }}
      />
      <UserLoginHistoryModal
        isOpen={!!loginHistoryUser}
        user={loginHistoryUser}
        onClose={() => setLoginHistoryUser(null)}
      />
      <SetPasswordModal
        isOpen={!!passwordResetUser}
        targetUser={passwordResetUser}
        onClose={() => setPasswordResetUser(null)}
        onSuccess={(msg) => onNotify(msg)}
      />
    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogoutModal } from '../components/auth/LogoutModal';
import {
  Lock,
  User,
  Loader2,
  AlertCircle,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  KeyRound,
  FileSpreadsheet,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim() || !password) {
      setError('Please provide both your Login ID and password.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      await login(identifier.trim(), password);
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFillCredentials = (id: string, pass: string) => {
    setIdentifier(id);
    setPassword(pass);
    setError(null);
  };

  return (
    <div className="min-h-screen w-full bg-[#F5F5F7] text-[#1D1D1F] flex flex-col justify-between p-4 sm:p-6 lg:p-10 relative overflow-x-hidden font-sans selection:bg-[#0071E3]/20">
      
      {/* Session Expired / Secure Logout Notification Modal */}
      <LogoutModal onLoginAgain={() => setError(null)} />

      {/* Apple-style Multi-Layer Ambient Light Glow */}
      <div className="fixed top-0 left-1/4 w-[600px] h-[600px] bg-gradient-to-br from-blue-400/[0.08] via-indigo-300/[0.05] to-transparent rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed bottom-0 right-1/4 w-[600px] h-[600px] bg-gradient-to-tl from-sky-400/[0.07] via-slate-300/[0.05] to-transparent rounded-full blur-[150px] pointer-events-none -z-10" />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-white/[0.6] rounded-full blur-[160px] pointer-events-none -z-10" />

      {/* Top Center: Apple Frosted Header Pill (Resilient alignment at all zoom scales) */}
      <header className="w-full max-w-6xl mx-auto flex items-center justify-center pt-2 pb-6 lg:pb-8 shrink-0 relative z-20">
        <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-white/85 hover:bg-white backdrop-blur-2xl border border-slate-200/90 shadow-[0_2px_14px_rgba(0,0,0,0.04)] transition-all">
          <div className="w-6 h-6 rounded-lg bg-white p-0.5 flex items-center justify-center shrink-0 border border-slate-200/80 shadow-2xs">
            <img
              src="/alltake-icon.png"
              alt="Alltake Emblem"
              className="w-full h-full object-contain select-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-xs tracking-wider text-[#1D1D1F]">ALLTAKE</span>
            <span className="text-slate-300">·</span>
            <span className="text-[11px] font-medium text-slate-600 tracking-wide">DATA CORE SOFTWARE</span>
          </div>
        </div>
      </header>

      {/* Main Container: 2-Column Split Layout with strict no-overlap constraints */}
      <main className="w-full max-w-6xl mx-auto my-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10 py-2 sm:py-4">
        
        {/* LEFT COLUMN: Corporate Brand & 3 Featured Governance Boxes */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6 sm:space-y-7 min-w-0 w-full">
          <div>
            {/* Top Wide Brand Emblem Card */}
            <div className="inline-block p-3.5 sm:p-4 rounded-2xl bg-white/95 backdrop-blur-2xl border border-slate-200/90 shadow-[0_6px_24px_rgba(0,0,0,0.04)] mb-5 transition-all hover:border-slate-300">
              <img
                src="/alltake-logo-wide.png"
                alt="Alltake Data Core Software"
                className="w-auto h-10 sm:h-12 md:h-14 max-w-xs sm:max-w-sm object-contain select-none"
              />
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-[-0.03em] text-[#1D1D1F] leading-[1.14]">
              Alltake Data Core <br />
              <span className="text-[#0071E3] font-semibold">
                Software
              </span>
            </h1>

            <p className="mt-3.5 text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl font-normal">
              High-speed dataset exploration, role-based export governance, and real-time compliance audit infrastructure for enterprise lead operations.
            </p>
          </div>

          {/* The 3 Feature Boxes: Role Governance, Audited Access, Campaign Tracking (White Apple Card Treatment) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 w-full">
            
            {/* Box 1: Role Governance */}
            <div className="p-4 sm:p-4.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-slate-200/90 shadow-[0_4px_16px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)] hover:border-blue-200 transition-all flex flex-col justify-between space-y-3 min-w-0">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0071E3] border border-blue-100 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-medium font-mono px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100">
                  RBAC
                </span>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-semibold text-[#1D1D1F]">
                  Role Governance
                </h2>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Strict admin download limits, approval gatekeepers, and automated field masking.
                </p>
              </div>
            </div>

            {/* Box 2: Audited Access */}
            <div className="p-4 sm:p-4.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-slate-200/90 shadow-[0_4px_16px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)] hover:border-indigo-200 transition-all flex flex-col justify-between space-y-3 min-w-0">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-[#5E5CE6] border border-indigo-100 flex items-center justify-center shrink-0">
                  <KeyRound className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-medium font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                  SHA-256
                </span>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-semibold text-[#1D1D1F]">
                  Audited Access
                </h2>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Cryptographic, immutable ledger recording every query and CSV download event.
                </p>
              </div>
            </div>

            {/* Box 3: Campaign Tracking */}
            <div className="p-4 sm:p-4.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-slate-200/90 shadow-[0_4px_16px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)] hover:border-emerald-200 transition-all flex flex-col justify-between space-y-3 min-w-0">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#34C759] border border-emerald-100 flex items-center justify-center shrink-0">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-medium font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100">
                  Alerts
                </span>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-semibold text-[#1D1D1F]">
                  Campaign Tracking
                </h2>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Mandatory campaign naming with automated Resend email alerts sent to Admin.
                </p>
              </div>
            </div>

          </div>

          {/* Quick-fill Access Accounts (Apple Light Styling) */}
          <div className="pt-2 border-t border-slate-200/80">
            <div className="text-[11px] text-slate-500 mb-2 font-medium">Enterprise Pre-configured Accounts:</div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => handleFillCredentials('admin@alltake.com', 'Admin@Alltake2026!')}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200/90 text-xs font-medium text-slate-700 shadow-2xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <span className="w-2 h-2 rounded-full bg-[#0071E3]" />
                <span className="font-semibold text-[#1D1D1F]">Admin</span>
                <span className="text-[10px] text-slate-400 font-mono">admin@alltake.com</span>
              </button>
              <button
                type="button"
                onClick={() => handleFillCredentials('manager@alltake.com', 'Manager@Alltake2026!')}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200/90 text-xs font-medium text-slate-700 shadow-2xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <span className="w-2 h-2 rounded-full bg-[#5E5CE6]" />
                <span className="font-semibold text-[#1D1D1F]">Manager</span>
                <span className="text-[10px] text-slate-400 font-mono">manager@alltake.com</span>
              </button>
              <button
                type="button"
                onClick={() => handleFillCredentials('employee@alltake.com', 'Employee@Alltake2026!')}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200/90 text-xs font-medium text-slate-700 shadow-2xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <span className="w-2 h-2 rounded-full bg-[#34C759]" />
                <span className="font-semibold text-[#1D1D1F]">Employee</span>
                <span className="text-[10px] text-slate-400 font-mono">employee@alltake.com</span>
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Apple White Frosted Liquid Glass Login Card */}
        <div className="lg:col-span-5 w-full min-w-0">
          <div className="bg-white/90 backdrop-blur-2xl border border-slate-200/90 shadow-[0_20px_50px_rgba(0,0,0,0.06),0_1px_4px_rgba(0,0,0,0.03)] ring-1 ring-inset ring-white/90 rounded-3xl p-7 sm:p-9 text-[#1D1D1F] relative overflow-hidden transition-all">
            
            {/* Top Center Emblem inside Card */}
            <div className="flex flex-col items-center text-center mb-6 pb-5 border-b border-slate-100">
              <div className="relative group mb-3">
                <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200/80 shadow-[0_4px_16px_rgba(0,0,0,0.06)] p-2.5 flex items-center justify-center transition-all group-hover:scale-105 group-hover:border-slate-300">
                  <img
                    src="/alltake-icon.png"
                    alt="Alltake Official Emblem"
                    className="w-full h-full object-contain filter drop-shadow-2xs select-none"
                  />
                </div>
                <div className="absolute -inset-1 rounded-2xl bg-blue-500/10 -z-10 blur-md pointer-events-none" />
              </div>

              <h2 className="text-xl sm:text-2xl font-semibold text-[#1D1D1F] tracking-tight">
                Sign in to Workspace
              </h2>
              <p className="text-xs text-slate-500 mt-1 font-normal">
                Authorized Personnel Single Sign-On
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200/80 rounded-2xl text-rose-700 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                <div>
                  <span className="font-semibold block text-rose-900">Authentication Error</span>
                  <span className="text-[11px] leading-relaxed text-rose-700">{error}</span>
                </div>
              </div>
            )}

            {/* Login Form */}
            <form className="space-y-4" onSubmit={handleSubmit} noValidate>
              {/* Login ID Field */}
              <div>
                <label
                  htmlFor="login-id"
                  className="block text-xs font-semibold text-[#1D1D1F] mb-1.5"
                >
                  Login ID / Email Address
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="login-id"
                    name="username"
                    type="text"
                    autoComplete="username"
                    required
                    disabled={isLoading}
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="e.g. admin@alltake.com"
                    className="w-full pl-10 pr-3 py-2.5 text-xs bg-slate-50/90 hover:bg-white focus:bg-white border border-slate-200 focus:border-[#0071E3] rounded-xl text-[#1D1D1F] placeholder:text-slate-400 focus:outline-hidden focus:ring-4 focus:ring-blue-500/10 transition-all disabled:opacity-50"
                  />
                </div>
              </div>

              {/* Password Field */}
              <div>
                <label
                  htmlFor="password"
                  className="block text-xs font-semibold text-[#1D1D1F] mb-1.5"
                >
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    required
                    disabled={isLoading}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full pl-10 pr-10 py-2.5 text-xs bg-slate-50/90 hover:bg-white focus:bg-white border border-slate-200 focus:border-[#0071E3] rounded-xl text-[#1D1D1F] placeholder:text-slate-400 focus:outline-hidden focus:ring-4 focus:ring-blue-500/10 transition-all disabled:opacity-50 font-mono"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 absolute right-2.5 top-1/2 -translate-y-1/2 rounded focus:outline-hidden cursor-pointer transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Session Option */}
              <div className="flex items-center justify-between pt-0.5">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-3.5 h-3.5 rounded border-slate-300 text-[#0071E3] focus:ring-[#0071E3]"
                  />
                  <span className="text-xs text-slate-600 font-medium">Remember this device</span>
                </label>
              </div>

              {/* Apple-Style Vibrant Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#0071E3] hover:bg-[#0077ED] active:bg-[#0062C4] text-white text-xs font-semibold rounded-xl shadow-[0_4px_14px_rgba(0,113,227,0.25)] hover:shadow-[0_6px_20px_rgba(0,113,227,0.35)] transition-all duration-150 disabled:opacity-50 cursor-pointer focus:outline-hidden focus:ring-3 focus:ring-blue-400 active:scale-[0.99]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                      <span>Verifying Credentials...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              {/* Bottom Security Assurance */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1.5 font-medium text-emerald-600">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Session Protected</span>
                </span>
                <span className="font-medium text-slate-400">256-Bit SSL Encrypted</span>
              </div>
            </form>
          </div>

          {/* Secure Audit Notice */}
          <p className="text-center text-[11px] text-slate-500 mt-4 leading-relaxed font-normal">
            Authorized personnel only. All access, queries, and exports are monitored and recorded.
          </p>
        </div>

      </main>

      {/* Footer copyright note with guaranteed spacing */}
      <footer className="w-full max-w-6xl mx-auto pt-6 pb-2 text-center text-[11px] text-slate-400 shrink-0">
        Alltake Data Core Software · Enterprise Lead Governance & Compliance Infrastructure
      </footer>

    </div>
  );
};

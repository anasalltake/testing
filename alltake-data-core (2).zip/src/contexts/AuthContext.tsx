import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole } from '../types';
import { EnterpriseUser } from '../types/enterprise';
import { apiRequest } from '../api/client';

export interface LoggedOutUserInfo {
  fullName: string;
  email: string;
  role: string;
  timestamp: string;
}

interface AuthContextType {
  user: EnterpriseUser | null;
  token: string | null;
  isLoading: boolean;
  isSessionExpired: boolean;
  lastLoggedOutUser: LoggedOutUserInfo | null;
  login: (identifier: string, password?: string) => Promise<void>;
  logout: () => Promise<void>;
  clearLogoutModal: () => void;
  switchDemoRole: (role: UserRole) => Promise<void>;
  refreshCurrentUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<EnterpriseUser | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('alltake_auth_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSessionExpired, setIsSessionExpired] = useState<boolean>(false);
  const [lastLoggedOutUser, setLastLoggedOutUser] = useState<LoggedOutUserInfo | null>(null);

  const verifySession = async () => {
    const storedToken = localStorage.getItem('alltake_auth_token');
    const storedUser = localStorage.getItem('alltake_auth_user');
    if (!storedToken || !storedUser) {
      setIsLoading(false);
      return;
    }

    try {
      // Verify JWT cryptographically with the backend API
      const res = await apiRequest<{ success: boolean; user: EnterpriseUser }>('/auth/me');
      if (res.success && res.user) {
        if (res.user.status === 'BLOCKED') {
          localStorage.removeItem('alltake_auth_token');
          localStorage.removeItem('alltake_auth_user');
          setUser(null);
          setToken(null);
          setIsSessionExpired(true);
          return;
        }
        setUser(res.user);
        setToken(storedToken);
        localStorage.setItem('alltake_auth_user', JSON.stringify(res.user));
        return;
      }
    } catch (jwtErr: any) {
      // Token expired or invalidated
      localStorage.removeItem('alltake_auth_token');
      localStorage.removeItem('alltake_auth_user');
      setUser(null);
      setToken(null);
      setIsSessionExpired(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    verifySession();
  }, []);

  const login = async (identifier: string, password?: string) => {
    setIsLoading(true);
    setIsSessionExpired(false);
    try {
      const res = await apiRequest<{ success: boolean; token: string; user: EnterpriseUser }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier: identifier.trim(), password: password || '' }),
      });
      if (res.success && res.user && res.token) {
        localStorage.setItem('alltake_auth_token', res.token);
        localStorage.setItem('alltake_auth_user', JSON.stringify(res.user));
        setToken(res.token);
        setUser(res.user);
        setLastLoggedOutUser(null);
        return;
      }
      throw new Error('Authentication failed. Please verify credentials.');
    } catch (err: any) {
      const msg = err.message || 'Invalid credentials provided';
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    const currentUser = user;
    if (currentUser) {
      setLastLoggedOutUser({
        fullName: currentUser.full_name || currentUser.username || 'Valued User',
        email: currentUser.email,
        role: currentUser.role,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
    }

    try {
      // Invalidate token on server side
      await apiRequest('/auth/logout', { method: 'POST' }).catch(() => {});
    } catch {
      // Proceed with local logout regardless of network
    }

    localStorage.removeItem('alltake_auth_token');
    localStorage.removeItem('alltake_auth_user');
    setToken(null);
    setUser(null);
  };

  const clearLogoutModal = () => {
    setLastLoggedOutUser(null);
    setIsSessionExpired(false);
  };

  const switchDemoRole = async (role: UserRole) => {
    let email = 'admin@alltake.com';
    let pwd = 'Admin@Alltake2026!';
    if (role === 'DATA_MANAGER') {
      email = 'manager@alltake.com';
      pwd = 'Manager@Alltake2026!';
    } else if (role === 'EMPLOYEE') {
      email = 'employee@alltake.com';
      pwd = 'Employee@Alltake2026!';
    }
    await login(email, pwd);
  };

  const refreshCurrentUser = async () => {
    await verifySession();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        isSessionExpired,
        lastLoggedOutUser,
        login,
        logout,
        clearLogoutModal,
        switchDemoRole,
        refreshCurrentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

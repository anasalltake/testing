import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { AuditLog } from '../../types';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import { ShieldAlert, Search, RefreshCw, ChevronLeft, ChevronRight, Eye } from 'lucide-react';
import { Modal } from '../common/Modal';

export const AuditLogsViewer: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(50);
  const [totalPages, setTotalPages] = useState(1);
  const [actionFilter, setActionFilter] = useState('ALL');
  const [userSearch, setUserSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
      });
      if (actionFilter && actionFilter !== 'ALL') params.append('action', actionFilter);
      if (userSearch) params.append('user', userSearch);

      const res = await apiRequest<{
        success: boolean;
        logs: AuditLog[];
        total: number;
        total_pages: number;
      }>(`/logs/audit?${params.toString()}`);

      if (res.success) {
        setLogs(res.logs || []);
        setTotal(res.total || 0);
        setTotalPages(res.total_pages || 1);
      }
    } catch (err) {
      console.error('Failed to load audit logs', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [page, limit, actionFilter]);

  const getActionBadge = (action: string) => {
    if (action.includes('LOGIN')) return <Badge variant="success">LOGIN</Badge>;
    if (action.includes('LOGOUT')) return <Badge variant="neutral">LOGOUT</Badge>;
    if (action.includes('UPLOAD')) return <Badge variant="primary">CSV UPLOAD</Badge>;
    if (action.includes('EXPORT')) return <Badge variant="primary">EXPORT</Badge>;
    if (action.includes('USER_CREATED')) return <Badge variant="success">USER CREATED</Badge>;
    if (action.includes('USER_DISABLED')) return <Badge variant="danger">USER DISABLED</Badge>;
    if (action.includes('PASSWORD')) return <Badge variant="warning">PASSWORD CHANGE</Badge>;
    return <Badge>{action}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-blue-600" />
            Compliance & System Audit Trail
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable log of all user logins, administrative modifications, CSV ingestions, and exports
          </p>
        </div>

        <button
          onClick={loadLogs}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
          <span>Refresh Audit Trail</span>
        </button>
      </div>

      {/* Filter bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-3">
        <div className="sm:col-span-8 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={userSearch}
            onChange={(e) => setUserSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && loadLogs()}
            placeholder="Filter by operator name or user ID..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          />
        </div>

        <div className="sm:col-span-4">
          <select
            value={actionFilter}
            onChange={(e) => {
              setActionFilter(e.target.value);
              setPage(1);
            }}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600 bg-white text-slate-700"
          >
            <option value="ALL">All Recorded Actions</option>
            <option value="LOGIN">LOGIN</option>
            <option value="LOGOUT">LOGOUT</option>
            <option value="CSV_UPLOADED">CSV_UPLOADED</option>
            <option value="EXPORT_STARTED">EXPORT_STARTED</option>
            <option value="EXPORT_COMPLETED">EXPORT_COMPLETED</option>
            <option value="USER_CREATED">USER_CREATED</option>
            <option value="USER_UPDATED">USER_UPDATED</option>
            <option value="USER_DISABLED">USER_DISABLED</option>
            <option value="PASSWORD_CHANGED">PASSWORD_CHANGED</option>
          </select>
        </div>
      </div>

      {/* Audit Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Action</th>
                <th className="py-3 px-4 font-semibold">User Operator</th>
                <th className="py-3 px-4 font-semibold">Entity Target</th>
                <th className="py-3 px-4 font-semibold">Network IP</th>
                <th className="py-3 px-4 font-semibold text-right">Timestamp</th>
                <th className="py-3 px-4 font-semibold text-center">Payload</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 font-sans">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center">
                    <LoadingSpinner text="Retrieving audit records..." />
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No audit records matching parameters.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">{getActionBadge(log.action)}</td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">{log.user_name}</span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {log.user_role} {log.user_id ? `• ${log.user_id}` : ''}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {log.entity_type} {log.entity_id ? `(${log.entity_id})` : ''}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                      {log.ip_address || '127.0.0.1'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => setSelectedLog(log)}
                        className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-md transition-colors"
                        title="Inspect event details payload"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-600">
          <div>
            Total <strong className="font-mono text-slate-900">{total}</strong> audit entries
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono">
              Page {page} of {totalPages || 1}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Payload Modal */}
      <Modal
        isOpen={!!selectedLog}
        onClose={() => setSelectedLog(null)}
        title="Audit Event Metadata Payload"
        subtitle={`Action: ${selectedLog?.action} by ${selectedLog?.user_name}`}
        maxWidth="md"
      >
        <div className="space-y-3">
          <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono overflow-x-auto max-h-72">
            {selectedLog &&
              JSON.stringify(
                typeof selectedLog.details_json === 'string'
                  ? JSON.parse(selectedLog.details_json || '{}')
                  : selectedLog.details || {},
                null,
                2
              )}
          </pre>

          <div className="text-[11px] text-slate-500 font-mono space-y-1 pt-2 border-t border-slate-200">
            <p>Event ID: {selectedLog?.id}</p>
            <p>Timestamp: {selectedLog?.created_at}</p>
            <p>IP Address: {selectedLog?.ip_address}</p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

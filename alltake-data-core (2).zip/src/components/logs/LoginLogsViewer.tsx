import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { LoginLog } from '../../types';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import { History, RefreshCw, ChevronLeft, ChevronRight, Lock, CheckCircle2, XCircle } from 'lucide-react';

export const LoginLogsViewer: React.FC = () => {
  const [logs, setLogs] = useState<LoginLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(50);
  const [totalPages, setTotalPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [isLoading, setIsLoading] = useState(true);

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
      });
      if (statusFilter && statusFilter !== 'ALL') params.append('status', statusFilter);

      const res = await apiRequest<{
        success: boolean;
        logs: LoginLog[];
        total: number;
        total_pages: number;
      }>(`/logs/logins?${params.toString()}`);

      if (res.success) {
        setLogs(res.logs || []);
        setTotal(res.total || 0);
        setTotalPages(res.total_pages || 1);
      }
    } catch (err) {
      console.error('Failed to load login logs', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [page, limit, statusFilter]);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            Security & Authentication Logs
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Tracks all successful and rejected authentication attempts with client IP and browser agents
          </p>
        </div>

        <button
          onClick={loadLogs}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
          <span>Refresh Login Logs</span>
        </button>
      </div>

      {/* Filter */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">Attempt Result:</span>
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white text-slate-700 font-mono"
          >
            <option value="ALL">All Authentication Attempts</option>
            <option value="SUCCESS">SUCCESSFUL LOGINS</option>
            <option value="FAILED">FAILED / BLOCKED LOGINS</option>
          </select>
        </div>

        <span className="text-xs text-slate-500 font-mono">
          Total: <strong className="text-slate-900">{total}</strong> attempts
        </span>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold">Account Identifier</th>
                <th className="py-3 px-4 font-semibold">IP Address</th>
                <th className="py-3 px-4 font-semibold">Client Agent</th>
                <th className="py-3 px-4 font-semibold">Reason</th>
                <th className="py-3 px-4 font-semibold text-right">Timestamp</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 font-sans">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center">
                    <LoadingSpinner text="Retrieving login security records..." />
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No login logs recorded matching criteria.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 text-center">
                      <Badge variant={log.status === 'SUCCESS' ? 'success' : 'danger'} size="sm">
                        {log.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">{log.email}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{log.ip_address || '127.0.0.1'}</td>
                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate text-[11px]" title={log.user_agent}>
                      {log.user_agent || 'Unknown'}
                    </td>
                    <td className="py-3 px-4">
                      {log.failure_reason ? (
                        <span className="font-mono text-[11px] text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          {log.failure_reason}
                        </span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-600">
          <div>
            Page <strong className="font-mono">{page}</strong> of{' '}
            <strong className="font-mono">{totalPages || 1}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { CountryStat } from '../../types';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Globe2, Search, ArrowUpDown, TrendingUp, BarChart2 } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

interface CountryAnalyticsProps {
  onSelectCountryFilter?: (country: string) => void;
}

const COLORS = ['#2563EB', '#3B82F6', '#60A5FA', '#10B981', '#059669', '#F59E0B', '#8B5CF6', '#EC4899', '#64748B'];

export const CountryAnalytics: React.FC<CountryAnalyticsProps> = ({ onSelectCountryFilter }) => {
  const [countries, setCountries] = useState<CountryStat[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  useEffect(() => {
    async function loadCountryData() {
      setIsLoading(true);
      try {
        const res = await apiRequest<{ success: boolean; countries: CountryStat[] }>('/data/countries');
        if (res.success && res.countries) {
          setCountries(res.countries);
        }
      } catch (err) {
        console.error('Failed to load country statistics', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadCountryData();
  }, []);

  const totalLeads = countries.reduce((acc, curr) => acc + (curr.leads || curr.count || 0), 0);

  const filteredCountries = countries.filter((c) =>
    c.country.toLowerCase().includes(search.toLowerCase())
  );

  const sortedCountries = [...filteredCountries].sort((a, b) => {
    const valA = a.leads || a.count || 0;
    const valB = b.leads || b.count || 0;
    return sortOrder === 'desc' ? valB - valA : valA - valB;
  });

  const chartData = countries.slice(0, 8).map((c) => ({
    name: c.country,
    leads: c.leads || c.count || 0,
  }));

  if (isLoading) {
    return <LoadingSpinner text="Computing country-wise aggregation from database..." />;
  }

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-blue-600" />
            Country-Wise Analytics
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Geographic lead distribution across all verified enterprise datasets
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <span className="text-slate-500">Countries: </span>
            <strong className="text-slate-900">{countries.length}</strong>
          </div>
          <div className="bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg text-blue-800">
            <span className="text-blue-600">Total Leads: </span>
            <strong className="text-blue-950">{totalLeads.toLocaleString()}</strong>
          </div>
        </div>
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Bar Chart */}
        <div className="lg:col-span-8 bg-white p-5 rounded-xl border border-slate-200">
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-4 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-blue-600" />
            Top Lead Concentration by Country
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis
                  dataKey="name"
                  stroke="#64748b"
                  fontSize={11}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  formatter={(val: any) => [`${Number(val).toLocaleString()} leads`, 'Volume']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#f8fafc',
                  }}
                />
                <Bar dataKey="leads" radius={[4, 4, 0, 0]}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut Chart */}
        <div className="lg:col-span-4 bg-white p-5 rounded-xl border border-slate-200 flex flex-col justify-between">
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            Geographic Share
          </h3>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  dataKey="leads"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={2}
                >
                  {chartData.map((_, index) => (
                    <Cell key={`donut-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${Number(val).toLocaleString()} leads`, 'Share']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-600 pt-2 border-t border-slate-100">
            {chartData.slice(0, 4).map((c, i) => (
              <div key={c.name} className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: COLORS[i] }}
                />
                <span className="truncate">{c.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Country Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search country..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600 placeholder:text-slate-400"
            />
          </div>

          <button
            onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
            className="flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 px-3 py-1.5 rounded-lg"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>Sort by Count ({sortOrder === 'desc' ? 'High to Low' : 'Low to High'})</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono text-[11px] uppercase border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold w-12 text-center">#</th>
                <th className="py-3 px-4 font-semibold">Country Name</th>
                <th className="py-3 px-4 font-semibold text-right">Lead Count</th>
                <th className="py-3 px-4 font-semibold text-right">Market Share</th>
                <th className="py-3 px-4 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedCountries.map((c, idx) => {
                const count = c.leads || c.count || 0;
                const percentage = totalLeads > 0 ? ((count / totalLeads) * 100).toFixed(1) : '0';

                return (
                  <tr key={c.country} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-4 text-center font-mono text-slate-400 text-[11px]">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-blue-600" />
                        {c.country}
                      </div>
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900">
                      {count.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-slate-500">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-blue-600 h-1.5 rounded-full"
                            style={{ width: `${Math.min(100, parseFloat(percentage) * 2.5)}%` }}
                          />
                        </div>
                        <span>{percentage}%</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {onSelectCountryFilter && (
                        <button
                          onClick={() => onSelectCountryFilter(c.country)}
                          className="px-2.5 py-1 text-[11px] font-medium text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-200 hover:border-blue-600 rounded-md transition-colors"
                        >
                          Explore Leads
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

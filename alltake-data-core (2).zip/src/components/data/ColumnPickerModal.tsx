import React from 'react';
import { Modal } from '../common/Modal';
import { DatasetColumn } from '../../types';
import { Check } from 'lucide-react';

interface ColumnPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableColumns: DatasetColumn[];
  visibleColumns: string[];
  onToggleColumn: (columnName: string) => void;
  onResetDefaults: () => void;
}

export const ColumnPickerModal: React.FC<ColumnPickerModalProps> = ({
  isOpen,
  onClose,
  availableColumns,
  visibleColumns,
  onToggleColumn,
  onResetDefaults,
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Customize Table Columns"
      subtitle="Select which fields to display in the Data Explorer view"
      maxWidth="md"
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <span className="text-xs text-slate-500 font-medium">
            {visibleColumns.length} of {availableColumns.length} visible
          </span>
          <button
            onClick={onResetDefaults}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            Reset to Standard
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
          {availableColumns.map((col) => {
            const isChecked = visibleColumns.includes(col.column_name);
            return (
              <label
                key={col.column_name}
                className={`flex items-center justify-between p-2.5 rounded-lg border text-xs cursor-pointer transition-all ${
                  isChecked
                    ? 'border-blue-300 bg-blue-50/50 text-blue-900 font-medium'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                      isChecked
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span className="truncate">{col.display_name}</span>
                </div>
                {col.is_core ? (
                  <span className="text-[10px] text-slate-400 font-mono">core</span>
                ) : (
                  <span className="text-[10px] text-blue-600 font-mono bg-blue-100/60 px-1 rounded">
                    dynamic
                  </span>
                )}
              </label>
            );
          })}
        </div>

        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-lg shadow-xs"
          >
            Apply View Settings
          </button>
        </div>
      </div>
    </Modal>
  );
};

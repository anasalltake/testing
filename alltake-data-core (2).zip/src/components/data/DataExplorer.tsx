import React, { useState, useEffect, useCallback } from 'react';
import { apiRequest } from '../../api/client';
import { DatasetRecord, DatasetColumn, PaginatedResponse, Dataset } from '../../types';
import { ColumnPickerModal } from './ColumnPickerModal';
import { ExportModal } from './ExportModal';
import { TableSkeleton } from '../common/SkeletonLoader';
import { EmptyState, ErrorState } from '../common/FeedbackStates';
import {
  Search,
  Filter,
  Columns,
  Download,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  Building,
  MapPin,
  Mail,
  Phone,
  Briefcase,
  Layers,
  X,
  Check,
} from 'lucide-react';

interface DataExplorerProps {
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
  initialCountryFilter?: string;
}

export const DataExplorer: React.FC<DataExplorerProps> = ({
  onNotify,
  initialCountryFilter = '',
}) => {
  // Data state
  const [records, setRecords] = useState<DatasetRecord[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Facet options from backend
  const [countryOptions, setCountryOptions] = useState<string[]>([]);
  const [datasetOptions, setDatasetOptions] = useState<Dataset[]>([]);

  // Filtering & Pagination State
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(50);
  const [search, setSearch] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(initialCountryFilter);
  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedDatasetId, setSelectedDatasetId] = useState('');
  const [sortBy, setSortBy] = useState('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Applied Filter Snapshot (applied on button click or chip remove)
  const [appliedFilters, setAppliedFilters] = useState({
    search: '',
    country: initialCountryFilter,
    state: '',
    city: '',
    company: '',
    dataset_id: '',
  });

  // Dynamic columns state
  const [availableColumns, setAvailableColumns] = useState<DatasetColumn[]>([]);
  const [visibleColumnKeys, setVisibleColumnKeys] = useState<string[]>([
    'name',
    'email',
    'company',
    'job_title',
    'country',
    'state',
    'phone',
  ]);
  const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Fetch facets & dynamic columns
  useEffect(() => {
    async function loadMetadata() {
      try {
        const [facetsRes, colsRes] = await Promise.all([
          apiRequest<{ success: boolean; countries: string[]; datasets: Dataset[] }>('/data/facets'),
          apiRequest<{ success: boolean; columns: DatasetColumn[] }>('/data/columns'),
        ]);

        if (facetsRes.success) {
          setCountryOptions(facetsRes.countries || []);
          setDatasetOptions(facetsRes.datasets || []);
        }

        if (colsRes.success && colsRes.columns) {
          setAvailableColumns(colsRes.columns);
          const allKeys = colsRes.columns.map((c) => c.column_name);
          const initial = ['name', 'email', 'company', 'job_title', 'country', 'state', 'phone'];
          colsRes.columns.forEach((c) => {
            if (!c.is_core && !initial.includes(c.column_name) && initial.length < 9) {
              initial.push(c.column_name);
            }
          });
          setVisibleColumnKeys(initial.filter((k) => allKeys.includes(k)));
        }
      } catch (err: any) {
        console.error('Failed to load explorer metadata', err);
      }
    }
    loadMetadata();
  }, []);

  // Fetch records
  const fetchRecords = useCallback(async () => {
    setIsLoading(true);
    setHasError(false);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString(),
        sort: sortBy,
        order: sortOrder,
      });

      if (appliedFilters.search) params.append('search', appliedFilters.search);
      if (appliedFilters.country) params.append('country', appliedFilters.country);
      if (appliedFilters.state) params.append('state', appliedFilters.state);
      if (appliedFilters.city) params.append('city', appliedFilters.city);
      if (appliedFilters.company) params.append('company', appliedFilters.company);
      if (appliedFilters.dataset_id) params.append('dataset_id', appliedFilters.dataset_id);

      const res = await apiRequest<PaginatedResponse<DatasetRecord>>(`/data?${params.toString()}`);

      if (res.success) {
        setRecords(res.data);
        setTotalCount(res.total);
        setTotalPages(res.total_pages || 1);
      }
    } catch (err: any) {
      setHasError(true);
      setErrorMessage(err.message || 'Failed to fetch dataset records');
    } finally {
      setIsLoading(false);
    }
  }, [page, limit, appliedFilters, sortBy, sortOrder]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  // Apply filters button
  const handleApplyFilters = () => {
    setAppliedFilters({
      search: search.trim(),
      country: selectedCountry,
      state: selectedState.trim(),
      city: selectedCity.trim(),
      company: selectedCompany.trim(),
      dataset_id: selectedDatasetId,
    });
    setPage(1);
  };

  // Clear all filters
  const handleClearAll = () => {
    setSearch('');
    setSelectedCountry('');
    setSelectedState('');
    setSelectedCity('');
    setSelectedCompany('');
    setSelectedDatasetId('');
    setAppliedFilters({
      search: '',
      country: '',
      state: '',
      city: '',
      company: '',
      dataset_id: '',
    });
    setPage(1);
    setSortBy('created_at');
    setSortOrder('desc');
  };

  // Remove individual filter chip
  const handleRemoveChip = (key: keyof typeof appliedFilters) => {
    if (key === 'search') setSearch('');
    if (key === 'country') setSelectedCountry('');
    if (key === 'state') setSelectedState('');
    if (key === 'city') setSelectedCity('');
    if (key === 'company') setSelectedCompany('');
    if (key === 'dataset_id') setSelectedDatasetId('');

    setAppliedFilters((prev) => ({
      ...prev,
      [key]: '',
    }));
    setPage(1);
  };

  const handleSort = (columnKey: string) => {
    if (sortBy === columnKey) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(columnKey);
      setSortOrder('asc');
    }
    setPage(1);
  };

  const activeChips = Object.entries(appliedFilters).filter(([_, val]) => Boolean(val));

  return (
    <div className="space-y-3.5">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white px-4 py-3 rounded-lg border border-slate-200/90 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold text-slate-900 tracking-tight">Data Explorer</h1>
            <span className="text-xs px-2 py-0.5 rounded font-mono font-medium bg-slate-100 text-slate-700 border border-slate-200">
              {totalCount.toLocaleString()} Records
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Indexed PostgreSQL leads repository with clinical search & dynamic schema mapping
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsColumnPickerOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md shadow-2xs transition-colors"
          >
            <Columns className="w-3.5 h-3.5 text-slate-500" />
            <span>Columns ({visibleColumnKeys.length})</span>
          </button>

          <button
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export ({totalCount.toLocaleString()})</span>
          </button>
        </div>
      </div>

      {/* Professional Filter Toolbar */}
      <div className="bg-white p-3.5 rounded-lg border border-slate-200/90 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 lg:grid-cols-12 gap-2.5">
          {/* Search Input */}
          <div className="md:col-span-3 relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleApplyFilters()}
              placeholder="Search records..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-600 focus:border-blue-600 font-sans"
            />
          </div>

          {/* Dataset selector */}
          <div className="md:col-span-2">
            <select
              value={selectedDatasetId}
              onChange={(e) => setSelectedDatasetId(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            >
              <option value="">Dataset: All</option>
              {datasetOptions.map((ds) => (
                <option key={ds.id} value={ds.id}>
                  {ds.name}
                </option>
              ))}
            </select>
          </div>

          {/* Country selector */}
          <div className="md:col-span-2">
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            >
              <option value="">Country: All</option>
              {countryOptions.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* State input */}
          <div className="md:col-span-2">
            <input
              type="text"
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleApplyFilters()}
              placeholder="State: All"
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            />
          </div>

          {/* Company input */}
          <div className="md:col-span-2">
            <input
              type="text"
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleApplyFilters()}
              placeholder="Company: All"
              className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            />
          </div>

          {/* Actions: Apply & Clear */}
          <div className="md:col-span-1 flex items-center gap-1.5">
            <button
              onClick={handleApplyFilters}
              className="flex-1 py-1.5 px-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-md shadow-2xs transition-colors text-center"
            >
              Apply
            </button>
            <button
              onClick={handleClearAll}
              title="Clear all filters"
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Removable Filter Chips Bar */}
        {activeChips.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 text-xs">
            <span className="text-[11px] font-semibold text-slate-400 uppercase font-mono mr-1">
              Active:
            </span>
            {activeChips.map(([k, val]) => (
              <span
                key={k}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] bg-blue-50 text-blue-800 border border-blue-200/80 font-medium"
              >
                <span className="capitalize">{k}:</span>
                <span className="font-semibold">{String(val)}</span>
                <button
                  onClick={() => handleRemoveChip(k as any)}
                  className="p-0.5 hover:text-rose-600 ml-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
            <button
              onClick={handleClearAll}
              className="text-[11px] text-slate-500 hover:text-slate-800 underline ml-2"
            >
              Reset all
            </button>
          </div>
        )}
      </div>

      {/* Main Data Table */}
      {hasError ? (
        <ErrorState
          title="Query Execution Failed"
          message={errorMessage}
          onRetry={fetchRecords}
        />
      ) : isLoading ? (
        <TableSkeleton rows={10} columns={visibleColumnKeys.length + 1} />
      ) : records.length === 0 ? (
        <div className="bg-white rounded-lg border border-slate-200 shadow-2xs">
          <EmptyState
            title="No records matching current filters"
            description="Adjust your search query, country, or company parameters."
            actionText="Clear Filter Chips"
            onAction={handleClearAll}
          />
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-slate-200/90 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto max-h-[640px] relative">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 z-20 bg-slate-900 text-white font-mono uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2.5 px-3 font-semibold text-slate-300 border-b border-slate-800 w-10 text-center">
                    #
                  </th>
                  {visibleColumnKeys.map((key) => {
                    const colDef = availableColumns.find((c) => c.column_name === key);
                    const displayName = colDef?.display_name || key.replace(/_/g, ' ');
                    const isSorted = sortBy === key;

                    return (
                      <th
                        key={key}
                        onClick={() => handleSort(key)}
                        className="py-2.5 px-3 font-semibold text-slate-200 border-b border-slate-800 cursor-pointer select-none hover:bg-slate-800 transition-colors whitespace-nowrap"
                      >
                        <div className="flex items-center gap-1.5">
                          <span>{displayName}</span>
                          <ArrowUpDown
                            className={`w-3 h-3 ${isSorted ? 'text-blue-400' : 'text-slate-500'}`}
                          />
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100 font-sans">
                {records.map((row, idx) => {
                  const rowNumber = (page - 1) * limit + idx + 1;
                  return (
                    <tr
                      key={row.id || idx}
                      className="hover:bg-slate-50/80 transition-colors group h-9"
                    >
                      <td className="py-1.5 px-3 text-center font-mono text-slate-400 text-[11px] bg-slate-50/50">
                        {rowNumber}
                      </td>
                      {visibleColumnKeys.map((colKey) => {
                        const val = row[colKey];
                        const isEmail = colKey === 'email';
                        const isCountry = colKey === 'country';

                        return (
                          <td
                            key={colKey}
                            className="py-1.5 px-3 text-slate-700 whitespace-nowrap max-w-xs truncate font-sans text-xs"
                          >
                            {isCountry ? (
                              <span className="inline-flex items-center gap-1 font-medium text-slate-900">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                                {val || 'Unknown'}
                              </span>
                            ) : isEmail ? (
                              <span className="font-mono text-[11px] text-blue-700">{val || '—'}</span>
                            ) : (
                              val ?? '—'
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="flex flex-col sm:flex-row items-center justify-between px-3.5 py-2.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-600 gap-3 font-mono">
            <div>
              Records{' '}
              <strong className="text-slate-900">
                {(page - 1) * limit + 1}–{Math.min(page * limit, totalCount)}
              </strong>{' '}
              of <strong className="text-slate-900">{totalCount.toLocaleString()}</strong>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-slate-500 font-sans">
                <span>Rows:</span>
                <select
                  value={limit}
                  onChange={(e) => {
                    setLimit(Number(e.target.value));
                    setPage(1);
                  }}
                  className="px-2 py-0.5 text-xs border border-slate-300 rounded bg-white text-slate-800"
                >
                  <option value="25">25</option>
                  <option value="50">50</option>
                  <option value="100">100</option>
                  <option value="250">250</option>
                </select>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page <= 1}
                  className="p-1 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
                  title="Previous Page"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <span className="px-2 text-slate-700">
                  {page} / {totalPages || 1}
                </span>
                <button
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={page >= totalPages}
                  className="p-1 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40"
                  title="Next Page"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <ColumnPickerModal
        isOpen={isColumnPickerOpen}
        onClose={() => setIsColumnPickerOpen(false)}
        availableColumns={availableColumns}
        visibleColumns={visibleColumnKeys}
        onToggleColumn={(col) => {
          setVisibleColumnKeys((prev) =>
            prev.includes(col) ? prev.filter((k) => k !== col) : [...prev, col]
          );
        }}
        onResetDefaults={() => {
          setVisibleColumnKeys(['name', 'email', 'company', 'job_title', 'country', 'state', 'phone']);
        }}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        matchingCount={totalCount}
        currentFilters={appliedFilters}
        onExportSuccess={(msg) => onNotify('success', msg)}
      />
    </div>
  );
};

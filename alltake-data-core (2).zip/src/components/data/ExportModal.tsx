import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { apiRequest } from '../../api/client';
import { FileSpreadsheet, FileText, Download, CheckCircle2, Loader2, AlertCircle } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  matchingCount: number;
  currentFilters: Record<string, any>;
  onExportSuccess: (message: string) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  matchingCount,
  currentFilters,
  onExportSuccess,
}) => {
  const [format, setFormat] = useState<'CSV' | 'EXCEL'>('CSV');
  const [datasetName, setDatasetName] = useState('Alltake Filtered Leads Export');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartExport = async () => {
    setIsSubmitting(true);
    setError(null);

    try {
      const res = await apiRequest<{ success: boolean; job_id: string; message: string }>(
        '/exports/create',
        {
          method: 'POST',
          body: JSON.stringify({
            format,
            filters: currentFilters,
            dataset_name: datasetName,
          }),
        }
      );

      if (res.success) {
        onExportSuccess(
          `Export job created for ${matchingCount.toLocaleString()} records in ${format} format. Check Export Center to download.`
        );
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Failed to initiate export process');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Export Dataset"
      subtitle="Generate filtered lead records in professional CSV or Excel spreadsheet format"
      maxWidth="md"
    >
      <div className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Record count banner */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 font-medium">Matching Filtered Records</span>
              <p className="text-2xl font-bold font-mono text-slate-900 mt-0.5">
                {matchingCount.toLocaleString()}
              </p>
            </div>
            <div className="px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-semibold text-blue-700">
              Server Verified
            </div>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-200/60 text-[11px] text-slate-500">
            Active filters: {Object.keys(currentFilters).filter((k) => currentFilters[k]).length || 'None (All Records)'}
          </div>
        </div>

        {/* Format selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Select Output Format
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setFormat('CSV')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all ${
                format === 'CSV'
                  ? 'border-blue-600 bg-blue-50/40 ring-1 ring-blue-600'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`p-2 rounded-lg ${
                  format === 'CSV' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900">Standard CSV</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Best for large datasets & CRM imports
                </p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setFormat('EXCEL')}
              className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all ${
                format === 'EXCEL'
                  ? 'border-emerald-600 bg-emerald-50/40 ring-1 ring-emerald-600'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`p-2 rounded-lg ${
                  format === 'EXCEL' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900">Microsoft Excel (.xlsx)</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Styled headers & auto-fit columns
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* File / Job Title */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Export Job Label
          </label>
          <input
            type="text"
            value={datasetName}
            onChange={(e) => setDatasetName(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            placeholder="e.g. Q1 North America Leads"
          />
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-lg"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleStartExport}
            disabled={isSubmitting || matchingCount === 0}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-medium rounded-lg shadow-xs flex items-center gap-1.5"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Queueing Job...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Start Background Export
              </>
            )}
          </button>
        </div>
      </div>
    </Modal>
  );
};

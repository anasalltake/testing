import React, { useState, useEffect } from 'react';
import {
  X,
  KeyRound,
  ShieldCheck,
  Eye,
  EyeOff,
  Copy,
  Check,
  RefreshCw,
  Loader2,
  Lock,
  AlertCircle,
  UserCheck
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { EnterpriseUser } from '../../types/enterprise';
import { getAllUsers, resetEnterpriseUserPassword } from '../../services/enterpriseDb';
import { apiRequest } from '../../api/client';

interface SetPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser?: EnterpriseUser | null;
  onSuccess?: (msg: string) => void;
}

export const SetPasswordModal: React.FC<SetPasswordModalProps> = ({
  isOpen,
  onClose,
  targetUser: propTargetUser,
  onSuccess,
}) => {
  const { user: currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'ADMIN';

  const [usersList, setUsersList] = useState<EnterpriseUser[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    setErrorMsg(null);
    setSuccessMsg(null);
    setNewPassword('');
    setConfirmPassword('');

    if (propTargetUser) {
      setSelectedUserId(propTargetUser.id);
    } else if (isAdmin) {
      getAllUsers().then((users) => {
        setUsersList(users);
        if (users && users.length > 0) {
          const defaultEmp = users.find((u) => u.role === 'EMPLOYEE') || users[0];
          setSelectedUserId(defaultEmp.id);
        }
      });
    }
  }, [isOpen, propTargetUser, isAdmin, currentUser]);

  if (!isOpen) return null;

  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fade-in font-sans">
        <div className="w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-2xl p-6 sm:p-8 text-[#1D1D1F] text-center">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 mx-auto flex items-center justify-center mb-4">
            <Lock className="w-6 h-6 stroke-[1.8]" />
          </div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">Access Restricted</h2>
          <p className="mt-2 text-xs text-slate-600 leading-relaxed">
            Only Administrators are authorized to set or reset employee passwords in Alltake Data Core Software. Employees cannot change credentials directly.
          </p>
          <div className="mt-5">
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Understood
            </button>
          </div>
        </div>
      </div>
    );
  }

  const activeTarget = propTargetUser || usersList.find((u) => u.id === selectedUserId) || currentUser;

  const generateStrongPassword = () => {
    const specials = '!@#$%&*';
    const uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowers = 'abcdefghijkmnpqrstuvwxyz';
    const digits = '23456789';

    let generated = 'Alltake@';
    for (let i = 0; i < 2; i++) generated += uppers.charAt(Math.floor(Math.random() * uppers.length));
    for (let i = 0; i < 3; i++) generated += lowers.charAt(Math.floor(Math.random() * lowers.length));
    for (let i = 0; i < 2; i++) generated += digits.charAt(Math.floor(Math.random() * digits.length));
    generated += specials.charAt(Math.floor(Math.random() * specials.length));

    setNewPassword(generated);
    setConfirmPassword(generated);
    setCopied(false);
    setErrorMsg(null);
  };

  const handleCopy = () => {
    if (!newPassword) return;
    navigator.clipboard.writeText(newPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!newPassword) {
      setErrorMsg('Please specify a new password.');
      return;
    }

    if (newPassword.length < 8) {
      setErrorMsg('Password must be at least 8 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('New password and confirmation do not match.');
      return;
    }

    if (!activeTarget) {
      setErrorMsg('No user account selected.');
      return;
    }

    setIsLoading(true);

    try {
      if (isAdmin && activeTarget.id !== currentUser?.id) {
        // Admin setting password for another user without needing existing password
        const res = await resetEnterpriseUserPassword(activeTarget.id, newPassword);
        const msg = res.message || `Password successfully set for ${activeTarget.full_name} (${activeTarget.email}).`;
        setSuccessMsg(msg);
        if (onSuccess) onSuccess(msg);
      } else {
        // Self-service password change or admin updating own password
        const res = await resetEnterpriseUserPassword(activeTarget.id, newPassword);
        const msg = res.message || 'Your password was updated successfully. Please use it for future logins.';
        setSuccessMsg(msg);
        if (onSuccess) onSuccess(msg);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update user password.');
    } finally {
      setIsLoading(false);
    }
  };

  // Password strength calculation
  const getStrengthScore = () => {
    let score = 0;
    if (newPassword.length >= 8) score++;
    if (newPassword.length >= 12) score++;
    if (/[A-Z]/.test(newPassword)) score++;
    if (/[a-z]/.test(newPassword)) score++;
    if (/[0-9]/.test(newPassword)) score++;
    if (/[^A-Za-z0-9]/.test(newPassword)) score++;
    return score;
  };

  const strength = getStrengthScore();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fade-in font-sans">
      <div 
        className="w-full max-w-lg bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-[0_24px_60px_rgba(0,0,0,0.18),0_1px_3px_rgba(0,0,0,0.06)] p-6 sm:p-8 text-[#1D1D1F] relative overflow-hidden transition-all"
        role="dialog"
        aria-modal="true"
        aria-labelledby="password-dialog-title"
      >
        {/* Subtle Ambient Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-[#0071E3]/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 text-[#0071E3] flex items-center justify-center shadow-2xs">
              <KeyRound className="w-5 h-5 stroke-[1.8]" />
            </div>
            <div>
              <h2 id="password-dialog-title" className="text-base sm:text-lg font-bold text-[#1D1D1F] tracking-tight">
                {activeTarget?.role === 'EMPLOYEE'
                  ? 'Set Employee Password (Admin Direct)'
                  : 'Set User Password (Admin Direct)'}
              </h2>
              <p className="text-xs text-slate-500">
                Directly set or reset employee credentials without requiring existing password
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success Alert */}
        {successMsg && (
          <div className="mt-4 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2.5">
            <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-emerald-900">{successMsg}</p>
              <p className="text-[11px] text-emerald-700">
                Previous tokens have been revoked. The user must authenticate with this new password.
              </p>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Target User Selector (If Admin with multiple users and no fixed target) */}
          {isAdmin && !propTargetUser && usersList.length > 0 && (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">Select User Account</label>
              <select
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-900 focus:bg-white focus:border-[#0071E3] focus:ring-2 focus:ring-[#0071E3]/20 transition-all outline-hidden cursor-pointer"
              >
                {usersList.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name} ({u.email}) · {u.role}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Target Profile Card */}
          {activeTarget && (
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-800 shadow-2xs">
                  {activeTarget.full_name?.slice(0, 2).toUpperCase() || 'US'}
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">{activeTarget.full_name}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{activeTarget.email}</p>
                </div>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                {activeTarget.role}
              </span>
            </div>
          )}

          {/* New Password Input with Generator Button */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700">New Password</label>
              <button
                type="button"
                onClick={generateStrongPassword}
                className="text-[11px] font-medium text-[#0071E3] hover:text-[#0077ED] flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Generate Strong Password</span>
              </button>
            </div>

            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new custom password..."
                className="w-full px-3.5 py-2.5 pr-20 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:border-[#0071E3] focus:ring-2 focus:ring-[#0071E3]/20 transition-all outline-hidden font-mono"
              />

              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {newPassword && (
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                    title="Copy password to clipboard"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Password Strength Meter */}
            {newPassword && (
              <div className="space-y-1 pt-1">
                <div className="flex gap-1 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full transition-all ${strength >= 1 ? 'w-1/4 bg-rose-500' : 'w-0'}`} />
                  <div className={`h-full transition-all ${strength >= 3 ? 'w-1/4 bg-amber-500' : 'w-0'}`} />
                  <div className={`h-full transition-all ${strength >= 4 ? 'w-1/4 bg-sky-500' : 'w-0'}`} />
                  <div className={`h-full transition-all ${strength >= 5 ? 'w-1/4 bg-emerald-500' : 'w-0'}`} />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Minimum 8 characters</span>
                  <span className={strength >= 4 ? 'text-emerald-600 font-semibold' : 'text-slate-400'}>
                    {strength >= 5 ? 'Very Strong' : strength >= 3 ? 'Good' : 'Weak'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700">Confirm New Password</label>
            <input
              type={showPassword ? 'text' : 'password'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Re-type new password to confirm..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:border-[#0071E3] focus:ring-2 focus:ring-[#0071E3]/20 transition-all outline-hidden font-mono"
            />
          </div>

          {/* Invalidation Security Notice */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2.5 text-[11px] text-slate-600">
            <Lock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <p>
              <span className="font-semibold text-slate-800">Session Revocation Policy:</span> Setting this password will immediately invalidate all active JWT tokens and sessions for this user on the server.
            </p>
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading || !newPassword}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#0071E3] hover:bg-[#0077ED] disabled:opacity-50 active:scale-95 shadow-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Updating Password...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Set Password</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

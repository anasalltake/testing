import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { CheckCircle2, ShieldAlert, ArrowRight, Lock, KeyRound } from 'lucide-react';

export const LogoutModal: React.FC<{ onLoginAgain?: () => void }> = ({ onLoginAgain }) => {
  const { lastLoggedOutUser, isSessionExpired, clearLogoutModal } = useAuth();

  if (!lastLoggedOutUser && !isSessionExpired) {
    return null;
  }

  const handleDismiss = () => {
    clearLogoutModal();
    if (onLoginAgain) onLoginAgain();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-[0_24px_60px_rgba(0,0,0,0.12),0_1px_3px_rgba(0,0,0,0.04)] p-7 sm:p-8 text-[#1D1D1F] relative overflow-hidden transition-all scale-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="logout-dialog-title"
      >
        {/* Subtle Ambient Apple Light Accent */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-[#0071E3]/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center text-center space-y-5">
          {/* Status Icon */}
          {isSessionExpired ? (
            <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shadow-xs">
              <ShieldAlert className="w-8 h-8 stroke-[1.75]" />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-8 h-8 stroke-[1.75]" />
            </div>
          )}

          {/* Heading */}
          <div className="space-y-1.5">
            <h3 id="logout-dialog-title" className="text-xl sm:text-2xl font-semibold tracking-tight text-[#1D1D1F]">
              {isSessionExpired ? 'Session Expired' : 'Logged Out Successfully'}
            </h3>
            <p className="text-xs uppercase tracking-wider font-semibold text-slate-400">
              ALLTAKE B2B Intelligence Core
            </p>
          </div>

          {/* Dynamic Personalized Message */}
          <div className="px-3 py-3 rounded-2xl bg-slate-50/80 border border-slate-200/80 w-full text-left">
            {lastLoggedOutUser ? (
              <p className="text-sm text-slate-700 leading-relaxed font-normal">
                Thank you, <span className="font-semibold text-[#1D1D1F]">{lastLoggedOutUser.fullName}</span>! You have been securely logged out of ALLTAKE B2B Intelligence. Your session has been closed successfully.
              </p>
            ) : (
              <p className="text-sm text-slate-700 leading-relaxed font-normal">
                For security reasons, your active 5-hour session has concluded or your security credentials have been updated. Please log in again to continue your work.
              </p>
            )}

            {lastLoggedOutUser && (
              <div className="mt-3 pt-2.5 border-t border-slate-200/70 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 font-mono">
                <span>Account: {lastLoggedOutUser.email}</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-semibold font-sans">
                  Token Revoked
                </span>
              </div>
            )}
          </div>

          {/* Security Assurance Indicator */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>Cryptographic JTI Blacklisted · Cookies Cleared</span>
          </div>

          {/* Prominent Action Button: LOGIN AGAIN */}
          <button
            type="button"
            onClick={handleDismiss}
            autoFocus
            className="w-full py-3.5 px-6 rounded-2xl bg-[#0071E3] hover:bg-[#0077ED] active:scale-[0.99] text-white font-medium text-sm sm:text-base tracking-tight shadow-[0_4px_16px_rgba(0,113,227,0.25)] hover:shadow-[0_6px_22px_rgba(0,113,227,0.35)] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <KeyRound className="w-4 h-4" />
            <span>LOGIN AGAIN</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </div>
    </div>
  );
};

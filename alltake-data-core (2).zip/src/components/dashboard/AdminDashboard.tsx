import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../contexts/AuthContext';
import { StatCard } from '../common/StatCard';
import { CardSkeleton, ChartSkeleton } from '../common/SkeletonLoader';
import { ErrorState } from '../common/FeedbackStates';
import { Badge } from '../common/Badge';
import {
  Database,
  Globe2,
  Users,
  UserCheck,
  UploadCloud,
  Download,
  ShieldCheck,
  ArrowUpRight,
  Server,
  Activity,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';

interface AdminDashboardProps {
  onNavigate: (tab: any) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [healthStatus, setHealthStatus] = useState<{ status: string; database: string } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const loadAdminData = async () => {
    setIsLoading(true);
    setHasError(false);
    try {
      const [dashRes, healthRes] = await Promise.all([
        apiRequest('/dashboard/admin'),
        apiRequest('/health').catch(() => ({ status: 'unknown', database: 'checking' })),
      ]);

      if (dashRes.success) {
        setData(dashRes);
      }
      if (healthRes) {
        setHealthStatus(healthRes);
      }
    } catch (err) {
      console.error('Failed to load admin dashboard', err);
      setHasError(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  if (hasError) {
    return <ErrorState title="Telemetry Stream Failed" onRetry={loadAdminData} />;
  }

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <CardSkeleton count={7} />
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8"><ChartSkeleton /></div>
          <div className="lg:col-span-4"><ChartSkeleton /></div>
        </div>
      </div>
    );
  }

  const { stats, countryDistribution, recentUploads, recentDownloads, recentAudits } = data;

  const chartData = (countryDistribution || []).slice(0, 8).map((c: any) => ({
    country: c.country,
    leads: c.count,
  }));

  const COLORS = ['#2563EB', '#3B82F6', '#60A5FA', '#10B981', '#059669', '#F59E0B', '#8B5CF6', '#64748B'];

  return (
    <div className="space-y-4">
      {/* Top Banner with Real Database Connection Badge */}
      <div className="bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold text-slate-900 tracking-tight">
              Welcome to Alltake Data Core Software, <span className="text-[#0071E3]">{user?.full_name || 'Administrator'}</span>!
            </h1>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              PostgreSQL {healthStatus?.database || 'Connected'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Real-time pipeline oversight, storage verification, and role-based access management
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('data-explorer')}
            className="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-2xs transition-colors flex items-center gap-1"
          >
            <span>Explore Leads</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onNavigate('uploads')}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 border border-slate-300 rounded-md shadow-2xs transition-colors flex items-center gap-1"
          >
            <UploadCloud className="w-3.5 h-3.5 text-slate-500" />
            <span>Upload CSV</span>
          </button>
        </div>
      </div>

      {/* 7 Compact Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
        <StatCard
          title="Total Records"
          value={stats.totalRecords}
          subtitle="PostgreSQL rows"
          icon={Database}
        />
        <StatCard
          title="Countries"
          value={stats.totalCountries}
          subtitle="Target markets"
          icon={Globe2}
        />
        <StatCard
          title="Employees"
          value={stats.totalEmployees}
          subtitle="Sales seats"
          icon={Users}
        />
        <StatCard
          title="Data Managers"
          value={stats.totalDataManagers}
          subtitle="Ingestion team"
          icon={UserCheck}
        />
        <StatCard
          title="Upload Jobs"
          value={stats.totalUploads}
          subtitle="Batches stored"
          icon={UploadCloud}
        />
        <StatCard
          title="Downloads"
          value={stats.totalDownloads}
          subtitle="Export requests"
          icon={Download}
        />
        <StatCard
          title="Active Users"
          value={stats.activeUsers}
          subtitle="System accounts"
          icon={ShieldCheck}
        />
      </div>

      {/* Middle Section: Chart + Audit Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Country distribution bar chart */}
        <div className="lg:col-span-8 bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider font-mono">
                Geographic Lead Volume
              </h3>
              <p className="text-[11px] text-slate-400">Top country distribution</p>
            </div>
            <button
              onClick={() => onNavigate('country-analytics')}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-0.5"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis
                  dataKey="country"
                  stroke="#94a3b8"
                  fontSize={10}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip
                  formatter={(val: any) => [`${Number(val).toLocaleString()} records`, 'Count']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '6px',
                    fontSize: '11px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="leads" radius={[3, 3, 0, 0]}>
                  {chartData.map((_: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Audit Log Snippet */}
        <div className="lg:col-span-4 bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider font-mono">
                Recent Audit Trail
              </h3>
              <button
                onClick={() => onNavigate('audit-logs')}
                className="text-xs text-blue-600 hover:text-blue-700 font-medium"
              >
                Log Explorer
              </button>
            </div>

            <div className="space-y-1.5">
              {recentAudits.slice(0, 5).map((log: any) => (
                <div
                  key={log.id}
                  className="p-2 rounded bg-slate-50 border border-slate-200/70 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 font-mono text-[11px]">
                      {log.action}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 truncate">
                    {log.user_name} ({log.user_role})
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>Audit: Active</span>
            <span>PostgreSQL: Synced</span>
          </div>
        </div>
      </div>

      {/* Tables: Recent Ingestions & Downloads */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Uploads */}
        <div className="bg-white rounded-lg border border-slate-200/90 overflow-hidden shadow-2xs">
          <div className="p-3 bg-slate-50/60 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-800 uppercase font-mono">
              Recent CSV Ingestions
            </span>
            <button
              onClick={() => onNavigate('uploads')}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              Upload Center
            </button>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {recentUploads.length === 0 ? (
              <p className="p-4 text-center text-slate-400 text-xs">No upload jobs recorded.</p>
            ) : (
              recentUploads.map((u: any) => (
                <div key={u.id} className="p-2.5 hover:bg-slate-50 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-slate-900 text-xs">{u.dataset_name}</p>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                      {u.user_name} • {u.row_count?.toLocaleString()} rows
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant={u.status === 'COMPLETED' ? 'success' : 'default'} size="sm">
                      {u.status}
                    </Badge>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {new Date(u.started_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Downloads */}
        <div className="bg-white rounded-lg border border-slate-200/90 overflow-hidden shadow-2xs">
          <div className="p-3 bg-slate-50/60 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-800 uppercase font-mono">
              Recent File Exports
            </span>
            <button
              onClick={() => onNavigate('downloads')}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              Download Logs
            </button>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {recentDownloads.length === 0 ? (
              <p className="p-4 text-center text-slate-400 text-xs">No export jobs recorded.</p>
            ) : (
              recentDownloads.map((d: any) => (
                <div key={d.id} className="p-2.5 hover:bg-slate-50 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-slate-900 text-xs">{d.dataset_name}</p>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                      {d.format} • {d.user_name} • {d.record_count?.toLocaleString()} records
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant={d.status === 'COMPLETED' ? 'success' : 'default'} size="sm">
                      {d.status}
                    </Badge>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {new Date(d.started_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

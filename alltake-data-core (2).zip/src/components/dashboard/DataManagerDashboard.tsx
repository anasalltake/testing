import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../contexts/AuthContext';
import { StatCard } from '../common/StatCard';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import {
  UploadCloud,
  Database,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  HardDrive,
} from 'lucide-react';

interface DataManagerDashboardProps {
  onNavigate: (tab: any) => void;
}

export const DataManagerDashboard: React.FC<DataManagerDashboardProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const res = await apiRequest('/dashboard/data-manager');
        if (res.success) {
          setData(res);
        }
      } catch (err) {
        console.error('Failed to load data manager dashboard', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  if (isLoading || !data) {
    return <LoadingSpinner text="Retrieving ingestion pipeline statistics..." />;
  }

  const { stats, recentUploads, datasetList } = data;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/20 text-blue-400 border border-blue-500/30">
            DATA INGESTION OPS
          </span>
          <h1 className="text-xl font-bold tracking-tight mt-1">
            Welcome to Alltake Data Core Software, <span className="text-[#38BDF8]">{user?.full_name || 'Data Architect'}</span>!
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Ingest large CSV files with dynamic column detection, deduplicate against existing leads, and monitor pipeline health.
          </p>
        </div>

        <button
          onClick={() => onNavigate('uploads')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-2 self-start md:self-auto"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Upload New CSV</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Active Datasets"
          value={stats.totalDatasets}
          icon={Database}
          subtitle="Managed in PostgreSQL"
        />
        <StatCard
          title="Total Ingested Leads"
          value={stats.totalRecords}
          icon={CheckCircle2}
          subtitle="Indexed database rows"
        />
        <StatCard
          title="My Ingestion Tasks"
          value={stats.myUploads}
          icon={UploadCloud}
          subtitle="CSV batches uploaded"
        />
        <StatCard
          title="Pipeline Engine"
          value="Chunked Bulk"
          icon={HardDrive}
          subtitle="Streaming PostgreSQL"
        />
      </div>

      {/* Recent Uploads Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
              Recent Batch Ingestions
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Breakdown of valid rows, duplicates, and new dynamic columns registered
            </p>
          </div>
          <button
            onClick={() => onNavigate('uploads')}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            Launch Ingestion Center
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Dataset Title</th>
                <th className="py-3 px-4 font-semibold">File Details</th>
                <th className="py-3 px-4 font-semibold text-right">Total Rows</th>
                <th className="py-3 px-4 font-semibold text-right">Valid Rows</th>
                <th className="py-3 px-4 font-semibold text-right">Duplicates</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Started</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 font-sans">
              {recentUploads.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400">
                    No upload batches recorded yet.
                  </td>
                </tr>
              ) : (
                recentUploads.map((u: any) => (
                  <tr key={u.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-semibold text-slate-900">{u.dataset_name}</td>
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">{u.filename}</td>
                    <td className="py-3 px-4 text-right font-mono text-slate-700">
                      {u.row_count?.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium text-emerald-700">
                      {u.valid_rows?.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-amber-700">
                      {u.duplicate_rows?.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Badge variant={u.status === 'COMPLETED' ? 'success' : 'default'} size="sm">
                        {u.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                      {new Date(u.started_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { useAuth } from '../../contexts/AuthContext';
import { StatCard } from '../common/StatCard';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import {
  Database,
  Globe2,
  Download,
  TableProperties,
  ArrowRight,
  FileSpreadsheet,
  Search,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts';

interface EmployeeDashboardProps {
  onNavigate: (tab: any) => void;
  onFilterCountry?: (country: string) => void;
}

export const EmployeeDashboard: React.FC<EmployeeDashboardProps> = ({
  onNavigate,
  onFilterCountry,
}) => {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const res = await apiRequest('/dashboard/employee');
        if (res.success) {
          setData(res);
        }
      } catch (err) {
        console.error('Failed to load employee dashboard', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  if (isLoading || !data) {
    return <LoadingSpinner text="Retrieving verified lead datasets..." />;
  }

  const { stats, countryStats, availableDatasets, myDownloads } = data;
  const topCountries = (countryStats || []).slice(0, 6);

  const COLORS = ['#2563EB', '#3B82F6', '#60A5FA', '#10B981', '#059669', '#F59E0B'];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/20 text-blue-400 border border-blue-500/30">
            EMPLOYEE WORKSPACE
          </span>
          <h1 className="text-xl font-bold tracking-tight mt-1">
            Welcome to Alltake Data Core Software, <span className="text-[#38BDF8]">{user?.full_name || 'Team Member'}</span>!
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Query pre-verified enterprise contacts, segment by geographic region or company, and export custom datasets.
          </p>
        </div>

        <button
          onClick={() => onNavigate('data-explorer')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-2 self-start md:self-auto"
        >
          <TableProperties className="w-4 h-4" />
          <span>Launch Data Explorer</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Quick KPI stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Permitted Records"
          value={stats.totalRecords}
          icon={Database}
          subtitle="Ready for queries and export"
        />
        <StatCard
          title="Global Countries"
          value={stats.totalCountries}
          icon={Globe2}
          subtitle="Active market regions"
        />
        <StatCard
          title="My Generated Exports"
          value={stats.myDownloadsCount}
          icon={Download}
          subtitle="Files downloaded this session"
        />
      </div>

      {/* Country Distribution Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
                Country Lead Volume
              </h3>
              <p className="text-[11px] text-slate-500">Verified contacts by destination country</p>
            </div>
            <button
              onClick={() => onNavigate('country-analytics')}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              Detailed Analytics
            </button>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topCountries} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis dataKey="country" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  formatter={(val: any) => [`${Number(val).toLocaleString()} leads`, 'Count']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="leads" radius={[4, 4, 0, 0]}>
                  {topCountries.map((_: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Country Breakdown Table */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-slate-200 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider mb-3">
              Top Country Directory
            </h3>

            <div className="divide-y divide-slate-100 text-xs">
              {topCountries.map((c: any) => (
                <div key={c.country} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    <span className="font-medium text-slate-900">{c.country}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-slate-900">
                      {c.leads?.toLocaleString()} leads
                    </span>
                    {onFilterCountry && (
                      <button
                        onClick={() => onFilterCountry(c.country)}
                        className="text-[11px] text-blue-600 hover:text-blue-800 font-medium"
                      >
                        Filter
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('country-analytics')}
            className="w-full mt-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-medium rounded-lg text-center transition-colors"
          >
            Explore All {stats.totalCountries} Countries
          </button>
        </div>
      </div>

      {/* Available Ingested Datasets */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
            Available Production Datasets
          </h3>
          <span className="text-[11px] text-slate-500 font-mono">
            {availableDatasets.length} Ingested Repositories
          </span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {availableDatasets.map((ds: any) => (
            <div key={ds.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
              <div>
                <p className="font-semibold text-slate-900 text-sm">{ds.name}</p>
                <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                  {ds.row_count?.toLocaleString()} rows • {ds.column_count} fields • Verified
                </p>
              </div>

              <button
                onClick={() => onNavigate('data-explorer')}
                className="px-3 py-1.5 text-xs font-medium text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-200 hover:border-blue-600 rounded-lg transition-colors"
              >
                Browse Records
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Modal } from '../common/Modal';
import { CsvPreviewSummary } from '../../types';
import { Badge } from '../common/Badge';
import { CheckCircle2, AlertTriangle, AlertCircle, FileText, ArrowRight, Loader2 } from 'lucide-react';

interface CsvPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: CsvPreviewSummary | null;
  previewData: Record<string, string>[];
  datasetName: string;
  onDatasetNameChange: (val: string) => void;
  duplicateHandling: 'SKIP' | 'IMPORT_ALL';
  onDuplicateHandlingChange: (val: 'SKIP' | 'IMPORT_ALL') => void;
  onConfirmImport: () => void;
  isImporting: boolean;
}

export const CsvPreviewModal: React.FC<CsvPreviewModalProps> = ({
  isOpen,
  onClose,
  summary,
  previewData,
  datasetName,
  onDatasetNameChange,
  duplicateHandling,
  onDuplicateHandlingChange,
  onConfirmImport,
  isImporting,
}) => {
  if (!summary) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="CSV Pre-Ingestion Analysis"
      subtitle={`Verified structure for "${summary.filename}" (${(summary.filesize / 1024).toFixed(1)} KB)`}
      maxWidth="4xl"
    >
      <div className="space-y-5">
        {/* Metric Cards Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] text-slate-500 font-medium">Total Rows</span>
            <p className="text-xl font-bold font-mono text-slate-900 mt-0.5">
              {summary.total_rows.toLocaleString()}
            </p>
          </div>

          <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200">
            <span className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Valid Rows
            </span>
            <p className="text-xl font-bold font-mono text-emerald-900 mt-0.5">
              {summary.valid_rows.toLocaleString()}
            </p>
          </div>

          <div className="bg-amber-50/60 p-3 rounded-xl border border-amber-200">
            <span className="text-[11px] text-amber-700 font-medium flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> Duplicates
            </span>
            <p className="text-xl font-bold font-mono text-amber-900 mt-0.5">
              {summary.duplicate_rows.toLocaleString()}
            </p>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="text-[11px] text-slate-500 font-medium">Columns Detected</span>
            <p className="text-xl font-bold font-mono text-slate-900 mt-0.5">
              {summary.columns_count}
            </p>
          </div>
        </div>

        {/* Dynamic Column Detection Assessment */}
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800">Dynamic Column Architecture</span>
            <span className="text-slate-500 font-mono text-[11px]">
              {summary.new_columns.length} New | {summary.existing_columns.length} Standard
            </span>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {summary.existing_columns.map((c) => (
              <span
                key={c}
                className="px-2 py-0.5 rounded text-[11px] bg-slate-200 text-slate-700 font-mono"
              >
                {c}
              </span>
            ))}
            {summary.new_columns.map((c) => (
              <span
                key={c}
                className="px-2 py-0.5 rounded text-[11px] bg-blue-100 text-blue-800 font-mono font-medium border border-blue-200"
              >
                + {c} (auto-register)
              </span>
            ))}
          </div>
        </div>

        {/* Ingestion Parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Dataset Registration Name
            </label>
            <input
              type="text"
              value={datasetName}
              onChange={(e) => onDatasetNameChange(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              placeholder="e.g. Q4 APAC Tech Directory"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Duplicate Conflict Strategy
            </label>
            <select
              value={duplicateHandling}
              onChange={(e) => onDuplicateHandlingChange(e.target.value as any)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600 bg-white"
            >
              <option value="SKIP">Skip Duplicates (Recommended for Clean Data)</option>
              <option value="IMPORT_ALL">Import All (Preserve Raw Duplicates)</option>
            </select>
          </div>
        </div>

        {/* Sample Records Table */}
        <div>
          <h4 className="text-xs font-semibold text-slate-700 mb-2">Sample Preview (First 5 Rows)</h4>
          <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-48 text-[11px]">
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-700 font-mono">
                <tr>
                  {summary.detected_headers.slice(0, 6).map((h) => (
                    <th key={h} className="py-2 px-3 border-b border-slate-200 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {previewData.slice(0, 5).map((row, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    {summary.detected_headers.slice(0, 6).map((h) => (
                      <td key={h} className="py-1.5 px-3 whitespace-nowrap text-slate-600 max-w-xs truncate">
                        {row[h] || '—'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Controls */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Ingestion uses chunked PostgreSQL transactions
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isImporting}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-lg"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={onConfirmImport}
              disabled={isImporting}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-lg shadow-xs flex items-center gap-1.5"
            >
              {isImporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Chunk Ingesting...
                </>
              ) : (
                <>
                  <span>Commit Import to PostgreSQL</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

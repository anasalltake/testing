import React, { useState, useEffect, useRef } from 'react';
import { apiRequest } from '../../api/client';
import { UploadJob, CsvPreviewSummary } from '../../types';
import { CsvPreviewModal } from './CsvPreviewModal';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  FileDown,
  RefreshCw,
  Layers,
  Sparkles,
} from 'lucide-react';

interface UploadCenterProps {
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const UploadCenter: React.FC<UploadCenterProps> = ({ onNotify }) => {
  const [jobs, setJobs] = useState<UploadJob[]>([]);
  const [isLoadingJobs, setIsLoadingJobs] = useState(true);

  // File upload state
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [duplicateStrategy, setDuplicateStrategy] = useState<'email' | 'phone'>('email');
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);
  const [previewSummary, setPreviewSummary] = useState<CsvPreviewSummary | null>(null);
  const [previewData, setPreviewData] = useState<Record<string, string>[]>([]);
  const [datasetName, setDatasetName] = useState('');
  const [duplicateHandling, setDuplicateHandling] = useState<'SKIP' | 'IMPORT_ALL'>('SKIP');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load upload history
  const loadJobs = async () => {
    setIsJobsLoading(true);
    try {
      const res = await apiRequest<{ success: boolean; jobs: UploadJob[] }>('/uploads/jobs');
      if (res.success && res.jobs) {
        setJobs(res.jobs);
      }
    } catch (err) {
      console.error('Failed to load upload history', err);
    } finally {
      setIsJobsLoading(false);
    }
  };

  const setIsJobsLoading = (val: boolean) => setIsLoadingJobs(val);

  useEffect(() => {
    loadJobs();
  }, []);

  // Handle file drop / select
  const handleFileChange = (file: File) => {
    const validExts = ['.csv', '.xlsx', '.xls', '.tsv', '.txt', '.json'];
    const isSupported = validExts.some((ext) => file.name.toLowerCase().endsWith(ext));
    if (!isSupported) {
      onNotify('error', 'Permitted file formats: CSV, Excel (XLSX, XLS), TSV, TXT, and JSON.');
      return;
    }
    setSelectedFile(file);
    setDatasetName(file.name.replace(/\.[^/.]+$/i, '').replace(/[-_]/g, ' '));
    triggerPreviewAnalysis(file);
  };

  const triggerPreviewAnalysis = async (file: File) => {
    setIsPreviewLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('duplicate_strategy', duplicateStrategy);

    try {
      const res = await apiRequest<{
        success: boolean;
        summary: CsvPreviewSummary;
        preview_data: Record<string, string>[];
      }>('/uploads/preview', {
        method: 'POST',
        body: formData,
      });

      if (res.success) {
        setPreviewSummary(res.summary);
        setPreviewData(res.preview_data || []);
        setIsModalOpen(true);
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to inspect CSV file');
    } finally {
      setIsPreviewLoading(false);
    }
  };

  const handleConfirmImport = async () => {
    if (!selectedFile) return;
    setIsImporting(true);

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('dataset_name', datasetName);
    formData.append('import_mode', 'APPEND');
    formData.append('duplicate_strategy', duplicateStrategy);
    formData.append('handle_duplicates', duplicateHandling);

    try {
      const res = await apiRequest<{
        success: boolean;
        message: string;
        stats: any;
      }>('/uploads/confirm', {
        method: 'POST',
        body: formData,
      });

      if (res.success) {
        onNotify(
          'success',
          `Successfully ingested ${res.stats?.valid_rows?.toLocaleString() || 'all'} records into PostgreSQL!`
        );
        setIsModalOpen(false);
        setSelectedFile(null);
        loadJobs();
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Database ingestion failed');
    } finally {
      setIsImporting(false);
    }
  };

  const handleDownloadSampleCsv = () => {
    window.location.href = '/api/uploads/sample-csv';
  };

  const getStatusBadge = (status: UploadJob['status']) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge variant="success">COMPLETED</Badge>;
      case 'IMPORTING':
      case 'VALIDATING':
        return <Badge variant="primary">PROCESSING</Badge>;
      case 'FAILED':
        return <Badge variant="danger">FAILED</Badge>;
      default:
        return <Badge variant="warning">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Description */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-blue-600" />
            CSV Ingestion Center
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Ingest large datasets with dynamic schema adaptation and duplicate resolution
          </p>
        </div>

        <button
          onClick={handleDownloadSampleCsv}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs"
          title="Download a verified 250-lead CSV with mixed columns to test immediate ingestion"
        >
          <FileDown className="w-3.5 h-3.5 text-blue-600" />
          <span>Get Sample Test CSV (250 Leads)</span>
        </button>
      </div>

      {/* Upload Drag & Drop Area */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
            Ingest New File
          </span>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Duplicate Check Key:</span>
            <select
              value={duplicateStrategy}
              onChange={(e) => setDuplicateStrategy(e.target.value as any)}
              className="px-2 py-1 text-xs border border-slate-300 rounded-md bg-white text-slate-700"
            >
              <option value="email">Business Email (Recommended)</option>
              <option value="phone">Direct Phone</option>
            </select>
          </div>
        </div>

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragActive(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleFileChange(e.dataTransfer.files[0]);
            }
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            dragActive
              ? 'border-blue-500 bg-blue-50/50'
              : 'border-slate-300 hover:border-slate-400 bg-slate-50/50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileChange(e.target.files[0]);
              }
            }}
          />

          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
            <FileSpreadsheet className="w-6 h-6" />
          </div>

          <h3 className="text-sm font-semibold text-slate-800">
            {isPreviewLoading ? 'Analyzing CSV Structure...' : 'Drop CSV file here or browse'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Supports multi-thousand row files. Automatically registers dynamic columns and checks for duplicates.
          </p>

          <div className="mt-4 flex items-center justify-center gap-4 text-[11px] text-slate-400 font-mono">
            <span>• Streamed Ingestion</span>
            <span>• Chunked PostgreSQL Bulk Inserts</span>
            <span>• 100MB Max</span>
          </div>
        </div>
      </div>

      {/* Ingestion History Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
              Upload History & Ingestion Log
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Detailed tracking of valid records, duplicates, and new dynamic columns registered
            </p>
          </div>

          <button
            onClick={loadJobs}
            className="p-1.5 text-slate-500 hover:text-slate-800 border border-slate-200 rounded-lg hover:bg-slate-50"
            title="Refresh history"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Dataset / File</th>
                <th className="py-3 px-4 font-semibold">Uploaded By</th>
                <th className="py-3 px-4 font-semibold text-right">Rows</th>
                <th className="py-3 px-4 font-semibold text-right">Valid</th>
                <th className="py-3 px-4 font-semibold text-right">Duplicates</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Timestamp</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 font-sans">
              {isLoadingJobs ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center">
                    <LoadingSpinner text="Loading upload jobs..." />
                  </td>
                </tr>
              ) : jobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    No upload jobs recorded yet. Ingest your first CSV above.
                  </td>
                </tr>
              ) : (
                jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">{job.dataset_name}</span>
                        <span className="text-[11px] text-slate-400 font-mono truncate max-w-xs">
                          {job.filename} ({(job.file_size / 1024).toFixed(1)} KB)
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{job.user_name}</td>
                    <td className="py-3 px-4 text-right font-mono text-slate-700">
                      {job.row_count.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium text-emerald-700">
                      {job.valid_rows.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-amber-700">
                      {job.duplicate_rows.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">{getStatusBadge(job.status)}</td>
                    <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                      {new Date(job.started_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Analysis Preview Modal */}
      <CsvPreviewModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        summary={previewSummary}
        previewData={previewData}
        datasetName={datasetName}
        onDatasetNameChange={setDatasetName}
        duplicateHandling={duplicateHandling}
        onDuplicateHandlingChange={setDuplicateHandling}
        onConfirmImport={handleConfirmImport}
        isImporting={isImporting}
      />
    </div>
  );
};

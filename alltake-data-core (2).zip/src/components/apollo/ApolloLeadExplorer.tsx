import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { TopNav } from './TopNav';
import { FilterSidebar } from './FilterSidebar';
import { LeadsTable } from './LeadsTable';
import { UploadFileModal } from './UploadFileModal';
import { ExecutiveDashboard } from '../dashboard/ExecutiveDashboard';
import { AdminSettingsModal, AdminSettingsTab } from '../admin/AdminSettingsModal';
import { FullSettingsPage } from '../../pages/FullSettingsPage';
import { EmployeeApprovedExports } from '../exports/EmployeeApprovedExports';
import {
  initializeEnterpriseDatabase,
  evaluateSerialFilterMatches,
  hasAnyActiveSerialFilter,
  DEFAULT_SERIAL_FILTERS,
  getAllLeads,
  getAllColumns,
  getAllUsers,
  getAllDownloadLogs,
  getFieldVisibilityRules,
} from '../../services/enterpriseDb';
import {
  EnterpriseLeadRecord,
  EnterpriseColumnDef,
  SerialFiltersState,
  FieldVisibilityRule,
  EnterpriseUser,
  DownloadAuditLog,
  FilterRuleConfig,
} from '../../types/enterprise';
import { useAuth } from '../../contexts/AuthContext';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { DmsLogo } from '../common/DmsLogo';

export const ApolloLeadExplorer: React.FC = () => {
  const { user, logout } = useAuth();

  // Data states from IndexedDB
  const [allLeads, setAllLeads] = useState<EnterpriseLeadRecord[]>([]);
  const [columns, setColumns] = useState<EnterpriseColumnDef[]>([]);
  const [users, setUsers] = useState<EnterpriseUser[]>([]);
  const [downloadLogs, setDownloadLogs] = useState<DownloadAuditLog[]>([]);
  const [visibilityRules, setVisibilityRules] = useState<FieldVisibilityRule[]>([]);
  const [filterRules, setFilterRules] = useState<FilterRuleConfig[]>([]);
  const [isInitializing, setIsInitializing] = useState(true);

  // View state: 'dashboard' is the initial landing view, 'explorer' for leads, 'settings' for full admin governance, 'approved' for employee approved downloads
  const [currentView, setCurrentView] = useState<'explorer' | 'dashboard' | 'settings' | 'approved'>('dashboard');
  const [readyApprovalsCount, setReadyApprovalsCount] = useState<number>(0);

  // Sidebar visibility
  const [isFiltersVisible, setIsFiltersVisible] = useState(true);

  // Search input state
  const [searchPeopleQuery, setSearchPeopleQuery] = useState('');
  const [globalQuery, setGlobalQuery] = useState('');

  // Modals
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isAdminSettingsOpen, setIsAdminSettingsOpen] = useState(false);
  const [adminSettingsTab, setAdminSettingsTab] = useState<AdminSettingsTab>('users');

  const handleOpenAdminSettings = (tab: AdminSettingsTab = 'users') => {
    setAdminSettingsTab(tab);
    setCurrentView('settings');
  };

  // 16 Serial-wise Filters state (Initially blank / inactive)
  const [appliedFilters, setAppliedFilters] = useState<SerialFiltersState>(DEFAULT_SERIAL_FILTERS);
  const [hasActiveFilter, setHasActiveFilter] = useState<boolean>(false);

  // Search progress percentage state
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchProgress, setSearchProgress] = useState<number>(0);
  const [searchStatusMsg, setSearchStatusMsg] = useState<string>('');

  // Toast notifications
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4500);
  };

  // Initialize Enterprise Database from IndexedDB
  const reloadDatabaseData = async () => {
    try {
      const { leads, columns: cols, visibilityRules: rules, users: usrList, filterRules: fltRules } =
        await initializeEnterpriseDatabase();
      setAllLeads(leads);
      setColumns(cols);
      setVisibilityRules(rules);
      setUsers(usrList);
      if (fltRules) setFilterRules(fltRules);

      const logs = await getAllDownloadLogs();
      setDownloadLogs(logs);

      // Fetch active export approval requests count
      try {
        const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
        const res = await fetch('/api/exports/requests', {
          headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        });
        const data = await res.json();
        if (data.success && Array.isArray(data.requests)) {
          const ready = data.requests.filter((r: any) => r.status === 'APPROVED').length;
          setReadyApprovalsCount(ready);
        }
      } catch {
        // ignore network error
      }
    } catch (err) {
      console.error('Failed to load enterprise database', err);
    } finally {
      setIsInitializing(false);
    }
  };

  const handleApplyQuickFilter = (type: 'location' | 'managementLevel' | 'jobTitle' | 'industry', value: string) => {
    const draft: SerialFiltersState = { ...DEFAULT_SERIAL_FILTERS };
    if (type === 'location') {
      draft.selectedLocations = [value];
    } else if (type === 'managementLevel') {
      draft.managementLevels = [value];
    } else if (type === 'jobTitle') {
      draft.jobTitlePaste = value;
      draft.jobTitleMode = 'include';
    } else if (type === 'industry') {
      draft.industries = [value];
    }
    handleApplyFilters(draft);
  };

  const handleSearchPeople = (term: string) => {
    setSearchPeopleQuery(term);
    if (!term.trim()) {
      handleClearAllFilters();
      return;
    }
    const draft: SerialFiltersState = { ...DEFAULT_SERIAL_FILTERS };
    draft.jobTitlePaste = term.trim();
    draft.jobTitleMode = 'include';
    setGlobalQuery(term.trim());
    handleApplyFilters(draft);
  };

  const handleBrowseAllLeads = () => {
    setAppliedFilters(DEFAULT_SERIAL_FILTERS);
    setGlobalQuery('');
    setHasActiveFilter(true);
    showNotification(`Displaying all ${allLeads.length.toLocaleString()} verified database records.`);
  };

  useEffect(() => {
    reloadDatabaseData();
  }, []);

  // Summary of active applied filters for audit logging & table header
  const activeFilterSummary = useMemo(() => {
    if (!hasActiveFilter) return '';
    const parts: string[] = [];

    if (appliedFilters.firstName || appliedFilters.lastName) {
      parts.push(`Name: ${[appliedFilters.firstName, appliedFilters.lastName].filter(Boolean).join(' ')}`);
    }
    if (appliedFilters.emailSearch.trim()) {
      parts.push(`Email: "${appliedFilters.emailSearch.trim()}"`);
    }
    if (appliedFilters.selectedLocations.length > 0) {
      parts.push(`Location: [${appliedFilters.selectedLocations.join(', ')}]`);
    }
    if (appliedFilters.addressSearch.trim()) {
      parts.push(`Address: "${appliedFilters.addressSearch.trim()}"`);
    }
    if (appliedFilters.city || appliedFilters.state || appliedFilters.country) {
      parts.push(`Region: ${[appliedFilters.city, appliedFilters.state, appliedFilters.country].filter(Boolean).join(', ')}`);
    }
    if (appliedFilters.addressLinkSearch.trim()) {
      parts.push(`Address Link: "${appliedFilters.addressLinkSearch.trim()}"`);
    }
    if (appliedFilters.phoneSearch.trim()) {
      parts.push(`Phone: "${appliedFilters.phoneSearch.trim()}"`);
    }
    if (appliedFilters.phoneTypes.corporate) parts.push('Phone: Corporate');
    if (appliedFilters.phoneTypes.mobile) parts.push('Phone: Mobile');
    if (appliedFilters.phoneTypes.other) parts.push('Phone: Other');

    if (appliedFilters.jobTitlePaste.trim()) {
      parts.push(`Job Title ${appliedFilters.jobTitleMode.toUpperCase()}: "${appliedFilters.jobTitlePaste.trim().slice(0, 30)}"`);
    }
    if (appliedFilters.managementLevels && appliedFilters.managementLevels.length > 0) {
      parts.push(`Management Level: [${appliedFilters.managementLevels.join(', ')}]`);
    }
    if (appliedFilters.companyNamePaste.trim()) {
      parts.push(`Company ${appliedFilters.companyNameMode.toUpperCase()}: "${appliedFilters.companyNamePaste.trim().slice(0, 30)}"`);
    }
    if (appliedFilters.companyDomainPaste.trim()) {
      parts.push(`Domain ${appliedFilters.companyDomainMode.toUpperCase()}: "${appliedFilters.companyDomainPaste.trim().slice(0, 30)}"`);
    }
    if (appliedFilters.employeeSizes.length > 0) {
      parts.push(`Size: [${appliedFilters.employeeSizes.join(', ')}]`);
    }
    if (appliedFilters.industries.length > 0) {
      parts.push(`Industries: [${appliedFilters.industries.slice(0, 3).join(', ')}${appliedFilters.industries.length > 3 ? '...' : ''}]`);
    }
    if (appliedFilters.revenueRanges.length > 0) {
      parts.push(`Revenue: [${appliedFilters.revenueRanges.join(', ')}]`);
    }
    if (appliedFilters.sicNaicsSearch.trim()) {
      parts.push(`SIC/NAICS: "${appliedFilters.sicNaicsSearch.trim()}"`);
    }

    if (globalQuery.trim()) {
      parts.push(`Keyword: "${globalQuery.trim()}"`);
    }

    return parts.join(' | ');
  }, [appliedFilters, hasActiveFilter, globalQuery]);

  // Strict Query Shield: Data is protected and NEVER shown until filter is applied!
  const filteredLeads = useMemo(() => {
    if (!hasActiveFilter) {
      return []; // PROTECTED: Zero data is leaked until an active filter is applied!
    }

    return allLeads.filter((lead) => {
      // 1. Evaluate serial filters
      const matchesSerial = evaluateSerialFilterMatches(lead, appliedFilters);
      if (!matchesSerial) return false;

      // 2. Global keyword query match if user typed in top bar
      if (globalQuery.trim()) {
        const q = globalQuery.trim().toLowerCase();
        const jsonStr = JSON.stringify(lead).toLowerCase();
        if (!jsonStr.includes(q)) return false;
      }

      return true;
    });
  }, [allLeads, appliedFilters, hasActiveFilter, globalQuery]);

  // Filter Actions
  const handleApplyFilters = (draftFilters: SerialFiltersState) => {
    const isActive = hasAnyActiveSerialFilter(draftFilters) || Boolean(globalQuery.trim());
    if (!isActive) {
      showNotification('Protected: Please select at least one filter criterion before applying');
      return;
    }

    setIsSearching(true);
    setSearchProgress(20);
    setSearchStatusMsg('Scanning database index...');

    setTimeout(() => {
      setSearchProgress(60);
      setSearchStatusMsg('Evaluating filter dimensions across database...');
    }, 120);

    setTimeout(() => {
      setSearchProgress(88);
      setSearchStatusMsg('Verifying PII access policies...');
    }, 240);

    setTimeout(() => {
      setSearchProgress(100);
      setSearchStatusMsg('Query complete!');
      setAppliedFilters(draftFilters);
      setHasActiveFilter(true);
      setIsSearching(false);

      const matches = allLeads.filter((l) => evaluateSerialFilterMatches(l, draftFilters));
      showNotification(`Query executed: Found ${matches.length.toLocaleString()} matching records.`);
    }, 380);
  };

  const handleClearAllFilters = () => {
    setAppliedFilters(DEFAULT_SERIAL_FILTERS);
    setHasActiveFilter(false);
    setSearchPeopleQuery('');
    setGlobalQuery('');
    showNotification('All filters reset. Database vault protected (0 records displayed).');
  };

  const handleDownloadCompleted = async () => {
    try {
      const logs = await getAllDownloadLogs();
      setDownloadLogs(logs);
    } catch {
      // ignore
    }
  };

  // Upload callback
  const handleUploadSuccess = (res: {
    addedCount: number;
    leads: EnterpriseLeadRecord[];
    columns: EnterpriseColumnDef[];
  }) => {
    setAllLeads(res.leads);
    setColumns(res.columns);
    showNotification(
      `Dataset Ingestion Complete: Stored ${res.addedCount.toLocaleString()} records across ${res.columns.length} columns in database!`
    );
  };

  if (isInitializing) {
    return (
      <div className="h-screen w-screen bg-slate-50 flex flex-col items-center justify-center select-none">
        <div className="mb-4">
          <DmsLogo size="lg" />
        </div>
        <div className="flex items-center gap-2 text-slate-600 font-medium text-xs">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          <span>Connecting to Enterprise Database...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 text-slate-800 flex-col">
      {/* 1. Top Navigation Bar */}
      <TopNav
        currentView={currentView}
        onViewChange={setCurrentView}
        isFiltersVisible={isFiltersVisible}
        onToggleFilters={() => setIsFiltersVisible(!isFiltersVisible)}
        onOpenUpload={() => setIsUploadModalOpen(true)}
        onOpenAdminSettings={handleOpenAdminSettings}
        onLogout={logout}
        userName={user?.full_name || 'Team Member'}
        userRole={user?.role || 'EMPLOYEE'}
        approvedCount={readyApprovalsCount}
      />

      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-16 right-4 z-50 flex items-center gap-2 px-3.5 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg shadow-lg border border-slate-700 animate-in fade-in slide-in-from-top-2 duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* 2. Main Workspace: View Toggle (Dashboard vs Explorer vs Full Settings Page vs Approved Downloads) */}
      {currentView === 'settings' ? (
        <div className="flex-1 overflow-y-auto">
          <FullSettingsPage
            onBackToExplorer={() => setCurrentView('explorer')}
            onBackToDashboard={() => setCurrentView('dashboard')}
            onNotify={showNotification}
            initialTab={
              adminSettingsTab === 'exports'
                ? 'exports'
                : adminSettingsTab === 'database'
                ? 'database'
                : adminSettingsTab === 'logs'
                ? 'logs'
                : adminSettingsTab === 'users'
                ? 'users'
                : 'notifications'
            }
          />
        </div>
      ) : currentView === 'approved' ? (
        <EmployeeApprovedExports
          onNavigateToExplorer={() => setCurrentView('explorer')}
          onNotify={showNotification}
          userRole={user?.role}
          userEmail={user?.email}
        />
      ) : currentView === 'dashboard' ? (
        <ExecutiveDashboard
          leads={allLeads}
          users={users}
          downloadLogs={downloadLogs}
          onNavigateToExplorer={() => setCurrentView('explorer')}
          onOpenUpload={() => setIsUploadModalOpen(true)}
          onOpenAdminSettings={handleOpenAdminSettings}
          isAdmin={user?.role === 'ADMIN'}
          userName={user?.full_name || 'Team Member'}
          userRole={user?.role || 'EMPLOYEE'}
        />
      ) : (
        <div className="flex-1 flex min-h-0 overflow-hidden">
          {/* Left Side: Apollo B2B Lead Filters */}
          {isFiltersVisible && (
            <FilterSidebar
              allLeads={allLeads}
              columns={columns}
              appliedFilters={appliedFilters}
              filterRules={filterRules}
              userRole={user?.role}
              hasActiveFilter={hasActiveFilter}
              filteredCount={filteredLeads.length}
              onApplyFilters={handleApplyFilters}
              onClearAll={handleClearAllFilters}
              onToggleFilters={() => setIsFiltersVisible(false)}
            />
          )}

          {/* Right Side: Leads Table & Prospecting Engine */}
          <LeadsTable
            leads={filteredLeads}
            allLeadsCount={allLeads.length}
            columns={columns}
            visibilityRules={visibilityRules}
            currentUser={user}
            hasActiveFilter={hasActiveFilter}
            activeFilterSummary={activeFilterSummary}
            activeFiltersJson={appliedFilters as any}
            onNotify={showNotification}
            isSearching={isSearching}
            searchProgress={searchProgress}
            searchStatusMsg={searchStatusMsg}
            searchPeopleQuery={searchPeopleQuery}
            onSearchPeople={handleSearchPeople}
            onApplyQuickFilter={handleApplyQuickFilter}
            onBrowseAllLeads={handleBrowseAllLeads}
            isFiltersVisible={isFiltersVisible}
            onToggleFilters={() => setIsFiltersVisible(!isFiltersVisible)}
            onOpenUpload={() => setIsUploadModalOpen(true)}
            onOpenDatabaseConfig={() => handleOpenAdminSettings('database')}
            onColumnsChanged={(updated) => setColumns(updated)}
            onDownloadComplete={handleDownloadCompleted}
          />
        </div>
      )}

      {/* Universal 31-Column Daily Upload Modal */}
      <UploadFileModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />

      {/* Unified Admin Settings Center (Apple-grade) */}
      {user?.role === 'ADMIN' && (
        <AdminSettingsModal
          isOpen={isAdminSettingsOpen}
          initialTab={adminSettingsTab}
          onClose={() => setIsAdminSettingsOpen(false)}
          onNotify={showNotification}
          onDataChanged={reloadDatabaseData}
        />
      )}
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import {
  Download,
  ExternalLink,
  Mail,
  Phone,
  Building,
  Users,
  ChevronLeft,
  ChevronRight,
  Filter,
  CheckSquare,
  Square,
  Lock,
  Eye,
  EyeOff,
  DollarSign,
  Loader2,
  ShieldCheck,
  Search,
  SlidersHorizontal,
  ArrowUpDown,
  MapPin,
  Briefcase,
  Upload,
  X,
  Database,
  Clock,
  FileSpreadsheet
} from 'lucide-react';
import {
  EnterpriseLeadRecord,
  EnterpriseColumnDef,
  FieldVisibilityRule,
  EnterpriseUser
} from '../../types/enterprise';
import {
  downloadEnterpriseCsv,
  recordDownloadAuditLog,
  reorderColumn,
  validateExportLimit,
  getExportGovernanceSettings,
  notifyExportEvent,
} from '../../services/enterpriseDb';
import { ColumnLayoutManagerModal } from '../admin/ColumnLayoutManagerModal';
import { ExportApprovalModal } from './ExportApprovalModal';
import { ExportRequestsModal } from './ExportRequestsModal';
import { CampaignExportModal } from './CampaignExportModal';

interface LeadsTableProps {
  leads: EnterpriseLeadRecord[];
  allLeadsCount: number;
  columns: EnterpriseColumnDef[];
  visibilityRules: FieldVisibilityRule[];
  currentUser: EnterpriseUser | null;
  hasActiveFilter: boolean;
  activeFilterSummary: string;
  activeFiltersJson: Record<string, any>;
  onNotify: (msg: string) => void;
  isSearching?: boolean;
  searchProgress?: number;
  searchStatusMsg?: string;
  searchPeopleQuery?: string;
  onSearchPeople?: (query: string) => void;
  onApplyQuickFilter?: (type: 'location' | 'managementLevel' | 'jobTitle' | 'industry', value: string) => void;
  isFiltersVisible?: boolean;
  onToggleFilters?: () => void;
  onOpenUpload?: () => void;
  onOpenDatabaseConfig?: () => void;
  onOpenFilterConfig?: () => void;
  onColumnsChanged?: (updated: EnterpriseColumnDef[]) => void;
  onDownloadComplete?: () => void;
  onBrowseAllLeads?: () => void;
}

export const LeadsTable: React.FC<LeadsTableProps> = ({
  leads,
  allLeadsCount,
  columns,
  visibilityRules,
  currentUser,
  hasActiveFilter,
  activeFilterSummary,
  activeFiltersJson,
  onNotify,
  isSearching = false,
  searchProgress = 100,
  searchStatusMsg = '',
  searchPeopleQuery = '',
  onSearchPeople,
  onApplyQuickFilter,
  onBrowseAllLeads,
  isFiltersVisible = true,
  onToggleFilters,
  onOpenUpload,
  onOpenFilterConfig,
  onColumnsChanged,
  onDownloadComplete,
}) => {
  // Selected lead IDs for bulk export
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [leadSearchInput, setLeadSearchInput] = useState('');

  // Export loading state to prevent duplicate submissions
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Export Campaign Modal state
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);

  // Export Governance Modals state
  const [isExportApprovalModalOpen, setIsExportApprovalModalOpen] = useState(false);
  const [isExportRequestsModalOpen, setIsExportRequestsModalOpen] = useState(false);
  const [exportQuotaLimit, setExportQuotaLimit] = useState(10000);

  // Column Layout Manager Modal state for Admin
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const isAdmin = currentUser?.role === 'ADMIN';
  const isDataManager = currentUser?.role === 'DATA_MANAGER';
  const isEmployee = !isAdmin && !isDataManager;

  // Determine which columns are displayed in the table based on Admin ordering and employee visibility
  const visibleColumns = useMemo(() => {
    // Strictly sort by configured order (aage/peeche position)
    const sorted = [...columns].sort((a, b) => (a.order ?? 999) - (b.order ?? 999));

    return sorted.filter((col) => {
      // Admins and managers see all columns in configured sequence
      if (isAdmin || isDataManager) return col.visible !== false;

      // For employees:
      // 1. Column must be permitted by Admin's employeeVisible flag
      if (col.employeeVisible === false) return false;

      // 2. Column must not be HIDDEN in enterprise visibility rules
      const rule = visibilityRules.find((r) => r.columnKey === col.key);
      if (rule) {
        if (rule.enabledInTable === false) return false;
        if (rule.employeeVisibility === 'HIDDEN') return false;
      }
      return true;
    });
  }, [columns, visibilityRules, isAdmin, isDataManager]);

  // Quick move column left (UP) or right (DOWN) directly on live header (Admin only)
  const handleMoveColumnQuick = async (colKey: string, direction: 'UP' | 'DOWN') => {
    try {
      const updated = await reorderColumn(colKey, direction);
      if (onColumnsChanged) {
        onColumnsChanged(updated);
      }
      onNotify(`Column position moved ${direction === 'UP' ? 'left' : 'right'}.`);
    } catch {
      onNotify('Failed to reorder column.');
    }
  };

  // Check visibility mode for a specific field
  const getFieldVisibility = (colKey: string): 'VISIBLE' | 'MASKED' | 'HIDDEN' => {
    if (isAdmin || isDataManager) {
      return 'VISIBLE';
    }
    const rule = visibilityRules.find((r) => r.columnKey === colKey);
    if (!rule) return 'VISIBLE';
    return rule.employeeVisibility;
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedLeads.length && paginatedLeads.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginatedLeads.map((l) => l.id)));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Pagination calculation
  const totalPages = Math.ceil(leads.length / pageSize) || 1;
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedLeads = leads.slice(startIndex, startIndex + pageSize);

  // Handle Download CSV Click: Opens Campaign Export Verification Modal
  const handleInitiateExport = async () => {
    if (leads.length === 0) {
      onNotify('No leads available to download');
      return;
    }

    if (isExporting) return;

    const recordsToDownload =
      selectedIds.size > 0 ? leads.filter((l) => selectedIds.has(l.id)) : leads;

    // Check Export Limits & Policy Gatekeeper for all non-admin personnel
    if (!isAdmin) {
      try {
        const validation = await validateExportLimit(recordsToDownload.length);
        if (validation.requiresApproval || !validation.allowed) {
          setExportQuotaLimit(validation.limit || 10000);
          setIsExportApprovalModalOpen(true);
          onNotify(
            validation.message ||
              `Export limit reached (Max ${(validation.limit || 10000).toLocaleString()} rows). Administrator approval required.`
          );
          return;
        }
      } catch {
        // Fallback to live server settings
        try {
          const liveSettings = await getExportGovernanceSettings();
          const limit = liveSettings?.employeeMaxDownloadLimit || 10000;
          if (recordsToDownload.length > limit) {
            setExportQuotaLimit(limit);
            setIsExportApprovalModalOpen(true);
            onNotify(
              `Export limit reached (Max ${limit.toLocaleString()} rows set by Administrator). Approval required.`
            );
            return;
          }
        } catch {
          // default limit guard
          if (recordsToDownload.length > 10000) {
            setExportQuotaLimit(10000);
            setIsExportApprovalModalOpen(true);
            onNotify(`Export limit reached (Max 10,000 leads). Administrator approval required.`);
            return;
          }
        }
      }
    }

    // Open Campaign Configuration Modal so user must specify campaign name before export
    setIsCampaignModalOpen(true);
  };

  // Execute export with verified Campaign Name and trigger email alert to admin
  const handleConfirmCampaignExport = async (params: {
    campaignName: string;
    notes?: string;
    format: 'CSV' | 'EXCEL';
  }) => {
    const { campaignName, notes, format } = params;
    const recordsToDownload =
      selectedIds.size > 0 ? leads.filter((l) => selectedIds.has(l.id)) : leads;

    setIsExporting(true);

    try {
      const sanitizedFileCampaign = campaignName.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
      const fileName = `${sanitizedFileCampaign}_Leads_${new Date().toISOString().split('T')[0]}.csv`;

      // 1. Download file with all active dynamic columns (Admin gets all columns, Employee gets permitted columns)
      downloadEnterpriseCsv(
        recordsToDownload,
        fileName,
        isAdmin ? columns : visibleColumns,
        {
          isEmployee,
          visibilityRules,
        }
      );

      // 2. Record Download in Audit Logs with Campaign Name for Admin review
      await recordDownloadAuditLog({
        userId: currentUser?.id || 'anonymous',
        userName: currentUser?.full_name || 'Anonymous User',
        userEmail: currentUser?.email || 'user@alltake.com',
        userRole: currentUser?.role || 'EMPLOYEE',
        campaignName: campaignName.trim(),
        campaignNotes: notes,
        recordCount: recordsToDownload.length,
        format: format === 'EXCEL' ? 'EXCEL' : 'CSV',
        filtersApplied: activeFiltersJson,
        filtersSummary: activeFilterSummary || 'All Filtered Records',
        ipAddress: '127.0.0.1 (Client Secure Session)',
      });

      // 3. Dispatch real-time email notification to Admin via Resend API with Campaign Name prominently
      notifyExportEvent({
        recordCount: recordsToDownload.length,
        format: format === 'EXCEL' ? 'EXCEL' : 'CSV',
        campaignName: campaignName.trim(),
        notes,
        filtersSummary: activeFilterSummary || 'All Filtered Records',
        datasetName: 'Alltake Leads Vault',
      }).catch((e) => console.warn('Email alert dispatch:', e));

      onNotify(
        `Successfully exported ${recordsToDownload.length.toLocaleString()} leads for campaign "${campaignName}". Administrator notification dispatched via email.`
      );
      setIsCampaignModalOpen(false);
      onDownloadComplete?.();
    } catch (err: any) {
      onNotify('Export failed: ' + (err?.message || 'Unable to generate CSV'));
    } finally {
      setIsExporting(false);
    }
  };

  // Render cell with masking and clean styling
  const renderCellContent = (lead: EnterpriseLeadRecord, colKey: string) => {
    const rawVal = lead[colKey];
    const visibility = getFieldVisibility(colKey);

    if (visibility === 'MASKED') {
      const displayVal = rawVal !== undefined && rawVal !== null && String(rawVal).trim() !== ''
        ? String(rawVal)
        : (colKey === 'emailAddress' ? 'confidential@company.com' : '+1 (555) 019-2834');

      return (
        <span
          className="relative inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-100/90 text-slate-800 text-[11px] select-none overflow-hidden border border-slate-200/70 max-w-[200px] cursor-not-allowed group"
          title="Field Protected: Blurred under Employee Privacy Policy. Unmasked in Admin & Manager views."
        >
          {/* Authentic Gaussian blur over real value */}
          <span className="blur-[4px] select-none pointer-events-none opacity-60 font-mono tracking-tight truncate max-w-[130px] inline-block">
            {displayVal}
          </span>
          <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-slate-500 bg-white/95 px-1 py-0.2 rounded border border-slate-200/90 shrink-0 ml-auto shadow-2xs">
            <Lock className="w-2.5 h-2.5 text-slate-400 shrink-0" />
            <span className="text-[8px] uppercase tracking-wider font-semibold">Blur</span>
          </span>
        </span>
      );
    }

    if (!rawVal && rawVal !== 0) {
      return <span className="text-slate-300 font-mono text-[11px]">—</span>;
    }

    const strVal = String(rawVal);

    if (colKey === 'employeeSize') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-slate-700 font-mono">
          <Users className="w-3 h-3 text-slate-400 shrink-0" />
          <span>{strVal}</span>
        </span>
      );
    }

    if (colKey === 'revenueSize') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-slate-800 font-mono">
          <DollarSign className="w-3 h-3 text-slate-400 shrink-0" />
          <span>{strVal}</span>
        </span>
      );
    }

    if (colKey === 'industryType') {
      return (
        <span className="truncate block text-slate-800 max-w-[200px]" title={strVal}>
          {strVal}
        </span>
      );
    }

    if (colKey === 'emailAddress') {
      return (
        <div className="flex items-center gap-1.5 max-w-[220px]">
          <Mail className="w-3 h-3 text-slate-400 shrink-0" />
          <span className="truncate text-slate-900 font-medium select-none" title={strVal}>
            {strVal}
          </span>
        </div>
      );
    }

    if (colKey === 'companyPhone' || colKey === 'directNumber' || colKey === 'otherNumber') {
      return (
        <div className="flex items-center gap-1.5 font-mono text-[11px] whitespace-nowrap">
          <Phone className="w-3 h-3 text-slate-400 shrink-0" />
          <span className="select-none">{strVal}</span>
        </div>
      );
    }

    if (colKey === 'companyName') {
      return (
        <div className="flex items-center gap-1.5 max-w-[200px]">
          <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="font-semibold text-slate-900 truncate" title={strVal}>
            {strVal}
          </span>
        </div>
      );
    }

    if (colKey === 'jobLevel' || colKey === 'managementLevel') {
      const lower = strVal.toLowerCase();
      let badgeCls = 'bg-slate-100 text-slate-700 border-slate-200';
      if (lower.includes('c-level') || lower.includes('c-suite') || lower.includes('chief') || lower.includes('executive') || lower.includes('ceo') || lower.includes('cto') || lower.includes('founder') || lower.includes('owner')) {
        badgeCls = 'bg-purple-50 text-purple-700 border-purple-200';
      } else if (lower.includes('vp') || lower.includes('vice president')) {
        badgeCls = 'bg-indigo-50 text-indigo-700 border-indigo-200';
      } else if (lower.includes('director') || lower.includes('head')) {
        badgeCls = 'bg-blue-50 text-blue-700 border-blue-200';
      } else if (lower.includes('manager')) {
        badgeCls = 'bg-emerald-50 text-emerald-700 border-emerald-200';
      } else if (lower.includes('senior') || lower.includes('lead')) {
        badgeCls = 'bg-cyan-50 text-cyan-700 border-cyan-200';
      } else if (lower.includes('specialist') || lower.includes('intermediate')) {
        badgeCls = 'bg-amber-50 text-amber-700 border-amber-200';
      } else if (lower.includes('entry') || lower.includes('junior') || lower.includes('intern')) {
        badgeCls = 'bg-slate-100 text-slate-600 border-slate-200';
      }

      return (
        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold border ${badgeCls}`}>
          {strVal}
        </span>
      );
    }

    if (colKey === 'emailStatus') {
      const lower = strVal.toLowerCase();
      let badgeCls = 'bg-slate-100 text-slate-700';
      if (lower.includes('valid')) badgeCls = 'bg-emerald-50 text-emerald-700 border border-emerald-200/80';
      else if (lower.includes('catch') || lower.includes('pending')) badgeCls = 'bg-amber-50 text-amber-700 border border-amber-200/80';
      else if (lower.includes('invalid') || lower.includes('bounced')) badgeCls = 'bg-rose-50 text-rose-700 border border-rose-200/80';

      return (
        <span className={`inline-block px-1.5 py-0.2 rounded text-[10px] font-semibold ${badgeCls}`}>
          {strVal}
        </span>
      );
    }

    if (colKey.endsWith('Url') || colKey.endsWith('Link')) {
      return (
        <a
          href={strVal}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 hover:underline inline-flex items-center gap-1 text-[11px] truncate max-w-[160px]"
        >
          <ExternalLink className="w-3 h-3 shrink-0" />
          <span className="truncate">{strVal}</span>
        </a>
      );
    }

    return (
      <span className="truncate block max-w-[220px]" title={strVal}>
        {strVal}
      </span>
    );
  };

  // 1. DATA WORKSPACE & SEARCH HERO: Initial Apollo-style Prospecting Screen
  if (!hasActiveFilter) {
    return (
      <div className="flex-1 bg-slate-50 flex flex-col overflow-y-auto select-none relative">
        {/* Top Search Percentage Bar (Shown when actively scanning DB) */}
        {isSearching && (
          <div className="bg-blue-600 text-white px-4 py-2 flex items-center justify-between text-xs font-medium z-30 shrink-0">
            <div className="flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>{searchStatusMsg || 'Scanning database index...'}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-32 h-1.5 bg-blue-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-150"
                  style={{ width: `${searchProgress}%` }}
                />
              </div>
              <span className="font-mono font-bold">{searchProgress}%</span>
            </div>
          </div>
        )}

        {/* Hero Prospecting Container */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 max-w-2xl mx-auto w-full my-auto space-y-6">
          {/* Quick Search Header */}
          <div className="w-full text-center space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-200/80 rounded-full text-[11px] font-semibold text-blue-700">
              <Search className="w-3 h-3" />
              <span>Alltake Lead Explorer · Database Engine</span>
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Find Targeted Prospects & Decision Makers
            </h1>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Search by title, management level, company, or location across verified database records.
            </p>
          </div>

          {/* Quick Search Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (leadSearchInput.trim() && onSearchPeople) {
                onSearchPeople(leadSearchInput.trim());
              }
            }}
            className="w-full flex items-center gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm focus-within:ring-2 focus-within:ring-blue-600 focus-within:border-blue-600 transition-all"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={leadSearchInput}
                onChange={(e) => setLeadSearchInput(e.target.value)}
                placeholder="Search job title (e.g. Director, VP, Manager, CEO)..."
                className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 bg-transparent focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              disabled={!leadSearchInput.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-40 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
            >
              Search Prospects
            </button>
          </form>

          {/* Quick One-Click Filters (Job Title & Management Level Chips) */}
          <div className="w-full space-y-2 text-center">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Popular Quick Filters
            </span>
            <div className="flex flex-wrap items-center justify-center gap-1.5">
              <button
                type="button"
                onClick={() => onApplyQuickFilter?.('managementLevel', 'Director')}
                className="px-3 py-1.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-medium text-slate-700 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <Briefcase className="w-3 h-3 text-blue-600" />
                <span>Director</span>
              </button>
              <button
                type="button"
                onClick={() => onApplyQuickFilter?.('managementLevel', 'VP')}
                className="px-3 py-1.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-medium text-slate-700 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <Briefcase className="w-3 h-3 text-blue-600" />
                <span>VP</span>
              </button>
              <button
                type="button"
                onClick={() => onApplyQuickFilter?.('managementLevel', 'C-Suite')}
                className="px-3 py-1.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-medium text-slate-700 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <Briefcase className="w-3 h-3 text-blue-600" />
                <span>C-Suite</span>
              </button>
              <button
                type="button"
                onClick={() => onApplyQuickFilter?.('managementLevel', 'Manager')}
                className="px-3 py-1.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-medium text-slate-700 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <Briefcase className="w-3 h-3 text-blue-600" />
                <span>Manager</span>
              </button>
              <button
                type="button"
                onClick={() => onApplyQuickFilter?.('industry', 'Engineering & Technical')}
                className="px-3 py-1.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-medium text-slate-700 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <Building className="w-3 h-3 text-blue-600" />
                <span>Engineering & Tech</span>
              </button>
            </div>
          </div>

          {/* Database Status & Query Guidance */}
          <div className="w-full bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shrink-0">
                <Database className="w-4 h-4" />
              </div>
              <div className="text-left">
                <span className="text-xs font-bold text-slate-900 block">
                  Enterprise Database Ready
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {(allLeadsCount ?? 0).toLocaleString()} Verified Records in Storage Vault
                </span>
              </div>
            </div>

            <span className="text-[11px] font-medium text-slate-500 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg hidden sm:inline-flex items-center gap-1.5">
              <span>Use search bar or quick filters to view records</span>
            </span>
          </div>

          {/* Security & Masking Note */}
          <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Strict Role-Based Field Masking & Enterprise Privacy Enforced</span>
          </p>
        </div>
      </div>
    );
  }

  // 2. NO RECORDS MATCH FILTER: When filter was applied but 0 leads matched
  if (leads.length === 0) {
    return (
      <div className="flex-1 bg-slate-50 flex flex-col items-center justify-center p-6 select-none relative">
        <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200/90 p-8 shadow-xs text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center mx-auto text-amber-600">
            <Filter className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              No Records Match Filters
            </h2>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              0 prospects matched your current query criteria. Try adjusting or clearing some filter facets on the left.
            </p>
          </div>

          <div className="pt-2">
            <span className="text-xs font-mono text-slate-500">
              Query evaluated across {(allLeadsCount ?? 0).toLocaleString()} database records
            </span>
          </div>
        </div>
      </div>
    );
  }

  // 2. ACTIVE RESULTS VIEW (Renders exact records loaded from DB)
  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden relative">
      {/* Top Search Percentage Bar when active filter is refreshing */}
      {isSearching && (
        <div className="bg-blue-600 text-white px-4 py-1.5 flex items-center justify-between text-xs font-medium z-30">
          <div className="flex items-center gap-2">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>{searchStatusMsg || 'Querying database records...'}</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-28 h-1.5 bg-blue-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-150"
                style={{ width: `${searchProgress}%` }}
              />
            </div>
            <span className="font-mono font-bold">{searchProgress}%</span>
          </div>
        </div>
      )}

      {/* Table Toolbar & Actions */}
      <div className="px-4 py-2.5 bg-slate-50/80 border-b border-slate-200/90 flex flex-wrap items-center justify-between gap-3 shrink-0">
        {/* Left: Record Count & Selection */}
        <div className="flex items-center gap-2.5">
          <span className="text-xs font-bold text-slate-900 font-mono">
            {leads.length.toLocaleString()}
          </span>
          <span className="text-xs text-slate-500">
            {hasActiveFilter ? 'records matched' : 'records from database'}
          </span>

          {selectedIds.size > 0 && (
            <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md">
              {selectedIds.size} selected
            </span>
          )}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Admin Column Layout & Ordering Button */}
          {(isAdmin || isDataManager) && (
            <button
              type="button"
              onClick={() => setIsColumnManagerOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title="Admin Privilege: Reorder column positions (Aage/Peeche) and set employee visibility"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-blue-600" />
              <span>Column Layout & Order</span>
              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 bg-blue-50 text-blue-700 rounded-full border border-blue-200">
                {visibleColumns.length} Active Columns
              </span>
            </button>
          )}

          {/* Export Approvals & History Button */}
          <button
            type="button"
            onClick={() => setIsExportRequestsModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-lg shadow-2xs transition-colors cursor-pointer"
            title="View submitted export approval requests & download approved batches"
          >
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Export Approvals</span>
          </button>

          {/* Download Filtered Data Button */}
          <button
            type="button"
            onClick={handleInitiateExport}
            disabled={leads.length === 0 || isExporting}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer"
            title="Download matching leads across all active columns"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Exporting...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>
                  Export Filtered Data {selectedIds.size > 0 ? `(${selectedIds.size})` : `(${leads.length})`}
                </span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Active Filter Criteria Summary Bar */}
      {activeFilterSummary && (
        <div className="px-4 py-1.5 bg-blue-50/40 border-b border-blue-100 flex items-center justify-between text-[11px] text-blue-950 shrink-0">
          <div className="flex items-center gap-1.5 truncate mr-2">
            <Filter className="w-3 h-3 text-blue-600 shrink-0" />
            <span className="font-semibold shrink-0">Applied Query:</span>
            <span className="truncate font-mono text-[10px] text-blue-800">
              {activeFilterSummary}
            </span>
          </div>
          <span className="text-[10px] text-slate-500 font-medium shrink-0">
            {visibleColumns.length} Dynamic Columns Active
          </span>
        </div>
      )}

      {/* Main Table Area */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 text-slate-700 uppercase text-[10px] font-semibold sticky top-0 z-10 border-b border-slate-200">
            <tr>
              {/* Checkbox column */}
              <th className="py-2.5 px-3 w-10 text-center bg-slate-50">
                <button
                  type="button"
                  onClick={toggleSelectAll}
                  className="text-slate-400 hover:text-blue-600 cursor-pointer"
                  aria-label="Select all rows on this page"
                >
                  {selectedIds.size === paginatedLeads.length && paginatedLeads.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-blue-600" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>
              </th>

              {/* Dynamic / Visible Columns */}
              {visibleColumns.map((col, idx) => (
                <th
                  key={col.key}
                  className="py-2.5 px-3 font-semibold whitespace-nowrap bg-slate-50 tracking-wider text-slate-700 group hover:bg-slate-100/90 transition-colors"
                >
                  <div className="flex items-center justify-between gap-1.5">
                    <div className="flex items-center gap-1.5">
                      {isAdmin && (
                        <span className="text-[9px] font-mono font-bold text-slate-400 bg-slate-200/70 px-1 py-0.2 rounded">
                          #{col.order ?? (idx + 1)}
                        </span>
                      )}
                      <span>{col.label}</span>
                      {getFieldVisibility(col.key) === 'MASKED' && (
                        <Lock className="w-2.5 h-2.5 text-slate-400" />
                      )}
                    </div>

                    {/* Quick Reorder Arrows for Admin on Live Header */}
                    {isAdmin && (
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveColumnQuick(col.key, 'UP');
                          }}
                          title="Move column left (aage)"
                          className="p-0.5 hover:bg-slate-200 rounded text-slate-500 hover:text-blue-600 cursor-pointer"
                        >
                          <ChevronLeft className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveColumnQuick(col.key, 'DOWN');
                          }}
                          title="Move column right (peeche)"
                          className="p-0.5 hover:bg-slate-200 rounded text-slate-500 hover:text-blue-600 cursor-pointer"
                        >
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {paginatedLeads.length === 0 ? (
              <tr>
                <td colSpan={visibleColumns.length + 1} className="py-16 text-center text-slate-400">
                  <div className="space-y-1.5 max-w-sm mx-auto">
                    <Filter className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                    <p className="text-xs font-semibold text-slate-800">
                      No records match this filter combination
                    </p>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Try relaxing some criteria in the filter sidebar and click Apply Filters again.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              paginatedLeads.map((lead) => {
                const isSelected = selectedIds.has(lead.id);

                return (
                  <tr
                    key={lead.id}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      isSelected ? 'bg-blue-50/40' : 'bg-white'
                    }`}
                  >
                    {/* Row Select Checkbox */}
                    <td className="py-2 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => toggleSelectRow(lead.id)}
                        className="text-slate-400 hover:text-blue-600 cursor-pointer"
                        aria-label={`Select row for ${lead.companyName || lead.id}`}
                      >
                        {isSelected ? (
                          <CheckSquare className="w-3.5 h-3.5 text-blue-600" />
                        ) : (
                          <Square className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </td>

                    {/* Columns */}
                    {visibleColumns.map((col) => (
                      <td
                        key={col.key}
                        className="py-2 px-3 text-slate-700 max-w-[240px]"
                        style={
                          getFieldVisibility(col.key) === 'MASKED'
                            ? { userSelect: 'none', WebkitUserSelect: 'none' }
                            : undefined
                        }
                      >
                        {renderCellContent(lead, col.key)}
                      </td>
                    ))}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="px-4 py-2 bg-white border-t border-slate-200 flex items-center justify-between gap-4 text-xs shrink-0">
        <div className="flex items-center gap-3 text-slate-500">
          <span>
            Showing <strong className="text-slate-800 font-mono">{Math.min(startIndex + 1, leads.length)}</strong> to{' '}
            <strong className="text-slate-800 font-mono">{Math.min(startIndex + pageSize, leads.length)}</strong> of{' '}
            <strong className="text-slate-800 font-mono">{leads.length.toLocaleString()}</strong> results
          </span>

          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-0.5 border border-slate-200 rounded text-xs bg-slate-50 focus:bg-white text-slate-700"
          >
            <option value={10}>10 per page</option>
            <option value={25}>25 per page</option>
            <option value={50}>50 per page</option>
            <option value={100}>100 per page</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white text-slate-600 cursor-pointer"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <span className="px-2 py-0.5 font-mono text-slate-700 font-semibold text-[11px]">
            {currentPage} / {totalPages}
          </span>

          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded border border-slate-200 hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white text-slate-600 cursor-pointer"
            aria-label="Next page"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Admin Column Layout & Visibility Modal */}
      {(isAdmin || isDataManager) && (
        <ColumnLayoutManagerModal
          isOpen={isColumnManagerOpen}
          onClose={() => setIsColumnManagerOpen(false)}
          columns={columns}
          onColumnsUpdated={(updated) => {
            if (onColumnsChanged) {
              onColumnsChanged(updated);
            }
          }}
          onNotify={onNotify}
        />
      )}

      {/* Export Approval Request Modal (for requests exceeding quota, default 10,000) */}
      <ExportApprovalModal
        isOpen={isExportApprovalModalOpen}
        onClose={() => setIsExportApprovalModalOpen(false)}
        currentUser={currentUser}
        recordsCount={selectedIds.size > 0 ? selectedIds.size : leads.length}
        allowedLimit={exportQuotaLimit}
        activeFilterSummary={activeFilterSummary}
        activeFiltersJson={activeFiltersJson}
        onNotify={onNotify}
        onRequestSubmitted={() => {
          setIsExportApprovalModalOpen(false);
          setIsExportRequestsModalOpen(true);
        }}
      />

      {/* Export Requests & History Modal */}
      <ExportRequestsModal
        isOpen={isExportRequestsModalOpen}
        onClose={() => setIsExportRequestsModalOpen(false)}
        currentUser={currentUser}
        columns={columns}
        visibilityRules={visibilityRules}
        onNotify={onNotify}
      />

      {/* Campaign Export Verification Modal */}
      <CampaignExportModal
        isOpen={isCampaignModalOpen}
        onClose={() => setIsCampaignModalOpen(false)}
        recordsCount={selectedIds.size > 0 ? selectedIds.size : leads.length}
        activeFilterSummary={activeFilterSummary}
        currentUser={currentUser}
        onConfirmExport={handleConfirmCampaignExport}
        isExporting={isExporting}
      />
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { DmsLogo } from '../common/DmsLogo';
import {
  SlidersHorizontal,
  Upload,
  LogOut,
  BarChart3,
  SearchCheck,
  ChevronDown,
  Settings,
  Download,
  Compass,
  KeyRound,
  User,
  Database
} from 'lucide-react';
import { UserRole } from '../../types';
import { OnboardingTour } from '../tour/OnboardingTour';
import { SetPasswordModal } from '../auth/SetPasswordModal';
import { ProfileEditModal } from '../auth/ProfileEditModal';

interface TopNavProps {
  currentView: 'explorer' | 'dashboard' | 'settings' | 'approved';
  onViewChange: (view: 'explorer' | 'dashboard' | 'settings' | 'approved') => void;
  isFiltersVisible: boolean;
  onToggleFilters: () => void;
  onOpenUpload: () => void;
  onOpenAdminSettings?: (tab?: 'users' | 'columns' | 'filters' | 'masking' | 'exports' | 'logs' | 'database') => void;
  onLogout: () => void;
  userName: string;
  userRole: UserRole;
  approvedCount?: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentView,
  onViewChange,
  isFiltersVisible,
  onToggleFilters,
  onOpenUpload,
  onOpenAdminSettings,
  onLogout,
  userName,
  userRole,
  approvedCount = 0,
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [showTour, setShowTour] = useState(false);
  const [showSetPasswordModal, setShowSetPasswordModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const isAdmin = userRole === 'ADMIN';
  const isDataManager = userRole === 'DATA_MANAGER';
  const firstName = (userName || '').split(' ')[0] || 'User';

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-14 backdrop-blur-2xl bg-white/80 border-b border-slate-200/70 flex items-center justify-between px-3 sm:px-6 z-20 shrink-0 shadow-xs">
      {/* Left zone: Brand Logo */}
      <div className="flex items-center gap-3">
        <DmsLogo size="md" />
      </div>

      {/* Center zone: The 3 Primary Views ONLY (Lead Explorer, Dashboard, Approved Downloads) */}
      <div className="flex items-center gap-2">
        <div className="flex items-center bg-slate-100/80 backdrop-blur-xl p-0.5 rounded-xl border border-slate-200/70 text-xs shadow-2xs">
          <button
            onClick={() => onViewChange('explorer')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer font-medium shrink-0 ${
              currentView === 'explorer'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <SearchCheck className="w-3.5 h-3.5" />
            <span>Lead Explorer</span>
          </button>

          <button
            onClick={() => onViewChange('dashboard')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer font-medium shrink-0 ${
              currentView === 'dashboard'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => onViewChange('approved')}
            className={`px-3 sm:px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer font-medium relative shrink-0 ${
              currentView === 'approved'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Approved Downloads</span>
            <span className="sm:hidden">Approved</span>
            {approvedCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 rounded-full bg-emerald-500 text-white text-[10px] font-bold">
                {approvedCount}
              </span>
            )}
          </button>
        </div>

        {/* Hide / Show Filters Toggle (Only active in explorer view) */}
        {currentView === 'explorer' && (
          <button
            onClick={onToggleFilters}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
              isFiltersVisible
                ? 'bg-slate-50/80 border-slate-200 text-slate-700 hover:bg-slate-100'
                : 'bg-blue-50 border-blue-200 text-blue-700 font-semibold'
            }`}
            title="Toggle filter sidebar visibility"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{isFiltersVisible ? 'Hide Filters' : 'Show Filters'}</span>
          </button>
        )}
      </div>

      {/* Right zone: ONLY User Profile Menu Button (Everything else is cleanly inside the dropdown) */}
      <div className="flex items-center">
        <div className="relative" ref={userMenuRef}>
          <button
            type="button"
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
            className="flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-xl border border-slate-200/90 bg-white hover:bg-slate-50 transition-all cursor-pointer shadow-2xs"
            aria-label="User Account Menu"
          >
            <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
              {userName.slice(0, 2).toUpperCase() || 'AD'}
            </div>
            <div className="hidden sm:flex flex-col text-left leading-tight">
              <span className="text-xs font-semibold text-slate-900 max-w-[110px] truncate">{firstName}</span>
              <span className="text-[10px] text-slate-500 font-medium">
                {isAdmin ? 'Super Admin' : isDataManager ? 'Data Manager' : 'Employee'}
              </span>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Clean Apple-style Profile Dropdown Menu */}
          {isUserMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-64 bg-white/95 backdrop-blur-2xl border border-slate-200/90 rounded-2xl shadow-xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
              {/* User Identity Header */}
              <div className="px-4 py-2.5 border-b border-slate-100 bg-slate-50/70">
                <p className="text-xs font-bold text-slate-900 truncate">{userName}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 border border-blue-200/80 px-2 py-0.2 rounded-md">
                    {isAdmin ? 'Super Admin' : isDataManager ? 'Data Manager' : 'Employee'}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200/70 font-semibold">
                    Authorized
                  </span>
                </div>
              </div>

              {/* Administrative Actions */}
              {isAdmin && (
                <div className="py-1 border-b border-slate-100 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenAdminSettings?.('users');
                    }}
                    className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <Settings className="w-3.5 h-3.5 text-blue-600" />
                    <span>Admin Settings Center</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenAdminSettings?.('database');
                    }}
                    className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <Database className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Database Cluster Health</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      setShowSetPasswordModal(true);
                    }}
                    className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Set Employee Password</span>
                  </button>
                </div>
              )}

              {/* Data Ingestion (Admin & Data Manager) */}
              {(isAdmin || isDataManager) && (
                <div className="py-1 border-b border-slate-100 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onOpenUpload();
                    }}
                    className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>Upload Daily Data</span>
                  </button>
                </div>
              )}

              {/* User Personal Actions: Profile & Guided Tour */}
              <div className="py-1 border-b border-slate-100 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setIsUserMenuOpen(false);
                    setShowProfileModal(true);
                  }}
                  className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                >
                  <User className="w-3.5 h-3.5 text-slate-600" />
                  <span>My Profile & Credentials</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsUserMenuOpen(false);
                    setShowTour(true);
                  }}
                  className="w-full text-left px-3.5 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
                >
                  <Compass className="w-3.5 h-3.5 text-blue-600" />
                  <span>Guided Product Tour</span>
                </button>
              </div>

              {/* Sign Out */}
              <button
                type="button"
                onClick={() => {
                  setIsUserMenuOpen(false);
                  onLogout();
                }}
                className="w-full text-left px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Tour & Modals */}
      <OnboardingTour forceOpen={showTour} onClose={() => setShowTour(false)} />
      <SetPasswordModal
        isOpen={showSetPasswordModal}
        onClose={() => setShowSetPasswordModal(false)}
      />
      <ProfileEditModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
      />
    </header>
  );
};

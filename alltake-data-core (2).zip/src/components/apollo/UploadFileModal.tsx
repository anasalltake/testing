import React, { useState, useRef } from 'react';
import { DmsLogo } from '../common/DmsLogo';
import {
  X,
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Download,
  Layers,
  FileText,
  ShieldCheck,
  Database,
  Sliders,
  CopyCheck
} from 'lucide-react';
import { ingestEnterpriseFile, downloadSample31Template } from '../../services/enterpriseDb';
import { EnterpriseColumnDef, EnterpriseLeadRecord } from '../../types/enterprise';

interface UploadFileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (res: {
    addedCount: number;
    leads: EnterpriseLeadRecord[];
    columns: EnterpriseColumnDef[];
    stats?: any;
    message?: string;
  }) => void;
}

export const UploadFileModal: React.FC<UploadFileModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importMode, setImportMode] = useState<'APPEND' | 'UPDATE' | 'REPLACE'>('APPEND');
  const [duplicateStrategy, setDuplicateStrategy] = useState<'email' | 'full_row' | 'phone'>('email');
  const [handleDuplicates, setHandleDuplicates] = useState<'SKIP' | 'UPDATE' | 'IMPORT_ALL'>('SKIP');
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStageText, setUploadStageText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFile = (file: File) => {
    setError(null);
    const validExtensions = ['csv', 'xlsx', 'xls', 'tsv', 'txt', 'json'];
    const ext = file.name.split('.').pop()?.toLowerCase() || '';

    if (!validExtensions.includes(ext)) {
      setError(`Unsupported file type (.${ext}). Permitted formats: CSV, XLSX, XLS, TSV, TXT, JSON.`);
      return;
    }

    setSelectedFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmUpload = async () => {
    if (!selectedFile) return;
    setIsProcessing(true);
    setError(null);
    setUploadProgress(20);
    setUploadStageText('Streaming file payload to backend PostgreSQL transaction...');

    try {
      const p1 = setTimeout(() => {
        setUploadProgress(50);
        setUploadStageText('Evaluating duplicate policies and dynamic schemas...');
      }, 200);

      const p2 = setTimeout(() => {
        setUploadProgress(80);
        setUploadStageText('Committing records to PostgreSQL database table...');
      }, 400);

      const result = await ingestEnterpriseFile(selectedFile, {
        datasetName: selectedFile.name.replace(/\.[^/.]+$/, ''),
        importMode,
        duplicateStrategy,
        handleDuplicates,
      });

      clearTimeout(p1);
      clearTimeout(p2);

      setUploadProgress(100);
      setUploadStageText(
        result.message ||
        `PostgreSQL verified! Stored ${result.addedCount.toLocaleString()} records across ${result.columns.length} columns.`
      );

      setTimeout(() => {
        onUploadSuccess(result);
        setSelectedFile(null);
        setUploadProgress(0);
        setUploadStageText('');
        setIsProcessing(false);
        onClose();
      }, 400);
    } catch (err: any) {
      setError(err.message || 'Database ingestion failed. PostgreSQL could not confirm transaction.');
      setIsProcessing(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50/90 border-b border-slate-200 shrink-0">
          <div className="flex items-center gap-3">
            <DmsLogo size="sm" variant="icon" />
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span>Daily Dataset Ingestion</span>
                <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-1.5 py-0.2 rounded border border-emerald-200">
                  PostgreSQL Master Vault
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                CSV, Excel (XLSX, XLS), TSV, TXT, and JSON
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors disabled:opacity-30 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div>
                <span className="font-bold block text-rose-900">Database Upload Failed</span>
                <span className="text-[11px] leading-relaxed">{error}</span>
              </div>
            </div>
          )}

          {/* Processing Progress Bar */}
          {isProcessing && (
            <div className="p-4 rounded-xl bg-blue-50/90 border border-blue-200 space-y-2.5 animate-in fade-in duration-150">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-blue-900 flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                  <span>{uploadStageText || 'Ingesting dataset...'}</span>
                </span>
                <span className="font-mono text-blue-700 font-bold text-sm">
                  {uploadProgress}%
                </span>
              </div>
              <div className="h-2.5 w-full bg-blue-200/70 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 rounded-full transition-all duration-200 ease-out"
                  style={{ width: `${Math.min(100, Math.max(8, uploadProgress))}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-blue-600 font-medium pt-0.5">
                <span>Transactional Commits</span>
                <span>Authoritative Database Store</span>
              </div>
            </div>
          )}

          {/* Download Sample Template Banner */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
            <div>
              <span className="block text-xs font-bold text-slate-800">
                Official 31-Column Template
              </span>
              <span className="text-[11px] text-slate-500">
                Standard headers with dynamic schema mapping
              </span>
            </div>
            <button
              type="button"
              onClick={downloadSample31Template}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Template</span>
            </button>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-blue-600 bg-blue-50/60 scale-[0.99]'
                : selectedFile
                ? 'border-blue-500 bg-blue-50/30'
                : 'border-slate-300 hover:border-blue-400 bg-slate-50/60 hover:bg-slate-50'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls,.tsv,.txt,.json"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFile(e.target.files[0]);
                }
              }}
            />

            {selectedFile ? (
              <div className="flex flex-col items-center">
                <div className="w-11 h-11 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1.5 shadow-xs">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-900 font-mono">
                  {selectedFile.name}
                </span>
                <span className="text-[11px] text-slate-500 mt-0.5">
                  {(selectedFile.size / 1024).toFixed(1)} KB • Click or drop to replace
                </span>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <div className="w-11 h-11 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mb-1.5">
                  <UploadCloud className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-800">
                  Click to browse or drop dataset file
                </span>
                <span className="text-[11px] text-slate-500 mt-0.5">
                  CSV, Excel (XLSX, XLS), TSV, TXT, or JSON
                </span>
              </div>
            )}
          </div>

          {/* 1. Import Operation Mode (APPEND BY DEFAULT) */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-blue-600" />
                <span>Import Operation Mode</span>
              </span>
              <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
                Default: Append New Records (Preserve Existing)
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
              <button
                type="button"
                onClick={() => setImportMode('APPEND')}
                className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
                  importMode === 'APPEND'
                    ? 'bg-blue-50 border-blue-500 text-blue-900 font-semibold shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="font-bold text-[11px] text-blue-900">Append (Default)</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Keep existing, add new rows</div>
              </button>

              <button
                type="button"
                onClick={() => setImportMode('UPDATE')}
                className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
                  importMode === 'UPDATE'
                    ? 'bg-blue-50 border-blue-500 text-blue-900 font-semibold shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="font-bold text-[11px]">Update Existing</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Refresh matching rows</div>
              </button>

              <button
                type="button"
                onClick={() => setImportMode('REPLACE')}
                className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
                  importMode === 'REPLACE'
                    ? 'bg-rose-50 border-rose-400 text-rose-900 font-semibold shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="font-bold text-[11px] text-rose-800">Replace Dataset</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Clear & overwrite previous</div>
              </button>
            </div>
            {importMode === 'REPLACE' && (
              <div className="p-2 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-700">
                ⚠️ <strong>Caution:</strong> Selecting Replace will wipe previous records and replace them with this dataset.
              </div>
            )}
          </div>

          {/* 2. Admin-Controlled Duplicate Detection Strategy */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <CopyCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span>Duplicate Matching Strategy</span>
              </span>
              <span className="text-[10px] text-slate-500">Backend Enforced</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Matching Criterion:
                </label>
                <select
                  value={duplicateStrategy}
                  onChange={(e) => setDuplicateStrategy(e.target.value as any)}
                  className="w-full p-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="email">Email Matching (Normalized)</option>
                  <option value="full_row">Full-Row Content Hash</option>
                  <option value="phone">Phone Number Matching</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  On Duplicate Match:
                </label>
                <select
                  value={handleDuplicates}
                  onChange={(e) => setHandleDuplicates(e.target.value as any)}
                  className="w-full p-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="SKIP">Skip Duplicates (Recommended)</option>
                  <option value="UPDATE">Update Matching Record</option>
                  <option value="IMPORT_ALL">Import All (Keep Duplicates)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-800 rounded-lg cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="button"
            disabled={!selectedFile || isProcessing}
            onClick={handleConfirmUpload}
            className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs disabled:opacity-50 transition-colors flex items-center gap-2 cursor-pointer"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Saving to Database...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Ingest & Save in PostgreSQL</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  XCircle,
  Download,
  X,
  RefreshCw,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { ExportApprovalRequest, EnterpriseUser, EnterpriseColumnDef, FieldVisibilityRule } from '../../types/enterprise';
import { getExportApprovalRequests, getAllLeads, downloadEnterpriseCsv } from '../../services/enterpriseDb';

interface ExportRequestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: EnterpriseUser | null;
  columns: EnterpriseColumnDef[];
  visibilityRules: FieldVisibilityRule[];
  onNotify: (msg: string) => void;
}

export const ExportRequestsModal: React.FC<ExportRequestsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  columns,
  visibilityRules,
  onNotify,
}) => {
  const [requests, setRequests] = useState<ExportApprovalRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await getExportApprovalRequests();
      setRequests(data);
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadRequests();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDownloadApproved = async (req: ExportApprovalRequest) => {
    if (req.status !== 'APPROVED') return;
    setDownloadingId(req.id);

    try {
      // Fetch full leads from verified database
      const allLeads = await getAllLeads();
      const recordsToExport = allLeads.slice(0, req.requested_count);

      const isEmployee = currentUser?.role === 'EMPLOYEE';
      downloadEnterpriseCsv(
        recordsToExport,
        `Alltake_Approved_Export_${req.id}_${new Date().toISOString().split('T')[0]}.csv`,
        columns,
        {
          isEmployee,
          visibilityRules,
        }
      );

      onNotify(`Successfully downloaded approved dataset (${recordsToExport.length.toLocaleString()} leads)`);
    } catch (err: any) {
      onNotify('Download failed: ' + (err?.message || 'Error creating export file'));
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200/80 w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Export Approvals & History</h3>
              <p className="text-xs text-slate-500">
                Track status of your requested dataset downloads and approved batches
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={loadRequests}
              disabled={isLoading}
              title="Refresh"
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Requests List */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {requests.length === 0 ? (
            <div className="text-center py-12 text-slate-400 space-y-2">
              <FileSpreadsheet className="w-10 h-10 mx-auto text-slate-300 stroke-1" />
              <p className="text-xs font-medium text-slate-600">No export approval requests submitted yet</p>
              <p className="text-[11px] text-slate-400">
                When you request to download more than 10,000 records, your requests will appear here.
              </p>
            </div>
          ) : (
            requests.map((r) => (
              <div
                key={r.id}
                className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all shadow-2xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-900">{r.id}</span>
                      <span className="text-[11px] font-medium text-slate-500 font-mono">
                        {r.requested_count.toLocaleString()} leads ({r.file_format})
                      </span>
                      {r.campaign_name && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.2 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                          🎯 {r.campaign_name}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-700 mt-1 font-medium">{r.reason}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Requested {new Date(r.created_at).toLocaleString()} by {r.user_name}
                    </p>
                  </div>

                  <div>
                    {r.status === 'PENDING' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                        <Clock className="w-3.5 h-3.5" /> Pending Review
                      </span>
                    )}
                    {r.status === 'APPROVED' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approved
                      </span>
                    )}
                    {r.status === 'REJECTED' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                        <XCircle className="w-3.5 h-3.5" /> Rejected
                      </span>
                    )}
                  </div>
                </div>

                {r.admin_note && (
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-[11px] text-slate-600 flex items-start gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="font-semibold text-slate-800">Admin Note:</span> {r.admin_note}
                    </div>
                  </div>
                )}

                {r.status === 'APPROVED' && (
                  <div className="pt-1 flex items-center justify-end">
                    <button
                      onClick={() => handleDownloadApproved(r)}
                      disabled={downloadingId === r.id}
                      className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{downloadingId === r.id ? 'Generating File...' : 'Download Approved Leads'}</span>
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Alltake Data Governance & Audit Compliance
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  ShieldAlert,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  X,
  Send,
  Loader2,
  Lock,
  AlertTriangle
} from 'lucide-react';
import { EnterpriseUser } from '../../types/enterprise';
import { submitExportApprovalRequest } from '../../services/enterpriseDb';

interface ExportApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: EnterpriseUser | null;
  recordsCount: number;
  allowedLimit: number;
  activeFilterSummary?: string;
  activeFiltersJson?: any;
  onNotify: (msg: string) => void;
  onRequestSubmitted?: () => void;
}

export const ExportApprovalModal: React.FC<ExportApprovalModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  recordsCount,
  allowedLimit,
  activeFilterSummary,
  activeFiltersJson,
  onNotify,
  onRequestSubmitted,
}) => {
  const [campaignName, setCampaignName] = useState('');
  const [reason, setReason] = useState('');
  const [fileFormat, setFileFormat] = useState<'CSV' | 'XLSX'>('CSV');
  const [agreedCompliance, setAgreedCompliance] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRequestId, setSubmittedRequestId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!campaignName.trim()) {
      setError('Please provide a Campaign Name for compliance tracking.');
      return;
    }
    if (!reason.trim()) {
      setError('Please provide a business justification for this bulk export.');
      return;
    }
    if (!agreedCompliance) {
      setError('You must confirm adherence to enterprise data privacy guidelines.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const req = await submitExportApprovalRequest({
        requestedCount: recordsCount,
        fileFormat,
        campaign_name: campaignName.trim(),
        reason: reason.trim(),
        filtersSummary: activeFilterSummary || 'All active filters snapshot',
        filtersSnapshot: activeFiltersJson,
      });

      setSubmittedRequestId(req.id);
      onNotify(`Approval request ${req.id} submitted to Administrator`);
      onRequestSubmitted?.();
    } catch (err: any) {
      setError(err?.message || 'Failed to submit approval request');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200/80 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-start justify-between bg-gradient-to-r from-amber-50/70 via-slate-50 to-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                Enterprise Export Governance
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200">
                  Approval Required
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Bulk export request exceeds default employee download limit
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {submittedRequestId ? (
            <div className="py-6 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Request Sent for Admin Approval</h4>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Your request to export <strong className="text-slate-900">{recordsCount.toLocaleString()} leads</strong> has been submitted as request <code className="text-blue-700 bg-blue-50 px-1 py-0.5 rounded font-mono font-semibold">{submittedRequestId}</code>.
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left text-xs text-slate-600 space-y-1 max-w-sm mx-auto">
                <div className="flex justify-between">
                  <span className="text-slate-500">Status:</span>
                  <span className="font-semibold text-amber-600 inline-flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> Pending Admin Review
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Format:</span>
                  <span className="font-medium text-slate-800">{fileFormat}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Employee:</span>
                  <span className="font-medium text-slate-800">{currentUser?.full_name}</span>
                </div>
              </div>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Close & Await Approval
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Threshold Comparison Card */}
              <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-amber-900 font-semibold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-700" />
                    Employee Quota Policy
                  </span>
                  <span className="text-slate-600 font-mono text-[11px]">
                    Max Direct: <strong className="text-slate-900">{allowedLimit.toLocaleString()}</strong> rows
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1 border-t border-amber-200/60">
                  <span className="text-slate-700">Requested Dataset Volume:</span>
                  <span className="font-bold text-amber-900 font-mono">
                    {recordsCount.toLocaleString()} leads
                  </span>
                </div>
                <p className="text-[11px] text-amber-800/90 leading-relaxed">
                  To safeguard company data integrity, mass exports beyond 10,000 records require verified business justification and Administrator sign-off.
                </p>
              </div>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Campaign Name Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Campaign Name / Project Code <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={campaignName}
                  onChange={(e) => setCampaignName(e.target.value)}
                  placeholder="e.g. Q4 EMEA Enterprise Tech Outreach"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600 transition-colors font-medium"
                  required
                />
              </div>

              {/* Justification Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Business Justification / Reason <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g., Q4 Enterprise Outreach Campaign for Directors and VPs in the Healthcare & Tech sectors."
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600 transition-colors"
                  required
                />
              </div>

              {/* Format selection */}
              <div className="grid grid-cols-2 gap-3">
                <label
                  className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                    fileFormat === 'CSV'
                      ? 'border-blue-600 bg-blue-50/50 text-blue-900 font-semibold'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="fileFormat"
                    value="CSV"
                    checked={fileFormat === 'CSV'}
                    onChange={() => setFileFormat('CSV')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                    <span>CSV Format</span>
                  </div>
                </label>

                <label
                  className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs cursor-pointer transition-colors ${
                    fileFormat === 'XLSX'
                      ? 'border-blue-600 bg-blue-50/50 text-blue-900 font-semibold'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="fileFormat"
                    value="XLSX"
                    checked={fileFormat === 'XLSX'}
                    onChange={() => setFileFormat('XLSX')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span>Excel (.XLSX)</span>
                  </div>
                </label>
              </div>

              {/* Compliance Checkbox */}
              <div className="pt-1">
                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={agreedCompliance}
                    onChange={(e) => setAgreedCompliance(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-[11px] text-slate-600 leading-snug">
                    I confirm this data will only be utilized for approved enterprise business activities in accordance with Alltake Data Protection Policies.
                  </span>
                </label>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={isSubmitting}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !agreedCompliance || !reason.trim()}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Submitting Request...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Ask Approval to Download</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

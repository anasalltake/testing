import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  MapPin,
  Briefcase,
  Building,
  Globe,
  Users,
  Factory,
  DollarSign,
  Hash,
  ChevronDown,
  ChevronRight,
  Filter,
  RotateCcw,
  Search,
  X,
  SlidersHorizontal,
  Navigation
} from 'lucide-react';
import {
  SerialFiltersState,
  EnterpriseLeadRecord,
  EnterpriseColumnDef,
  EMPLOYEE_SIZE_OPTIONS,
  REVENUE_RANGE_OPTIONS,
  FilterRuleConfig
} from '../../types/enterprise';
import {
  DEFAULT_SERIAL_FILTERS,
  JOB_LEVEL_OPTIONS,
  ALL_WORLD_COUNTRIES,
  getLocationSuggestions,
  LocationSuggestion,
  matchesEmployeeSizeFilter,
  matchesRevenueFilter,
} from '../../services/enterpriseDb';

interface FilterSidebarProps {
  allLeads: EnterpriseLeadRecord[];
  columns: EnterpriseColumnDef[];
  appliedFilters: SerialFiltersState;
  filterRules?: FilterRuleConfig[];
  userRole?: string;
  hasActiveFilter?: boolean;
  filteredCount?: number;
  onApplyFilters: (filters: SerialFiltersState) => void;
  onClearAll: () => void;
  onToggleFilters?: () => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  allLeads,
  appliedFilters,
  filterRules,
  userRole = 'EMPLOYEE',
  hasActiveFilter = false,
  filteredCount = 0,
  onApplyFilters,
  onClearAll,
  onToggleFilters,
}) => {
  const isAdmin = userRole === 'ADMIN';

  // Check if a filter section should be rendered in the sidebar
  const isFilterVisible = (key: string): boolean => {
    // Individual contact fields are strictly excluded from search filters
    if (['name', 'email', 'addressLink', 'phone'].includes(key)) {
      return false;
    }
    // If filterRules provided, follow backend configuration
    if (filterRules && filterRules.length > 0) {
      const rule = filterRules.find((r) => r.key === key || r.id === key);
      if (rule) {
        if (!rule.enabled) return false;
        if (!isAdmin && !rule.visibleToEmployees) return false;
        return true;
      }
    }
    return true;
  };

  // Local editable draft state
  const [draft, setDraft] = useState<SerialFiltersState>(appliedFilters);

  // Search queries for multicheckbox filters
  const [industrySearch, setIndustrySearch] = useState('');
  const [managementLevelSearch, setManagementLevelSearch] = useState('');
  const [jobLevelSearch, setJobLevelSearch] = useState('');

  // Location suggestions state
  const [locationInput, setLocationInput] = useState('');
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);
  const locationDropdownRef = useRef<HTMLDivElement>(null);

  // Dedicated Country input auto-suggestions state
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const countryDropdownRef = useRef<HTMLDivElement>(null);

  // Synchronize draft when appliedFilters change from outside (e.g. clear all)
  useEffect(() => {
    setDraft(appliedFilters);
  }, [appliedFilters]);

  // Accordion open/collapse states (Clean B2B search facets)
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    location: true,
    jobTitle: true,
    managementLevel: true,
    jobLevel: true,
    companyName: true,
    companyDomain: false,
    employeeSize: false,
    industryType: false,
    revenueRange: false,
    sicNaics: false,
  });

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Close location & country dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (locationDropdownRef.current && !locationDropdownRef.current.contains(e.target as Node)) {
        setIsLocationDropdownOpen(false);
      }
      if (countryDropdownRef.current && !countryDropdownRef.current.contains(e.target as Node)) {
        setIsCountryDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Compute smart location suggestions from stored database leads
  const locationSuggestions = useMemo(() => {
    if (!locationInput.trim()) return [];
    return getLocationSuggestions(allLeads, locationInput);
  }, [allLeads, locationInput]);

  // Dedicated Country Autocomplete Suggestions for the Country input field
  const countrySuggestions = useMemo(() => {
    const q = (draft.country || '').trim().toLowerCase();

    const leadCountryCounts = new Map<string, number>();
    for (const lead of allLeads) {
      const c = (lead.country || '').trim();
      if (c) {
        leadCountryCounts.set(c.toLowerCase(), (leadCountryCounts.get(c.toLowerCase()) || 0) + 1);
      }
    }

    const matches: { name: string; count: number }[] = [];
    const seen = new Set<string>();

    if (!q) {
      // When empty and focused, show countries that exist in the database first, then top world countries
      for (const [cLower, count] of leadCountryCounts.entries()) {
        const displayName = allLeads.find((l) => (l.country || '').toLowerCase() === cLower)?.country || cLower;
        if (!seen.has(cLower)) {
          seen.add(cLower);
          matches.push({ name: displayName, count });
        }
      }
      const topCountries = [
        'United States', 'United Kingdom', 'Canada', 'Australia', 'Germany',
        'India', 'France', 'Singapore', 'United Arab Emirates', 'Japan',
        'Netherlands', 'Switzerland', 'Ireland', 'Brazil', 'South Africa'
      ];
      for (const tc of topCountries) {
        const cLower = tc.toLowerCase();
        if (!seen.has(cLower)) {
          seen.add(cLower);
          matches.push({ name: tc, count: leadCountryCounts.get(cLower) || 0 });
        }
      }
      return matches.slice(0, 12);
    }

    for (const country of ALL_WORLD_COUNTRIES) {
      const cLower = country.toLowerCase();
      if (cLower.startsWith(q) || cLower.includes(q)) {
        seen.add(cLower);
        matches.push({
          name: country,
          count: leadCountryCounts.get(cLower) || 0,
        });
      }
    }

    for (const [cLower, count] of leadCountryCounts.entries()) {
      if (!seen.has(cLower) && (cLower.startsWith(q) || cLower.includes(q))) {
        const displayName = allLeads.find((l) => (l.country || '').toLowerCase() === cLower)?.country || cLower;
        matches.push({ name: displayName, count });
      }
    }

    return matches
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
      .slice(0, 15);
  }, [allLeads, draft.country]);

  const handleSelectLocation = (s: LocationSuggestion) => {
    if (!draft.selectedLocations.includes(s.label)) {
      setDraft((prev) => ({
        ...prev,
        selectedLocations: [...prev.selectedLocations, s.label],
        locationQuery: '',
      }));
    }
    setLocationInput('');
    setIsLocationDropdownOpen(false);
  };

  const handleRemoveLocation = (loc: string) => {
    setDraft((prev) => ({
      ...prev,
      selectedLocations: prev.selectedLocations.filter((l) => l !== loc),
    }));
  };

  // Dynamically extract all unique industries directly from database leads
  const uniqueIndustriesWithCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const l of allLeads) {
      const ind = (l.industryType || '').trim();
      if (ind) {
        counts.set(ind, (counts.get(ind) || 0) + 1);
      }
    }
    return Array.from(counts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [allLeads]);

  // Dynamically extract all unique management levels directly from database leads (deduplicated & normalized)
  const uniqueManagementLevelsWithCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const l of allLeads) {
      let lvl = (l.managementLevel || l.jobLevel || '').trim();
      if (!lvl && l.jobTitle) {
        const t = l.jobTitle.toLowerCase();
        if (t.includes('director')) lvl = 'Director';
        else if (t.includes('manager')) lvl = 'Manager';
        else if (t.includes('vp') || t.includes('vice president')) lvl = 'VP';
        else if (t.includes('chief') || t.includes('ceo') || t.includes('cto') || t.includes('cfo')) lvl = 'C-Suite';
      }
      if (lvl) {
        const lower = lvl.toLowerCase();
        const normalized =
          lower === 'c suite' || lower === 'c-suite' || lower === 'c level' || lower === 'executive'
            ? 'C-Suite'
            : lower === 'vp' || lower === 'vice president'
            ? 'VP'
            : lower.includes('director')
            ? 'Director'
            : lower.includes('manager')
            ? 'Manager'
            : lower.includes('head')
            ? 'Head'
            : lower.includes('founder')
            ? 'Founder'
            : lower.includes('owner')
            ? 'Owner'
            : lower.includes('senior')
            ? 'Senior'
            : lvl.charAt(0).toUpperCase() + lvl.slice(1);
        counts.set(normalized, (counts.get(normalized) || 0) + 1);
      }
    }
    // Standard executive levels baseline if empty
    if (counts.size === 0) {
      ['Director', 'Manager', 'C-Suite', 'VP', 'Senior', 'Founder', 'Owner', 'Head', 'Entry-Level'].forEach((name) => {
        counts.set(name, 0);
      });
    }
    return Array.from(counts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [allLeads]);

  const filteredManagementLevels = useMemo(() => {
    if (!managementLevelSearch.trim()) return uniqueManagementLevelsWithCounts;
    const q = managementLevelSearch.toLowerCase().trim();
    return uniqueManagementLevelsWithCounts.filter((item) =>
      item.name.toLowerCase().includes(q)
    );
  }, [uniqueManagementLevelsWithCounts, managementLevelSearch]);

  // Dynamically extract and normalize job seniority levels
  const uniqueJobLevelsWithCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const opt of JOB_LEVEL_OPTIONS) {
      counts.set(opt, 0);
    }
    for (const l of allLeads) {
      const raw = (l.jobLevel || '').trim();
      if (raw) {
        let matched = false;
        for (const opt of JOB_LEVEL_OPTIONS) {
          if (
            opt.toLowerCase() === raw.toLowerCase() ||
            raw.toLowerCase().includes(opt.toLowerCase()) ||
            opt.toLowerCase().includes(raw.toLowerCase())
          ) {
            counts.set(opt, (counts.get(opt) || 0) + 1);
            matched = true;
            break;
          }
        }
        if (!matched) {
          counts.set(raw, (counts.get(raw) || 0) + 1);
        }
      }
    }
    return Array.from(counts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [allLeads]);

  const filteredJobLevels = useMemo(() => {
    if (!jobLevelSearch.trim()) return uniqueJobLevelsWithCounts;
    const q = jobLevelSearch.toLowerCase().trim();
    return uniqueJobLevelsWithCounts.filter((item) =>
      item.name.toLowerCase().includes(q)
    );
  }, [uniqueJobLevelsWithCounts, jobLevelSearch]);

  // Dynamically compute count of leads matching each employee size bracket
  const employeeSizeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const bracket of EMPLOYEE_SIZE_OPTIONS) {
      counts[bracket] = 0;
    }
    for (const lead of allLeads) {
      for (const bracket of EMPLOYEE_SIZE_OPTIONS) {
        if (matchesEmployeeSizeFilter(lead.employeeSize, [bracket])) {
          counts[bracket] = (counts[bracket] || 0) + 1;
        }
      }
    }
    return counts;
  }, [allLeads]);

  // Dynamically compute count of leads matching each revenue range
  const revenueRangeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const range of REVENUE_RANGE_OPTIONS) {
      counts[range] = 0;
    }
    for (const lead of allLeads) {
      for (const range of REVENUE_RANGE_OPTIONS) {
        if (matchesRevenueFilter(lead.revenueSize, [range])) {
          counts[range] = (counts[range] || 0) + 1;
        }
      }
    }
    return counts;
  }, [allLeads]);

  // Count active filter criteria accurately (Excluded contact personal fields)
  const activeCount = useMemo(() => {
    let count = 0;
    if (
      draft.addressSearch.trim() ||
      draft.selectedLocations.length > 0 ||
      draft.city.trim() ||
      draft.state.trim() ||
      draft.postalCode.trim() ||
      draft.country.trim()
    ) {
      count++;
    }
    if (draft.jobTitlePaste.trim()) count++;
    if (draft.managementLevels && draft.managementLevels.length > 0) count++;
    if (draft.jobLevels && draft.jobLevels.length > 0) count++;
    if (draft.companyNamePaste.trim()) count++;
    if (draft.companyDomainPaste.trim()) count++;
    if (draft.employeeSizes.length > 0) count++;
    if (draft.industries.length > 0) count++;
    if (draft.revenueRanges.length > 0) count++;
    if (draft.sicNaicsSearch.trim()) count++;
    return count;
  }, [draft]);

  const handleApply = () => {
    onApplyFilters(draft);
  };

  const handleReset = () => {
    setDraft(DEFAULT_SERIAL_FILTERS);
    setLocationInput('');
    onClearAll();
  };

  const toggleArrayItem = (
    key: 'employeeSizes' | 'industries' | 'revenueRanges' | 'managementLevels' | 'jobLevels',
    item: string
  ) => {
    setDraft((prev) => {
      const list = prev[key] || [];
      const next = list.includes(item) ? list.filter((x) => x !== item) : [...list, item];
      return { ...prev, [key]: next };
    });
  };

  return (
    <aside className="w-80 bg-white border-r border-slate-200/90 flex flex-col h-full shrink-0 select-none">
      {/* 1. Header Toolbar: Title, Active Count & Reset */}
      <div className="p-3.5 border-b border-slate-200/90 shrink-0 space-y-2.5 bg-slate-50/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-700" />
            <h2 className="text-xs font-bold text-slate-900 tracking-tight">
              Filters & Criteria
            </h2>
            {activeCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-md text-[10px] font-semibold bg-blue-100 text-blue-700 font-mono">
                {activeCount}
              </span>
            )}
          </div>

          {activeCount > 0 && (
            <button
              type="button"
              onClick={handleReset}
              className="text-[11px] font-medium text-slate-600 hover:text-rose-600 flex items-center gap-1 transition-colors cursor-pointer"
              title="Reset all criteria"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear All</span>
            </button>
          )}
        </div>

        {/* Primary Apply Filters Button */}
        <button
          type="button"
          onClick={handleApply}
          className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Filter className="w-3.5 h-3.5" />
          <span>Apply Filters</span>
          {activeCount > 0 && (
            <span className="px-1.5 py-0.2 rounded bg-blue-700 text-[10px] font-mono">
              {activeCount}
            </span>
          )}
        </button>
      </div>

      {/* Apollo-Style Direct DB Metrics Tabs */}
      <div className="grid grid-cols-3 gap-1.5 p-2.5 bg-slate-50/80 border-b border-slate-200 shrink-0">
        <div className="p-2 rounded-lg bg-white border border-slate-200/90 shadow-2xs text-center">
          <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block">Total</span>
          <span className="text-xs font-bold text-slate-900 font-mono mt-0.5 block truncate">
            {allLeads.length.toLocaleString()}
          </span>
        </div>
        <div className="p-2 rounded-lg bg-white border border-slate-200/90 shadow-2xs text-center">
          <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block">Net New</span>
          <span className="text-xs font-bold text-blue-600 font-mono mt-0.5 block truncate">
            {allLeads.length.toLocaleString()}
          </span>
        </div>
        <div className="p-2 rounded-lg bg-white border border-slate-200/90 shadow-2xs text-center">
          <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block">Filtered</span>
          <span className="text-xs font-bold text-emerald-600 font-mono mt-0.5 block truncate">
            {hasActiveFilter ? (filteredCount ?? 0).toLocaleString() : '0'}
          </span>
        </div>
      </div>

      {/* 2. Scrollable Filter Sections */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 text-xs">


        {/* ================= 3. Location (Autocomplete + Granular Fields) ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('location')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-blue-600" />
              <span>Location</span>
            </div>
            <div className="flex items-center gap-1.5">
              {(draft.selectedLocations.length > 0 ||
                draft.addressSearch.trim() ||
                draft.city.trim() ||
                draft.state.trim() ||
                draft.country.trim()) && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
              {openSections.location ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.location && (
            <div className="mt-2.5 space-y-2.5 pt-2 border-t border-slate-100">
              {/* Street / Address Input */}
              <div>
                <label className="text-[10px] font-medium text-slate-500 block mb-1">
                  Street / Address
                </label>
                <div className="relative">
                  <Navigation className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={draft.addressSearch}
                    onChange={(e) => setDraft({ ...draft, addressSearch: e.target.value })}
                    placeholder="Search street or building..."
                    className="w-full pl-8 pr-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden transition-colors"
                  />
                </div>
              </div>

              {/* City / Country Autocomplete from Database */}
              <div ref={locationDropdownRef} className="relative">
                <label className="text-[10px] font-medium text-slate-500 block mb-1">
                  City, State or Country (Database Autocomplete)
                </label>

                {/* Selected Location Chips */}
                {draft.selectedLocations.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {draft.selectedLocations.map((loc) => (
                      <span
                        key={loc}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-blue-50 text-blue-700 border border-blue-200"
                      >
                        <MapPin className="w-2.5 h-2.5 text-blue-600" />
                        <span className="max-w-[150px] truncate" title={loc}>
                          {loc}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveLocation(loc)}
                          className="hover:text-blue-900 rounded cursor-pointer"
                        >
                          <X className="w-2.5 h-2.5" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={locationInput}
                    onChange={(e) => {
                      setLocationInput(e.target.value);
                      setDraft({ ...draft, locationQuery: e.target.value });
                      setIsLocationDropdownOpen(true);
                    }}
                    onFocus={() => {
                      if (locationInput.trim()) setIsLocationDropdownOpen(true);
                    }}
                    placeholder="Type city, state, or country..."
                    className="w-full pl-8 pr-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden transition-colors"
                  />
                </div>

                {/* Suggestions Dropdown */}
                {isLocationDropdownOpen && locationSuggestions.length > 0 && (
                  <div className="absolute left-0 right-0 mt-1 bg-white rounded-lg border border-slate-200 shadow-lg py-1 z-50 max-h-48 overflow-y-auto">
                    <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100 bg-slate-50">
                      Locations in Database
                    </div>
                    {locationSuggestions.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => handleSelectLocation(s)}
                        className="w-full px-3 py-2 text-left hover:bg-blue-50/80 flex items-center justify-between text-xs transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2 min-w-0 mr-2">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="font-medium text-slate-800 truncate">
                            {s.label}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded shrink-0">
                          {s.count}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Granular Field Inputs */}
              <div className="pt-1 space-y-1.5">
                <span className="text-[10px] font-medium text-slate-500 block">
                  Granular Region Fields
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={draft.city}
                    onChange={(e) => setDraft({ ...draft, city: e.target.value })}
                    placeholder="City"
                    className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-md bg-slate-50 focus:bg-white focus:outline-hidden"
                  />
                  <input
                    type="text"
                    value={draft.state}
                    onChange={(e) => setDraft({ ...draft, state: e.target.value })}
                    placeholder="State / Region"
                    className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-md bg-slate-50 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={draft.postalCode}
                    onChange={(e) => setDraft({ ...draft, postalCode: e.target.value })}
                    placeholder="Postal / Zip Code"
                    className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-md bg-slate-50 focus:bg-white focus:outline-hidden"
                  />
                  <div className="relative" ref={countryDropdownRef}>
                    <div className="relative">
                      <input
                        type="text"
                        value={draft.country}
                        onFocus={() => setIsCountryDropdownOpen(true)}
                        onChange={(e) => {
                          setDraft({ ...draft, country: e.target.value });
                          setIsCountryDropdownOpen(true);
                        }}
                        placeholder="Country (all world)"
                        className="w-full pl-2 pr-6 py-1.5 text-xs border border-slate-200 rounded-md bg-slate-50 focus:bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 focus:outline-hidden transition-all placeholder:text-slate-400"
                      />
                      {draft.country ? (
                        <button
                          type="button"
                          onClick={() => {
                            setDraft({ ...draft, country: '' });
                            setIsCountryDropdownOpen(false);
                          }}
                          className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                          title="Clear country"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      ) : (
                        <Globe className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                      )}
                    </div>

                    {/* Dynamic Country Suggestions Dropdown */}
                    {isCountryDropdownOpen && countrySuggestions.length > 0 && (
                      <div className="absolute z-50 left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-52 overflow-y-auto divide-y divide-slate-100 backdrop-blur-sm animate-in fade-in duration-100">
                        <div className="px-2.5 py-1 text-[10px] font-semibold text-slate-400 bg-slate-50/90 uppercase tracking-wider flex items-center justify-between sticky top-0 backdrop-blur-xs z-10 border-b border-slate-100">
                          <span className="flex items-center gap-1">
                            <Globe className="w-2.5 h-2.5 text-blue-500" />
                            Countries
                          </span>
                          <span className="text-[9px] text-slate-400 font-mono">
                            {countrySuggestions.length} available
                          </span>
                        </div>
                        {countrySuggestions.map((item) => (
                          <button
                            key={item.name}
                            type="button"
                            onClick={() => {
                              setDraft({ ...draft, country: item.name });
                              setIsCountryDropdownOpen(false);
                            }}
                            className={`w-full px-2.5 py-1.5 text-left flex items-center justify-between text-xs transition-colors cursor-pointer group ${
                              (draft.country || '').toLowerCase() === item.name.toLowerCase()
                                ? 'bg-blue-50/90 text-blue-700 font-medium'
                                : 'hover:bg-slate-50 text-slate-700 hover:text-slate-900'
                            }`}
                          >
                            <span className="truncate pr-1 group-hover:translate-x-0.5 transition-transform">
                              {item.name}
                            </span>
                            {item.count > 0 ? (
                              <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 border border-emerald-100 px-1.5 py-0.2 rounded-full shrink-0 font-medium">
                                {item.count} lead{item.count !== 1 ? 's' : ''}
                              </span>
                            ) : (
                              <span className="text-[9px] text-slate-400 font-normal shrink-0">
                                Global
                              </span>
                            )}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>



        {/* ================= 6. Job Title ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('jobTitle')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Briefcase className="w-3.5 h-3.5 text-blue-600" />
              <span>Job Title</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.jobTitlePaste.trim() && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
              {openSections.jobTitle ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.jobTitle && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-medium">Mode:</span>
                <div className="inline-flex rounded-md bg-slate-100 p-0.5 border border-slate-200/80 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, jobTitleMode: 'include' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.jobTitleMode === 'include'
                        ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Include
                  </button>
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, jobTitleMode: 'exclude' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.jobTitleMode === 'exclude'
                        ? 'bg-white text-rose-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Exclude
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={draft.jobTitlePaste}
                onChange={(e) => setDraft({ ...draft, jobTitlePaste: e.target.value })}
                placeholder="Paste or type titles (e.g. CEO, Manager, Director)..."
                className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden resize-none"
              />
            </div>
          )}
        </div>

        {/* ================= 6B. Management Level ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('managementLevel')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-blue-600" />
              <span>Management Level</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.managementLevels && draft.managementLevels.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700">
                  {draft.managementLevels.length}
                </span>
              )}
              {openSections.managementLevel ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.managementLevel && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={managementLevelSearch}
                  onChange={(e) => setManagementLevelSearch(e.target.value)}
                  placeholder="Search management levels..."
                  className="w-full pl-8 pr-2.5 py-1 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden"
                />
              </div>

              <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                {filteredManagementLevels.length === 0 ? (
                  <div className="text-[11px] text-slate-400 py-2 text-center">
                    No matching levels in database
                  </div>
                ) : (
                  filteredManagementLevels.map(({ name, count }) => {
                    const isChecked = (draft.managementLevels || []).includes(name);
                    return (
                      <label
                        key={name}
                        className="flex items-center justify-between text-xs text-slate-700 hover:text-blue-600 cursor-pointer py-1 px-1.5 rounded hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-2 truncate pr-1">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleArrayItem('managementLevels', name)}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                          <span className="truncate">{name}</span>
                        </div>
                        {count > 0 && (
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded-full shrink-0">
                            {count.toLocaleString()}
                          </span>
                        )}
                      </label>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* ================= 6C. Job Seniority Level ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('jobLevel')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600" />
              <span>Job Seniority Level</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.jobLevels && draft.jobLevels.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700">
                  {draft.jobLevels.length}
                </span>
              )}
              {openSections.jobLevel ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.jobLevel && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={jobLevelSearch}
                  onChange={(e) => setJobLevelSearch(e.target.value)}
                  placeholder="Search seniority levels..."
                  className="w-full pl-8 pr-2.5 py-1 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-indigo-600 focus:outline-hidden"
                />
              </div>

              <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                {filteredJobLevels.length === 0 ? (
                  <div className="text-[11px] text-slate-400 py-2 text-center">
                    No matching levels found
                  </div>
                ) : (
                  filteredJobLevels.map(({ name, count }) => {
                    const isChecked = (draft.jobLevels || []).includes(name);
                    return (
                      <label
                        key={name}
                        className="flex items-center justify-between text-xs text-slate-700 hover:text-indigo-600 cursor-pointer py-1 px-1.5 rounded hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-2 truncate pr-1">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleArrayItem('jobLevels', name)}
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                          />
                          <span className="truncate">{name}</span>
                        </div>
                        {count > 0 && (
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded-full shrink-0">
                            {count.toLocaleString()}
                          </span>
                        )}
                      </label>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* ================= 7. Company Name ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('companyName')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Building className="w-3.5 h-3.5 text-blue-600" />
              <span>Company Name</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.companyNamePaste.trim() && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
              {openSections.companyName ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.companyName && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-medium">Mode:</span>
                <div className="inline-flex rounded-md bg-slate-100 p-0.5 border border-slate-200/80 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, companyNameMode: 'include' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.companyNameMode === 'include'
                        ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Include
                  </button>
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, companyNameMode: 'exclude' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.companyNameMode === 'exclude'
                        ? 'bg-white text-rose-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Exclude
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={draft.companyNamePaste}
                onChange={(e) => setDraft({ ...draft, companyNamePaste: e.target.value })}
                placeholder="Paste company names (Apple, Stripe, Microsoft)..."
                className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden resize-none"
              />
            </div>
          )}
        </div>

        {/* ================= 8. Company Domain ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('companyDomain')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>Company Domain</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.companyDomainPaste.trim() && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
              {openSections.companyDomain ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.companyDomain && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-medium">Mode:</span>
                <div className="inline-flex rounded-md bg-slate-100 p-0.5 border border-slate-200/80 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, companyDomainMode: 'include' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.companyDomainMode === 'include'
                        ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Include
                  </button>
                  <button
                    type="button"
                    onClick={() => setDraft({ ...draft, companyDomainMode: 'exclude' })}
                    className={`px-2.5 py-0.5 rounded cursor-pointer transition-colors ${
                      draft.companyDomainMode === 'exclude'
                        ? 'bg-white text-rose-700 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Exclude
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={draft.companyDomainPaste}
                onChange={(e) => setDraft({ ...draft, companyDomainPaste: e.target.value })}
                placeholder="Paste domains (stripe.com, google.com)..."
                className="w-full px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden resize-none"
              />
            </div>
          )}
        </div>

        {/* ================= 9. Employee Size Brackets ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('employeeSize')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              <span>Employee Size</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.employeeSizes.length > 0 && (
                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-100 text-blue-700 font-mono">
                  {draft.employeeSizes.length}
                </span>
              )}
              {openSections.employeeSize ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.employeeSize && (
            <div className="mt-2.5 space-y-1 pt-2 border-t border-slate-100 max-h-48 overflow-y-auto pr-1">
              {EMPLOYEE_SIZE_OPTIONS.map((range) => (
                <label
                  key={range}
                  className="flex items-center justify-between cursor-pointer hover:bg-slate-50 p-1.5 rounded transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={draft.employeeSizes.includes(range)}
                      onChange={() => toggleArrayItem('employeeSizes', range)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-slate-700">{range}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-500 font-mono">
                    {employeeSizeCounts[range] || 0}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        {/* ================= 10. Industry Type ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('industryType')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Factory className="w-3.5 h-3.5 text-blue-600" />
              <span>Industry Type</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.industries.length > 0 && (
                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-100 text-blue-700 font-mono">
                  {draft.industries.length}
                </span>
              )}
              {openSections.industryType ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.industryType && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="relative">
                <Search className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={industrySearch}
                  onChange={(e) => setIndustrySearch(e.target.value)}
                  placeholder="Filter industries..."
                  className="w-full pl-7 pr-2 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                {uniqueIndustriesWithCounts
                  .filter(({ name }) => name.toLowerCase().includes(industrySearch.toLowerCase()))
                  .map(({ name, count }) => (
                    <label
                      key={name}
                      className="flex items-center justify-between cursor-pointer hover:bg-slate-50 p-1.5 rounded transition-colors"
                      title={name}
                    >
                      <div className="flex items-center gap-2 min-w-0 pr-2">
                        <input
                          type="checkbox"
                          checked={draft.industries.includes(name)}
                          onChange={() => toggleArrayItem('industries', name)}
                          className="rounded text-blue-600 focus:ring-blue-500 shrink-0"
                        />
                        <span className="text-slate-700 truncate">{name}</span>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-500 font-mono shrink-0">
                        {count}
                      </span>
                    </label>
                  ))}
                {uniqueIndustriesWithCounts.length === 0 && (
                  <p className="text-xs text-slate-400 p-2 italic text-center">
                    No industries in database
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ================= 11. Revenue Range ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('revenueRange')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <DollarSign className="w-3.5 h-3.5 text-blue-600" />
              <span>Revenue Range</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.revenueRanges.length > 0 && (
                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-100 text-blue-700 font-mono">
                  {draft.revenueRanges.length}
                </span>
              )}
              {openSections.revenueRange ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.revenueRange && (
            <div className="mt-2.5 space-y-1 pt-2 border-t border-slate-100 max-h-48 overflow-y-auto pr-1">
              {REVENUE_RANGE_OPTIONS.map((rev) => (
                <label
                  key={rev}
                  className="flex items-center justify-between cursor-pointer hover:bg-slate-50 p-1.5 rounded transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={draft.revenueRanges.includes(rev)}
                      onChange={() => toggleArrayItem('revenueRanges', rev)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-slate-700">{rev}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-500 font-mono">
                    {revenueRangeCounts[rev] || 0}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        {/* ================= 12. SIC & NAICS Code Search ================= */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => toggleSection('sicNaics')}
            className="w-full flex items-center justify-between font-semibold text-slate-800 hover:text-blue-600 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Hash className="w-3.5 h-3.5 text-blue-600" />
              <span>SIC & NAICS Codes</span>
            </div>
            <div className="flex items-center gap-1.5">
              {draft.sicNaicsSearch.trim() && (
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              )}
              {openSections.sicNaics ? (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
          </button>

          {openSections.sicNaics && (
            <div className="mt-2.5 space-y-2 pt-2 border-t border-slate-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={draft.sicNaicsSearch}
                  onChange={(e) => setDraft({ ...draft, sicNaicsSearch: e.target.value })}
                  placeholder="Search code (e.g. 7371, 541511)..."
                  className="w-full pl-8 pr-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden transition-colors"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Sticky Bottom Action Bar with Apply and Clear/Hide Buttons (Apollo-style) */}
      <div className="p-3 bg-slate-50/90 border-t border-slate-200/90 shrink-0 space-y-2">
        <button
          type="button"
          onClick={handleApply}
          className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <Filter className="w-3.5 h-3.5" />
          <span>Apply Filters {activeCount > 0 ? `(${activeCount})` : ''}</span>
        </button>

        <div className="flex items-center justify-between text-xs pt-1 px-1 text-slate-500">
          <button
            type="button"
            onClick={handleReset}
            className="hover:text-rose-600 transition-colors cursor-pointer flex items-center gap-1 font-medium"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Clear all</span>
          </button>
          {onToggleFilters && (
            <button
              type="button"
              onClick={onToggleFilters}
              className="hover:text-blue-600 transition-colors cursor-pointer flex items-center gap-1 font-medium"
            >
              <span>Collapse sidebar</span>
              <ChevronRight className="w-3 h-3 rotate-180" />
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Download,
  X,
  Target,
  FileSpreadsheet,
  ShieldCheck,
  Filter,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { EnterpriseUser } from '../../types/enterprise';

export interface CampaignExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordsCount: number;
  activeFilterSummary?: string;
  currentUser: EnterpriseUser | null;
  onConfirmExport: (params: {
    campaignName: string;
    notes?: string;
    format: 'CSV' | 'EXCEL';
  }) => Promise<void> | void;
  isExporting?: boolean;
}

export const CampaignExportModal: React.FC<CampaignExportModalProps> = ({
  isOpen,
  onClose,
  recordsCount,
  activeFilterSummary,
  currentUser,
  onConfirmExport,
  isExporting = false,
}) => {
  const [campaignName, setCampaignName] = useState('');
  const [notes, setNotes] = useState('');
  const [format, setFormat] = useState<'CSV' | 'EXCEL'>('CSV');
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setCampaignName('');
      setNotes('');
      setFormat('CSV');
      setValidationError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = campaignName.trim();
    if (!trimmed) {
      setValidationError('Please enter a Campaign Name before exporting.');
      return;
    }
    setValidationError(null);
    await onConfirmExport({
      campaignName: trimmed,
      notes: notes.trim() || undefined,
      format,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.35)] w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="campaign-export-title"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800/80 bg-linear-to-r from-slate-50 via-white to-blue-50/40 dark:from-slate-900 dark:via-slate-900 dark:to-blue-950/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-200/50 dark:border-blue-500/30 shadow-xs">
              <Target className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-full border border-blue-200/60 dark:border-blue-900">
                  Alltake Data Core
                </span>
                <span className="text-[10px] text-slate-400">· Export Gateway</span>
              </div>
              <h2
                id="campaign-export-title"
                className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-tight mt-0.5"
              >
                Campaign Export Verification
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isExporting}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {/* Scope Overview Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between shadow-2xs">
            <div className="space-y-0.5">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Total Download Volume
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900 dark:text-white font-mono">
                  {recordsCount.toLocaleString()}
                </span>
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Verified Leads
                </span>
              </div>
              {activeFilterSummary && (
                <div className="flex items-center gap-1 text-[11px] text-slate-600 dark:text-slate-300 font-mono truncate max-w-xs pt-0.5">
                  <Filter className="w-3 h-3 text-blue-500 shrink-0" />
                  <span className="truncate">{activeFilterSummary}</span>
                </div>
              )}
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">User Access</span>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block truncate max-w-[150px]">
                {currentUser?.full_name || 'User'}
              </span>
              <span className="inline-block mt-0.5 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200">
                {currentUser?.role || 'EMPLOYEE'}
              </span>
            </div>
          </div>

          {/* Validation Alert */}
          {validationError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div>
                <span className="font-semibold block">Campaign Name Required</span>
                <span className="text-[11px]">{validationError}</span>
              </div>
            </div>
          )}

          {/* Dedicated Campaign Name Input (Clean & Focused - No Preset Chips) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="campaign-name-input"
                className="block text-xs font-bold text-slate-900 dark:text-slate-100"
              >
                Campaign Name <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-slate-400 font-medium">Included in Admin Email Alert</span>
            </div>

            <div className="relative">
              <Target className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="campaign-name-input"
                type="text"
                required
                autoFocus
                disabled={isExporting}
                value={campaignName}
                onChange={(e) => {
                  setCampaignName(e.target.value);
                  if (validationError) setValidationError(null);
                }}
                placeholder="Enter campaign name here..."
                className="w-full pl-10 pr-3 py-3 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:bg-white dark:focus:bg-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all font-semibold shadow-2xs"
              />
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Type the exact campaign or project name for tracking and regulatory compliance.
            </p>
          </div>

          {/* Campaign Purpose / Notes (Optional) */}
          <div className="space-y-1">
            <label
              htmlFor="campaign-notes-input"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
            >
              Campaign Purpose / Notes <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              id="campaign-notes-input"
              type="text"
              disabled={isExporting}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Outreach sequence for regional directors"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:bg-white dark:focus:bg-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all"
            />
          </div>

          {/* Export File Format */}
          <div className="space-y-1.5 pt-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              File Format
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormat('CSV')}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  format === 'CSV'
                    ? 'border-blue-600 bg-blue-50/80 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                <span>CSV Format (.csv)</span>
              </button>

              <button
                type="button"
                onClick={() => setFormat('EXCEL')}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  format === 'EXCEL'
                    ? 'border-emerald-600 bg-emerald-50/80 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Excel Spreadsheet (.csv)</span>
              </button>
            </div>
          </div>

          {/* Security & Admin Alert Notice */}
          <div className="p-3 rounded-xl bg-blue-50/60 dark:bg-blue-950/40 border border-blue-200/60 dark:border-blue-900/60 flex items-start gap-2 text-[11px] text-blue-900 dark:text-blue-200">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              An automated notification with this <strong>Campaign Name</strong> and download details will be dispatched immediately to the administrator via Resend.
            </p>
          </div>

          {/* Modal Actions */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isExporting}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-linear-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-800 active:scale-[0.98] rounded-xl shadow-md hover:shadow-lg transition-all duration-150 disabled:opacity-50 cursor-pointer"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Exporting & Dispatching Alert...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-white" />
                  <span>Confirm & Export {recordsCount.toLocaleString()} Leads</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

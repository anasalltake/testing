import React, { useState } from 'react';
import { X, Clipboard, CheckCircle2, Ban, Plus } from 'lucide-react';
import { EnterpriseColumnDef } from '../../types/enterprise';

interface BulkPasteModalProps {
  isOpen: boolean;
  onClose: () => void;
  columns: { key: string; label: string }[];
  activeColumnKey?: string;
  onApplyPaste: (columnKey: string, values: string[], mode: 'include' | 'exclude') => void;
}

export const BulkPasteModal: React.FC<BulkPasteModalProps> = ({
  isOpen,
  onClose,
  columns,
  activeColumnKey = 'jobTitle',
  onApplyPaste,
}) => {
  const [selectedColumnKey, setSelectedColumnKey] = useState<string>(activeColumnKey);
  const [mode, setMode] = useState<'include' | 'exclude'>('include');
  const [pasteText, setPasteText] = useState<string>('');

  if (!isOpen) return null;

  const parsedValues = pasteText
    .split(/[\n,;]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const distinctValues = Array.from(new Set(parsedValues));

  const handleApply = () => {
    if (distinctValues.length === 0) return;
    onApplyPaste(selectedColumnKey, distinctValues, mode);
    setPasteText('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-blue-50/50 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Clipboard className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Direct Bulk Paste Filter
              </h3>
              <p className="text-xs text-slate-500">
                Paste lists of values to apply bulk Include or Exclude rules
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Target Attribute / Heading Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Filter Target Heading / Column
            </label>
            <select
              value={selectedColumnKey}
              onChange={(e) => setSelectedColumnKey(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white text-slate-800 font-medium focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
            >
              {columns.map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label} ({c.key})
                </option>
              ))}
            </select>
          </div>

          {/* Mode Selector: Include vs Exclude */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Filter Action Mode
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setMode('include')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'include'
                    ? 'bg-blue-50 border-blue-600 text-blue-700 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>INCLUDE (Must Match)</span>
              </button>

              <button
                type="button"
                onClick={() => setMode('exclude')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'exclude'
                    ? 'bg-rose-50 border-rose-600 text-rose-700 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Ban className="w-4 h-4 text-rose-600" />
                <span>EXCLUDE (Filter Out)</span>
              </button>
            </div>
          </div>

          {/* Paste Textarea */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                Paste Values (separated by newline, comma, or tab)
              </label>
              <span className="text-[11px] font-mono text-slate-500">
                {distinctValues.length} distinct detected
              </span>
            </div>

            <textarea
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              placeholder="e.g.&#10;Life Coach & Strategic Advisor&#10;Founder & CEO&#10;President & Board Member&#10;United States"
              rows={6}
              className="w-full p-3 text-xs font-mono border border-slate-300 rounded-xl bg-slate-50 focus:bg-white text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
            />
          </div>

          {/* Quick value preview tag badges */}
          {distinctValues.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Parsed Values Preview ({distinctValues.length})
              </span>
              <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto p-2 border border-slate-200 rounded-lg bg-slate-50">
                {distinctValues.slice(0, 15).map((val) => (
                  <span
                    key={val}
                    className={`px-2 py-0.5 rounded text-[10px] font-medium font-mono ${
                      mode === 'include'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-rose-100 text-rose-800 line-through'
                    }`}
                  >
                    {val}
                  </span>
                ))}
                {distinctValues.length > 15 && (
                  <span className="text-[10px] text-slate-400 font-mono self-center">
                    +{distinctValues.length - 15} more
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-800 rounded-lg cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleApply}
            disabled={distinctValues.length === 0}
            className={`px-5 py-2 text-xs font-bold text-white rounded-lg shadow-xs disabled:opacity-50 transition-colors flex items-center gap-1.5 cursor-pointer ${
              mode === 'include'
                ? 'bg-blue-600 hover:bg-blue-700'
                : 'bg-rose-600 hover:bg-rose-700'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>
              Apply {mode === 'include' ? 'Include' : 'Exclude'} ({distinctValues.length})
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

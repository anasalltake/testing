import React from 'react';
import {
  Search,
  Users,
  Send,
  Mail,
  Phone,
  BarChart2,
  Workflow,
  Settings,
  Sparkles,
  HelpCircle,
  FolderOpen
} from 'lucide-react';

interface LeftIconBarProps {
  onOpenUpload: () => void;
}

export const LeftIconBar: React.FC<LeftIconBarProps> = ({ onOpenUpload }) => {
  return (
    <aside className="w-12 shrink-0 bg-[#0e131f] flex flex-col items-center justify-between py-3 select-none z-30 border-r border-[#1e2638]">
      {/* Top Icons */}
      <div className="flex flex-col items-center gap-4 w-full">
        {/* Apollo Logo Star */}
        <div
          className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-400 flex items-center justify-center text-white shadow-md cursor-pointer hover:opacity-90 transition-opacity"
          title="Apollo Lead Intelligence"
        >
          <Sparkles className="w-4 h-4 fill-white" />
        </div>

        <div className="w-6 h-[1px] bg-slate-800 my-1" />

        {/* Primary Search / People (Active in Apollo) */}
        <button
          className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-sm transition-transform active:scale-95"
          title="Search People & Companies"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Contact Lists */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Lists & Saved Searches"
        >
          <Users className="w-4 h-4" />
        </button>

        {/* Sequences / Campaigns */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Sequences"
        >
          <Send className="w-4 h-4" />
        </button>

        {/* Emails */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Emails"
        >
          <Mail className="w-4 h-4" />
        </button>

        {/* Calls / Phone */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Calls & Phone"
        >
          <Phone className="w-4 h-4" />
        </button>

        {/* Analytics */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Analytics & Reports"
        >
          <BarChart2 className="w-4 h-4" />
        </button>

        {/* Workflows / Automation */}
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Workflows"
        >
          <Workflow className="w-4 h-4" />
        </button>

        {/* Direct CSV Upload Trigger */}
        <button
          onClick={onOpenUpload}
          className="w-8 h-8 rounded-lg text-amber-400 hover:text-amber-300 hover:bg-amber-950/40 flex items-center justify-center transition-colors border border-amber-500/20"
          title="Upload CSV / Datasets"
        >
          <FolderOpen className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom Icons */}
      <div className="flex flex-col items-center gap-3 w-full">
        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Help & Documentation"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        <button
          className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 flex items-center justify-center transition-colors"
          title="Settings"
        >
          <Settings className="w-4 h-4" />
        </button>

        {/* User Avatar */}
        <div
          className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-semibold shadow-inner cursor-pointer hover:ring-2 hover:ring-blue-400 transition-all"
          title="User Account"
        >
          ST
        </div>
      </div>
    </aside>
  );
};

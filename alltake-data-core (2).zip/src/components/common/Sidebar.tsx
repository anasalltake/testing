import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import {
  LayoutDashboard,
  TableProperties,
  Globe2,
  UploadCloud,
  Download,
  Users,
  ShieldAlert,
  History,
  FolderGit2,
  Server,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export type NavigationTab =
  | 'dashboard'
  | 'data-explorer'
  | 'datasets'
  | 'country-analytics'
  | 'uploads'
  | 'downloads'
  | 'users'
  | 'audit-logs'
  | 'login-logs'
  | 'system-health';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavItem {
  id: NavigationTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  allowedRoles: string[];
}

interface NavSection {
  title?: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
}) => {
  const { user } = useAuth();
  const role = user?.role;

  const sections: NavSection[] = [
    {
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard',
          icon: LayoutDashboard,
          allowedRoles: ['ADMIN', 'DATA_MANAGER', 'EMPLOYEE'],
        },
      ],
    },
    {
      title: 'DATA',
      items: [
        {
          id: 'data-explorer',
          label: 'Data Explorer',
          icon: TableProperties,
          allowedRoles: ['ADMIN', 'DATA_MANAGER', 'EMPLOYEE'],
        },
        {
          id: 'uploads',
          label: 'Upload Data',
          icon: UploadCloud,
          allowedRoles: ['ADMIN', 'DATA_MANAGER'],
        },
      ],
    },
    {
      title: 'ANALYTICS',
      items: [
        {
          id: 'country-analytics',
          label: 'Countries',
          icon: Globe2,
          allowedRoles: ['ADMIN', 'EMPLOYEE'],
        },
      ],
    },
    {
      title: 'ACTIVITY',
      items: [
        {
          id: 'downloads',
          label: 'Download History',
          icon: Download,
          allowedRoles: ['ADMIN', 'DATA_MANAGER', 'EMPLOYEE'],
        },
        {
          id: 'audit-logs',
          label: 'Audit Logs',
          icon: ShieldAlert,
          allowedRoles: ['ADMIN'],
        },
        {
          id: 'login-logs',
          label: 'Security Logs',
          icon: History,
          allowedRoles: ['ADMIN'],
        },
      ],
    },
    {
      title: 'ADMIN',
      items: [
        {
          id: 'users',
          label: 'Users & Roles',
          icon: Users,
          allowedRoles: ['ADMIN'],
        },
        {
          id: 'system-health',
          label: 'System & DB',
          icon: Server,
          allowedRoles: ['ADMIN'],
        },
      ],
    },
  ];

  return (
    <aside
      className={`h-[calc(100vh-3.5rem)] bg-white border-r border-slate-200/80 transition-all duration-200 flex flex-col justify-between select-none ${
        isCollapsed ? 'w-16' : 'w-56'
      }`}
    >
      <div className="py-3 overflow-y-auto">
        {sections.map((section, sIdx) => {
          const visibleItems = section.items.filter((item) => role && item.allowedRoles.includes(role));
          if (visibleItems.length === 0) return null;

          return (
            <div key={sIdx} className="mb-4">
              {section.title && !isCollapsed && (
                <div className="px-4 mb-1.5">
                  <span className="text-[10px] font-semibold text-slate-400 tracking-wider uppercase font-mono">
                    {section.title}
                  </span>
                </div>
              )}

              <nav className="space-y-0.5 px-2">
                {visibleItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => onSelectTab(item.id)}
                      title={isCollapsed ? item.label : undefined}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 font-semibold shadow-2xs border border-blue-200/60'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                      } ${isCollapsed ? 'justify-center px-0' : ''}`}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'
                        }`}
                      />
                      {!isCollapsed && <span className="truncate tracking-tight">{item.label}</span>}
                    </button>
                  );
                })}
              </nav>
            </div>
          );
        })}
      </div>

      {/* Collapse button */}
      <div className="p-2 border-t border-slate-100 bg-slate-50/50">
        <button
          onClick={onToggleCollapse}
          className="w-full flex items-center justify-center p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          {!isCollapsed && <span className="text-[11px] ml-1.5 font-medium text-slate-500">Collapse</span>}
        </button>
      </div>
    </aside>
  );
};

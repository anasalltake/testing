import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole } from '../../types';
import {
  Database,
  Shield,
  LogOut,
  ChevronDown,
  KeyRound,
  Bell,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { Badge } from './Badge';

interface NavbarProps {
  onOpenChangePassword?: () => void;
  onGlobalSearch?: (term: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenChangePassword, onGlobalSearch }) => {
  const { user, logout, switchDemoRole } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const getRoleContextLabel = (role?: UserRole) => {
    switch (role) {
      case 'ADMIN':
        return 'Executive Administration';
      case 'DATA_MANAGER':
        return 'Data Ingestion Operations';
      case 'EMPLOYEE':
        return 'Lead Analytics Workspace';
      default:
        return 'Data Management';
    }
  };

  const getRoleBadgeVariant = (role?: UserRole) => {
    switch (role) {
      case 'ADMIN':
        return 'danger';
      case 'DATA_MANAGER':
        return 'primary';
      case 'EMPLOYEE':
        return 'success';
      default:
        return 'default';
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onGlobalSearch && searchTerm) {
      onGlobalSearch(searchTerm);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-slate-200/90 shadow-2xs">
      <div className="flex items-center justify-between h-14 px-4 sm:px-6">
        {/* Left: Brand + Context Header */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-xs">
              <Database className="w-4 h-4" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="font-extrabold tracking-wider text-base text-slate-900 font-mono">
                ALLTAKE
              </span>
              <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">
                / {getRoleContextLabel(user?.role)}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Search input */}
        <div className="hidden md:flex flex-1 max-w-md mx-6">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Quick search records across datasets..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:ring-1 focus:ring-blue-600 focus:border-blue-600 transition-colors"
            />
          </form>
        </div>

        {/* Right: Telemetry, Quick Role Switcher, Profile */}
        <div className="flex items-center gap-3">
          {/* Quick RBAC Role Switcher */}
          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-medium bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-slate-700 rounded-md transition-colors"
              title="Switch user role to test access boundaries"
            >
              <Shield className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden lg:inline text-slate-500">Role:</span>
              <span className="font-bold text-slate-900">{user?.role}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {isRoleDropdownOpen && (
              <div
                className="absolute right-0 mt-1.5 w-60 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-50 animate-in fade-in duration-100"
                onMouseLeave={() => setIsRoleDropdownOpen(false)}
              >
                <div className="px-3 py-1.5 border-b border-slate-100 bg-slate-50/50">
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider font-mono">
                    Switch Security Context
                  </p>
                  <p className="text-[10px] text-slate-500">Instant RBAC boundary testing</p>
                </div>

                <button
                  onClick={() => {
                    switchDemoRole('ADMIN');
                    setIsRoleDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                    user?.role === 'ADMIN' ? 'bg-blue-50/60 font-semibold' : ''
                  }`}
                >
                  <div>
                    <span className="text-slate-900 font-medium block">Executive Admin</span>
                    <span className="text-[10px] text-slate-400 font-mono">admin@alltake.com</span>
                  </div>
                  <Badge variant="danger" size="sm">ADMIN</Badge>
                </button>

                <button
                  onClick={() => {
                    switchDemoRole('DATA_MANAGER');
                    setIsRoleDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                    user?.role === 'DATA_MANAGER' ? 'bg-blue-50/60 font-semibold' : ''
                  }`}
                >
                  <div>
                    <span className="text-slate-900 font-medium block">Data Manager</span>
                    <span className="text-[10px] text-slate-400 font-mono">manager@alltake.com</span>
                  </div>
                  <Badge variant="primary" size="sm">MANAGER</Badge>
                </button>

                <button
                  onClick={() => {
                    switchDemoRole('EMPLOYEE');
                    setIsRoleDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                    user?.role === 'EMPLOYEE' ? 'bg-blue-50/60 font-semibold' : ''
                  }`}
                >
                  <div>
                    <span className="text-slate-900 font-medium block">Sales Employee</span>
                    <span className="text-[10px] text-slate-400 font-mono">employee@alltake.com</span>
                  </div>
                  <Badge variant="success" size="sm">EMPLOYEE</Badge>
                </button>
              </div>
            )}
          </div>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-md hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
            >
              <div className="w-6 h-6 rounded-md bg-blue-600 text-white flex items-center justify-center text-xs font-semibold font-mono">
                {user?.full_name?.charAt(0) || 'U'}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-medium leading-none text-slate-800">{user?.full_name}</span>
                <span className="text-[10px] text-slate-400 font-mono leading-tight mt-0.5">{user?.role}</span>
              </div>
              <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>

            {isMenuOpen && (
              <div
                className="absolute right-0 mt-1.5 w-52 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-50 animate-in fade-in duration-100"
                onMouseLeave={() => setIsMenuOpen(false)}
              >
                <div className="px-3 py-2 border-b border-slate-100 bg-slate-50/50">
                  <p className="text-xs font-semibold text-slate-900 truncate">{user?.full_name}</p>
                  <p className="text-[11px] text-slate-500 font-mono truncate">{user?.email}</p>
                  <div className="mt-1.5">
                    <Badge variant={getRoleBadgeVariant(user?.role)} size="sm">
                      {user?.role}
                    </Badge>
                  </div>
                </div>

                {onOpenChangePassword && (
                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenChangePassword();
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                    Change Password
                  </button>
                )}

                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    logout();
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 border-t border-slate-100"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

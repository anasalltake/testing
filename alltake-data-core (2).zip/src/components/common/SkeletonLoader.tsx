import React from 'react';

export const CardSkeleton: React.FC<{ count?: number }> = ({ count = 4 }) => {
  return (
    <div className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-${count} gap-3`}>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="bg-white rounded-lg border border-slate-200/80 p-4 shadow-2xs animate-pulse"
        >
          <div className="flex items-center justify-between">
            <div className="h-3 w-20 bg-slate-200 rounded" />
            <div className="h-7 w-7 bg-slate-100 rounded-md" />
          </div>
          <div className="mt-3 h-6 w-24 bg-slate-200 rounded" />
          <div className="mt-2 h-2.5 w-16 bg-slate-100 rounded" />
        </div>
      ))}
    </div>
  );
};

export const TableSkeleton: React.FC<{ rows?: number; columns?: number }> = ({
  rows = 8,
  columns = 6,
}) => {
  return (
    <div className="w-full bg-white rounded-lg border border-slate-200/80 overflow-hidden shadow-2xs">
      <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="h-4 w-32 bg-slate-200 rounded animate-pulse" />
        <div className="h-6 w-20 bg-slate-200 rounded animate-pulse" />
      </div>
      <div className="divide-y divide-slate-100">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex items-center px-4 py-2.5 gap-4 animate-pulse">
            {Array.from({ length: columns }).map((_, c) => (
              <div
                key={c}
                className="h-3 bg-slate-200/70 rounded"
                style={{ width: `${Math.max(40, (c * 23) % 90 + 30)}px` }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export const ChartSkeleton: React.FC = () => {
  return (
    <div className="bg-white p-5 rounded-lg border border-slate-200/80 shadow-2xs animate-pulse">
      <div className="flex items-center justify-between mb-4">
        <div className="h-4 w-40 bg-slate-200 rounded" />
        <div className="h-4 w-16 bg-slate-100 rounded" />
      </div>
      <div className="h-56 flex items-end gap-3 pt-6 px-2">
        {[40, 75, 55, 90, 65, 80, 45, 70].map((h, i) => (
          <div
            key={i}
            className="flex-1 bg-slate-100 rounded-t"
            style={{ height: `${h}%` }}
          />
        ))}
      </div>
    </div>
  );
};

import React from 'react';

export const LoadingSpinner: React.FC<{ size?: 'sm' | 'md' | 'lg'; text?: string }> = ({
  size = 'md',
  text,
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4 border-2',
    md: 'w-6 h-6 border-2',
    lg: 'w-8 h-8 border-3',
  }[size];

  return (
    <div className="flex items-center justify-center gap-2.5 p-6">
      <div
        className={`${sizeClasses} border-slate-300 border-t-blue-600 rounded-full animate-spin`}
      />
      {text && <span className="text-xs text-slate-500 font-medium">{text}</span>}
    </div>
  );
};

import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: string;
  trendPositive?: boolean;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendPositive,
}) => {
  return (
    <div className="bg-white rounded-lg border border-slate-200/90 p-3.5 shadow-2xs hover:border-slate-300 transition-colors">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider font-mono">
          {title}
        </span>
        {Icon && (
          <div className="w-7 h-7 rounded bg-slate-50 border border-slate-200/60 flex items-center justify-center text-slate-600 shrink-0">
            <Icon className="w-3.5 h-3.5" />
          </div>
        )}
      </div>

      <div className="mt-2 flex items-baseline justify-between gap-2">
        <span className="text-xl font-bold text-slate-900 font-mono tracking-tight">
          {typeof value === 'number' ? value.toLocaleString() : value}
        </span>
        {trend && (
          <span
            className={`text-[11px] font-mono font-medium ${
              trendPositive ? 'text-emerald-700' : 'text-slate-500'
            }`}
          >
            {trend}
          </span>
        )}
      </div>

      {subtitle && (
        <p className="mt-1 text-[11px] text-slate-400 font-sans truncate">{subtitle}</p>
      )}
    </div>
  );
};

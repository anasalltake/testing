import React, { useState } from 'react';

interface DmsLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'icon';
  layout?: 'horizontal' | 'vertical' | 'center';
  className?: string;
  light?: boolean;
}

export const DmsLogo: React.FC<DmsLogoProps> = ({
  size = 'md',
  variant = 'full',
  layout = 'horizontal',
  className = '',
  light = false,
}) => {
  const [imageError, setImageError] = useState(false);

  const dimensions = {
    sm: { icon: 28, title: 'text-xs', sub: 'text-[9px]', badge: 'text-[9px] px-1 py-0.2' },
    md: { icon: 34, title: 'text-sm', sub: 'text-[10px]', badge: 'text-[10px] px-1.5 py-0.5' },
    lg: { icon: 46, title: 'text-lg', sub: 'text-xs', badge: 'text-xs px-2 py-0.5' },
    xl: { icon: 72, title: 'text-2xl', sub: 'text-xs', badge: 'text-xs px-2.5 py-1' },
  }[size];

  const iconEmblem = (
    <div
      className="relative flex items-center justify-center shrink-0"
      style={{ width: dimensions.icon, height: dimensions.icon }}
    >
      {!imageError ? (
        <img
          src="/alltake-icon.png"
          alt="Alltake"
          className="w-full h-full object-contain select-none drop-shadow-xs"
          onError={() => setImageError(true)}
        />
      ) : (
        <div className="w-full h-full rounded-xl bg-gradient-to-tr from-blue-700 to-blue-500 flex items-center justify-center text-white font-black text-xl shadow-xs">
          a
        </div>
      )}
    </div>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center ${className}`}>{iconEmblem}</div>;
  }

  const isVertical = layout === 'vertical' || layout === 'center';

  return (
    <div
      className={`inline-flex ${
        isVertical ? 'flex-col items-center text-center gap-2.5' : 'items-center gap-3 text-left'
      } select-none ${className}`}
    >
      {iconEmblem}
      <div className={`flex flex-col ${isVertical ? 'items-center' : 'items-start'} leading-tight`}>
        <div className="flex items-center gap-1.5">
          <span
            className={`font-black tracking-tight ${dimensions.title} ${
              light ? 'text-white' : 'text-slate-900'
            }`}
          >
            ALLTAKE
          </span>
          <span
            className={`font-bold tracking-wider rounded-md bg-linear-to-r from-blue-600 to-indigo-600 text-white shadow-2xs ${dimensions.badge}`}
          >
            DATA CORE
          </span>
        </div>
        <span
          className={`font-medium tracking-wide ${dimensions.sub} ${
            light ? 'text-slate-300' : 'text-slate-500'
          }`}
        >
          Alltake Data Core Software
        </span>
      </div>
    </div>
  );
};

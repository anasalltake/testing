import React, { useState, useEffect } from 'react';
import {
  Download,
  CheckCircle2,
  Clock,
  XCircle,
  FileSpreadsheet,
  Megaphone,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Search,
  AlertCircle,
  ChevronRight,
  Calendar,
  Layers,
  Lock
} from 'lucide-react';
import { ExportApprovalRequest } from '../../types/enterprise';

interface EmployeeApprovedExportsProps {
  onNavigateToExplorer: () => void;
  onNotify?: (msg: string) => void;
  userRole?: string;
  userEmail?: string;
}

export const EmployeeApprovedExports: React.FC<EmployeeApprovedExportsProps> = ({
  onNavigateToExplorer,
  onNotify,
  userRole = 'EMPLOYEE',
  userEmail = 'employee@alltake.com',
}) => {
  const [requests, setRequests] = useState<ExportApprovalRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [filterTab, setFilterTab] = useState<'all' | 'approved' | 'pending' | 'rejected'>('approved');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchRequests = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
      const res = await fetch('/api/exports/requests', {
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.requests)) {
        setRequests(data.requests);
      }
    } catch (err) {
      console.error('Failed to load export requests:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleDownload = async (req: ExportApprovalRequest) => {
    setDownloadingId(req.id);
    try {
      const token = localStorage.getItem('alltake_auth_token') || sessionStorage.getItem('alltake_auth_token');
      const res = await fetch(`/api/exports/download-approved/${req.id}`, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || `Download failed with HTTP ${res.status}`);
      }

      // Convert response stream to Blob and trigger browser download
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const cleanCampaign = (req.campaign_name || 'Campaign').replace(/[^a-zA-Z0-9_-]/g, '_');
      link.setAttribute('download', `Alltake_${cleanCampaign}_${req.requested_count}_leads.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      onNotify?.(`Downloaded approved dataset for "${req.campaign_name || 'Campaign'}".`);
      // Refresh list to update status to DOWNLOADED
      fetchRequests();
    } catch (err: any) {
      onNotify?.(err.message || 'Failed to download approved export batch');
    } finally {
      setDownloadingId(null);
    }
  };

  const filteredRequests = requests.filter((r) => {
    // Filter by tab
    if (filterTab === 'approved' && r.status !== 'APPROVED' && r.status !== 'DOWNLOADED') return false;
    if (filterTab === 'pending' && r.status !== 'PENDING') return false;
    if (filterTab === 'rejected' && r.status !== 'REJECTED') return false;

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const matchCampaign = (r.campaign_name || '').toLowerCase().includes(query);
      const matchReason = (r.reason || '').toLowerCase().includes(query);
      const matchNote = (r.admin_note || '').toLowerCase().includes(query);
      const matchUser = (r.user_name || '').toLowerCase().includes(query);
      return matchCampaign || matchReason || matchNote || matchUser;
    }
    return true;
  });

  const approvedCount = requests.filter((r) => r.status === 'APPROVED' || r.status === 'DOWNLOADED').length;
  const pendingCount = requests.filter((r) => r.status === 'PENDING').length;
  const readyCount = requests.filter((r) => r.status === 'APPROVED').length;

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50/70 p-4 sm:p-6 lg:p-8 font-sans">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Apple-Style Minimalist Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Export Governance & Delivery
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900">
              Approved Downloads
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
              Access and download authorized lead export batches approved by the Administrator.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={fetchRequests}
              disabled={isLoading}
              className="p-2.5 rounded-xl bg-white border border-slate-200/80 text-slate-600 hover:text-slate-900 shadow-2xs hover:bg-slate-50 transition-all cursor-pointer disabled:opacity-50"
              title="Refresh approved downloads"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            <button
              type="button"
              onClick={onNavigateToExplorer}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-semibold shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Explore Leads & Request Export</span>
            </button>
          </div>
        </div>

        {/* Apple-Style Metrics Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          <div className="bg-white/80 backdrop-blur-xl p-4.5 rounded-2xl border border-slate-200/70 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-medium">Ready to Download</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
              {readyCount}
            </div>
            <p className="text-[11px] text-slate-400">
              Approved by administrator and ready for 1-click download
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-xl p-4.5 rounded-2xl border border-slate-200/70 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-medium">Pending Approvals</span>
              <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
              {pendingCount}
            </div>
            <p className="text-[11px] text-slate-400">
              Currently in administrator review queue
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-xl p-4.5 rounded-2xl border border-slate-200/70 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-medium">Total Batches Handled</span>
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <Layers className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-semibold text-slate-900 font-mono tabular-nums">
              {requests.length}
            </div>
            <p className="text-[11px] text-slate-400">
              Audited export requests across all campaigns
            </p>
          </div>
        </div>

        {/* Filter Navigation Bar */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-3 shadow-2xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Segmented Controls */}
          <div className="flex items-center bg-slate-100/80 p-1 rounded-xl text-xs font-medium text-slate-600">
            <button
              type="button"
              onClick={() => setFilterTab('approved')}
              className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                filterTab === 'approved'
                  ? 'bg-white text-slate-900 font-semibold shadow-2xs'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Approved & Ready</span>
              {readyCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  {readyCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setFilterTab('pending')}
              className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                filterTab === 'pending'
                  ? 'bg-white text-slate-900 font-semibold shadow-2xs'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Pending</span>
              {pendingCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                  {pendingCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setFilterTab('all')}
              className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                filterTab === 'all'
                  ? 'bg-white text-slate-900 font-semibold shadow-2xs'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>All Batches</span>
              <span className="text-[10px] text-slate-400">({requests.length})</span>
            </button>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by campaign or keyword..."
              className="w-full pl-8.5 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200/80 rounded-xl text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {/* Requests List */}
        {isLoading ? (
          <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center text-slate-400 text-xs">
            <RefreshCw className="w-6 h-6 mx-auto mb-2 text-slate-300 animate-spin" />
            <p>Loading authorized export batches...</p>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center space-y-3">
            <FileSpreadsheet className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-800">
              {searchQuery ? 'No batches match your filter' : 'No approved downloads in this view'}
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              When an export exceeds your daily limit, submit an approval request with a campaign name. Once approved by the Administrator, it appears here ready for 1-click download.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={onNavigateToExplorer}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition-colors cursor-pointer"
              >
                <span>Go to Lead Explorer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredRequests.map((req) => {
              const isApproved = req.status === 'APPROVED';
              const isDownloaded = req.status === 'DOWNLOADED';
              const isPending = req.status === 'PENDING';
              const isRejected = req.status === 'REJECTED';
              const isBusy = downloadingId === req.id;

              return (
                <div
                  key={req.id}
                  className={`bg-white rounded-2xl border transition-all p-5 shadow-2xs hover:shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isApproved
                      ? 'border-emerald-300/80 ring-1 ring-emerald-500/10'
                      : 'border-slate-200/80'
                  }`}
                >
                  {/* Left Side: Campaign & Lead Details */}
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Campaign Name Tag */}
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200/80 text-xs font-semibold">
                        <Megaphone className="w-3 h-3 text-blue-600" />
                        <span>Campaign: {req.campaign_name || 'General Outreach'}</span>
                      </span>

                      {/* Status Tag */}
                      {isApproved && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Approved · Ready to Download</span>
                        </span>
                      )}

                      {isDownloaded && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-medium">
                          <Download className="w-3.5 h-3.5 text-slate-500" />
                          <span>Downloaded</span>
                        </span>
                      )}

                      {isPending && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-semibold">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Awaiting Administrator Approval</span>
                        </span>
                      )}

                      {isRejected && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 text-rose-800 border border-rose-200 text-[11px] font-semibold">
                          <XCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Declined</span>
                        </span>
                      )}

                      <span className="text-xs font-mono font-bold text-slate-800 tabular-nums">
                        {req.requested_count.toLocaleString()} leads ({req.file_format || 'CSV'})
                      </span>
                    </div>

                    {/* Reason / Admin Note */}
                    <div className="text-xs text-slate-600 space-y-0.5">
                      {req.reason && (
                        <p>
                          <span className="font-medium text-slate-700">Reason:</span> {req.reason}
                        </p>
                      )}
                      {req.admin_note && (
                        <p className="text-slate-700 font-medium bg-slate-50 p-2 rounded-lg border border-slate-100 inline-block">
                          <span className="text-blue-700 font-semibold">Admin Note:</span> {req.admin_note}
                        </p>
                      )}
                    </div>

                    {/* Metadata Footer */}
                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-mono pt-1">
                      <span>Submitted: {new Date(req.created_at).toLocaleDateString()} {new Date(req.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      {req.reviewed_at && (
                        <>
                          <span>·</span>
                          <span>Reviewed: {new Date(req.reviewed_at).toLocaleDateString()} {new Date(req.reviewed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </>
                      )}
                      {req.reviewed_by && (
                        <>
                          <span>·</span>
                          <span>By: {req.reviewed_by}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Right Side: Direct Action Button */}
                  <div className="shrink-0 flex items-center gap-2 pt-2 md:pt-0">
                    {(isApproved || isDownloaded) && (
                      <button
                        type="button"
                        onClick={() => handleDownload(req)}
                        disabled={isBusy}
                        className={`px-4 py-2.5 rounded-xl font-semibold text-xs shadow-xs transition-all flex items-center gap-2 cursor-pointer active:scale-95 disabled:opacity-50 ${
                          isApproved
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20 hover:shadow-md'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                        }`}
                      >
                        <Download className={`w-4 h-4 ${isBusy ? 'animate-bounce' : ''}`} />
                        <span>
                          {isBusy
                            ? 'Streaming File...'
                            : isApproved
                            ? 'Download CSV Dataset'
                            : 'Download Again'}
                        </span>
                      </button>
                    )}

                    {isPending && (
                      <div className="text-right">
                        <span className="text-xs text-amber-700 font-medium px-3 py-1.5 bg-amber-50 rounded-xl border border-amber-200/80 inline-flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 animate-spin text-amber-600" />
                          <span>Review in progress</span>
                        </span>
                      </div>
                    )}

                    {isRejected && (
                      <span className="text-xs text-rose-600 font-medium px-3 py-1.5 bg-rose-50 rounded-xl border border-rose-200">
                        Request Declined
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};

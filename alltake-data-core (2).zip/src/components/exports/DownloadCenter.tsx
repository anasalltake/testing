import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { DownloadJob } from '../../types';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import {
  Download,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  Shield,
} from 'lucide-react';

interface DownloadCenterProps {
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const DownloadCenter: React.FC<DownloadCenterProps> = ({ onNotify }) => {
  const [jobs, setJobs] = useState<DownloadJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadJobs = async () => {
    setIsLoading(true);
    try {
      const res = await apiRequest<{ success: boolean; jobs: DownloadJob[] }>('/exports/jobs');
      if (res.success && res.jobs) {
        setJobs(res.jobs);
      }
    } catch (err: any) {
      onNotify('error', err.message || 'Failed to fetch export tasks');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadJobs();
    const interval = setInterval(loadJobs, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleDownloadFile = (jobId: string, filename: string) => {
    const token = localStorage.getItem('alltake_auth_token');
    // Direct stream
    const url = `/api/exports/${jobId}/download`;
    fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error('File download failed');
        return res.blob();
      })
      .then((blob) => {
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(downloadUrl);
        a.remove();
        onNotify('success', `Downloaded ${filename}`);
      })
      .catch((err) => onNotify('error', err.message));
  };

  const getStatusBadge = (status: DownloadJob['status']) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge variant="success">COMPLETED</Badge>;
      case 'PROCESSING':
      case 'QUEUED':
        return <Badge variant="primary">GENERATING</Badge>;
      case 'FAILED':
        return <Badge variant="danger">FAILED</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Download className="w-5 h-5 text-blue-600" />
            Export Center & Download Logs
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Retrieve generated CSV and Excel files. All file downloads are logged for compliance.
          </p>
        </div>

        <button
          onClick={loadJobs}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
            Export Jobs History
          </span>
          <span className="text-[11px] text-slate-500 font-mono">
            {jobs.length} Generated Archives
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Job Name / Description</th>
                <th className="py-3 px-4 font-semibold">Initiated By</th>
                <th className="py-3 px-4 font-semibold">Format</th>
                <th className="py-3 px-4 font-semibold text-right">Records</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Created</th>
                <th className="py-3 px-4 font-semibold text-center">Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 font-sans">
              {isLoading && jobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center">
                    <LoadingSpinner text="Loading export queue..." />
                  </td>
                </tr>
              ) : jobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No files have been exported yet. Use the Data Explorer to export filtered leads.
                  </td>
                </tr>
              ) : (
                jobs.map((job) => {
                  let filterSummary = 'All Records';
                  try {
                    const parsed =
                      typeof job.filters_json === 'string'
                        ? JSON.parse(job.filters_json)
                        : job.filters_json;
                    const parts = [];
                    if (parsed.country) parts.push(`Country: ${parsed.country}`);
                    if (parsed.state) parts.push(`State: ${parsed.state}`);
                    if (parsed.company) parts.push(`Company: ${parsed.company}`);
                    if (parsed.search) parts.push(`Search: "${parsed.search}"`);
                    if (parts.length > 0) filterSummary = parts.join(' | ');
                  } catch {}

                  const defaultFilename = `alltake_${job.format.toLowerCase()}_export_${job.id.slice(-6)}.${
                    job.format === 'CSV' ? 'csv' : 'xlsx'
                  }`;

                  return (
                    <tr key={job.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-900">{job.dataset_name}</span>
                          <span className="text-[11px] text-slate-500 truncate max-w-xs" title={filterSummary}>
                            {filterSummary}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{job.user_name}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-1 font-mono font-medium text-slate-800">
                          {job.format === 'CSV' ? (
                            <FileText className="w-3.5 h-3.5 text-blue-600" />
                          ) : (
                            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                          )}
                          {job.format}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {job.record_count.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">{getStatusBadge(job.status)}</td>
                      <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                        {new Date(job.started_at).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {job.status === 'COMPLETED' ? (
                          <button
                            onClick={() => handleDownloadFile(job.id, defaultFilename)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg shadow-2xs transition-colors"
                          >
                            <Download className="w-3.5 h-3.5" />
                            Download
                          </button>
                        ) : job.status === 'FAILED' ? (
                          <span className="text-xs text-rose-500 font-mono">Error</span>
                        ) : (
                          <span className="text-xs text-slate-400 font-mono">Processing...</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

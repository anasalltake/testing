import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { apiRequest } from '../../api/client';
import { User, UserRole } from '../../types';
import { UserPlus, AlertCircle, Loader2 } from 'lucide-react';

interface CreateUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUserCreated: (user: User) => void;
}

export const CreateUserModal: React.FC<CreateUserModalProps> = ({
  isOpen,
  onClose,
  onUserCreated,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<UserRole>('EMPLOYEE');
  const [temporaryPassword, setTemporaryPassword] = useState('Alltake@2026Temp');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const res = await apiRequest<{ success: boolean; user: User }>('/users', {
        method: 'POST',
        body: JSON.stringify({
          full_name: fullName,
          email,
          username,
          role,
          temporary_password: temporaryPassword,
        }),
      });

      if (res.success && res.user) {
        onUserCreated(res.user);
        onClose();
        // Reset form
        setFullName('');
        setEmail('');
        setUsername('');
        setTemporaryPassword('Alltake@2026Temp');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to create user account');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Provision Team Member Account"
      subtitle="Only Executive Administrators can grant Employee or Data Manager access"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name</label>
          <input
            type="text"
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
            placeholder="e.g. Jane Doe"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Company Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (!username && e.target.value.includes('@')) {
                  setUsername(e.target.value.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, ''));
                }
              }}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              placeholder="jane.doe@alltake.com"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Username</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
              placeholder="janedoe"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Assign Role (RBAC)</label>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600 bg-white"
          >
            <option value="EMPLOYEE">EMPLOYEE (Data Explorer, Country Analytics, Export)</option>
            <option value="DATA_MANAGER">DATA MANAGER (CSV Ingestion, Validation, Dynamic Schema)</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Initial Temporary Password
          </label>
          <input
            type="text"
            required
            minLength={8}
            value={temporaryPassword}
            onChange={(e) => setTemporaryPassword(e.target.value)}
            className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          />
          <p className="text-[11px] text-slate-400 mt-1">
            User will be prompted to change password upon first login.
          </p>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs border border-slate-200 hover:bg-slate-50 rounded-lg text-slate-700"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-lg shadow-xs flex items-center gap-1.5"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Provisioning...
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                Create Account
              </>
            )}
          </button>
        </div>
      </form>
    </Modal>
  );
};

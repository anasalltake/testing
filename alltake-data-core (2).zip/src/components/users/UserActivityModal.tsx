import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { apiRequest } from '../../api/client';
import { User, AuditLog, LoginLog, DownloadJob } from '../../types';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import { History, Shield, Download, LogIn } from 'lucide-react';

interface UserActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}

export const UserActivityModal: React.FC<UserActivityModalProps> = ({ isOpen, onClose, user }) => {
  const [audits, setAudits] = useState<AuditLog[]>([]);
  const [logins, setLogins] = useState<LoginLog[]>([]);
  const [downloads, setDownloads] = useState<DownloadJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'audits' | 'logins' | 'downloads'>('audits');

  useEffect(() => {
    if (!user || !isOpen) return;

    async function loadActivity() {
      setIsLoading(true);
      try {
        const res = await apiRequest<{
          success: boolean;
          audits: AuditLog[];
          logins: LoginLog[];
          downloads: DownloadJob[];
        }>(`/users/${user!.id}/activity`);

        if (res.success) {
          setAudits(res.audits || []);
          setLogins(res.logins || []);
          setDownloads(res.downloads || []);
        }
      } catch (err) {
        console.error('Failed to load user activity', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadActivity();
  }, [user, isOpen]);

  if (!user) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="User Activity & Audit History"
      subtitle={`Session and action trail for ${user.full_name} (${user.email})`}
      maxWidth="2xl"
    >
      <div className="space-y-4">
        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200">
          <button
            onClick={() => setActiveTab('audits')}
            className={`pb-2 px-3 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'audits'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Audit Events ({audits.length})
          </button>

          <button
            onClick={() => setActiveTab('logins')}
            className={`pb-2 px-3 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'logins'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Login Records ({logins.length})
          </button>

          <button
            onClick={() => setActiveTab('downloads')}
            className={`pb-2 px-3 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'downloads'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            Export History ({downloads.length})
          </button>
        </div>

        {isLoading ? (
          <LoadingSpinner text="Retrieving security logs..." />
        ) : (
          <div className="max-h-72 overflow-y-auto space-y-2">
            {activeTab === 'audits' &&
              (audits.length === 0 ? (
                <p className="text-xs text-slate-500 py-6 text-center">No audit events recorded.</p>
              ) : (
                audits.map((a, i) => (
                  <div
                    key={i}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex items-center justify-between"
                  >
                    <div>
                      <span className="font-semibold text-slate-900 font-mono">{a.action}</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Target: {a.entity_type} {a.entity_id ? `(${a.entity_id})` : ''}
                      </p>
                    </div>
                    <div className="text-right text-[11px] text-slate-400 font-mono">
                      <p>{new Date(a.created_at).toLocaleString()}</p>
                      <p className="text-slate-500">IP: {a.ip_address || '127.0.0.1'}</p>
                    </div>
                  </div>
                ))
              ))}

            {activeTab === 'logins' &&
              (logins.length === 0 ? (
                <p className="text-xs text-slate-500 py-6 text-center">No login attempts recorded.</p>
              ) : (
                logins.map((l, i) => (
                  <div
                    key={i}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge variant={l.status === 'SUCCESS' ? 'success' : 'danger'} size="sm">
                          {l.status}
                        </Badge>
                        <span className="font-mono text-[11px] text-slate-600">IP: {l.ip_address}</span>
                      </div>
                      {l.failure_reason && (
                        <p className="text-[11px] text-rose-600 mt-0.5">Reason: {l.failure_reason}</p>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {new Date(l.created_at).toLocaleString()}
                    </span>
                  </div>
                ))
              ))}

            {activeTab === 'downloads' &&
              (downloads.length === 0 ? (
                <p className="text-xs text-slate-500 py-6 text-center">No files exported by this user.</p>
              ) : (
                downloads.map((d, i) => (
                  <div
                    key={i}
                    className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex items-center justify-between"
                  >
                    <div>
                      <span className="font-semibold text-slate-900">{d.dataset_name}</span>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {d.format} • {d.record_count.toLocaleString()} leads
                      </p>
                    </div>
                    <Badge variant={d.status === 'COMPLETED' ? 'success' : 'default'} size="sm">
                      {d.status}
                    </Badge>
                  </div>
                ))
              ))}
          </div>
        )}
      </div>
    </Modal>
  );
};

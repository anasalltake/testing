import React, { useState, useEffect } from 'react';
import {
  X,
  Users,
  ShieldCheck,
  ClipboardList,
  Database,
  UserPlus,
  Ban,
  CheckCircle2,
  Trash2,
  Mail,
  User,
  KeyRound,
  AlertCircle,
  Loader2,
  Sparkles,
  Lock,
  Search,
  RotateCw,
  Server,
  Layers,
  ArrowRight,
  SlidersHorizontal,
  ArrowUp,
  ArrowDown,
  ChevronsUp,
  ChevronsDown,
  Eye,
  EyeOff,
  RotateCcw,
  Activity,
  Zap,
  AlertTriangle,
  RefreshCw,
  HardDrive,
  Filter,
  Save,
  FileSpreadsheet,
  Clock,
  XCircle,
  Download,
  Copy,
  Check,
  Target
} from 'lucide-react';
import { DmsLogo } from '../common/DmsLogo';
import {
  EnterpriseUser,
  FieldVisibilityRule,
  DownloadAuditLog,
  UserRole,
  EnterpriseColumnDef,
  DatabaseDiagnosticStatus,
  FilterRuleConfig,
  DEFAULT_FILTER_RULES,
  ExportGovernanceSettings,
  ExportApprovalRequest,
} from '../../types/enterprise';
import {
  getAllUsers,
  createEnterpriseUser,
  toggleBlockUser,
  deleteEnterpriseUser,
  resetEnterpriseUserPassword,
  getFieldVisibilityRules,
  updateFieldVisibilityRule,
  toggleColumnEmployeeDownloadRule,
  getFilterRules,
  updateFilterRules,
  resetFilterRulesToDefault,
  getAllDownloadLogs,
  clearSampleSeedDataFromDB,
  syncLeadsFromBackendApi,
  getAllColumns,
  updateColumnOrderAndVisibility,
  resetColumnOrderToDefault,
  fetchDatabaseStatus,
  testDatabaseDiagnostics,
  getExportGovernanceSettings,
  updateExportGovernanceSettings,
  getExportApprovalRequests,
  reviewExportApprovalRequest,
} from '../../services/enterpriseDb';

export type AdminSettingsTab = 'users' | 'columns' | 'filters' | 'masking' | 'exports' | 'logs' | 'database';

interface AdminSettingsModalProps {
  isOpen: boolean;
  initialTab?: AdminSettingsTab;
  onClose: () => void;
  onNotify: (msg: string) => void;
  onDataChanged?: () => void;
}

export const AdminSettingsModal: React.FC<AdminSettingsModalProps> = ({
  isOpen,
  initialTab = 'users',
  onClose,
  onNotify,
  onDataChanged,
}) => {
  const [activeTab, setActiveTab] = useState<AdminSettingsTab>(initialTab);

  // Sync initialTab when modal opens
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  // Tab 1: Users State
  const [users, setUsers] = useState<EnterpriseUser[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('EMPLOYEE');
  const [userFormError, setUserFormError] = useState<string | null>(null);

  // Password reset modal state
  const [resettingUser, setResettingUser] = useState<EnterpriseUser | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [isResetting, setIsResetting] = useState(false);
  const [resetSuccessMsg, setResetSuccessMsg] = useState<string | null>(null);
  const [resetErrorMsg, setResetErrorMsg] = useState<string | null>(null);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [copied, setCopied] = useState(false);

  // Tab 2: Masking Rules State
  const [rules, setRules] = useState<FieldVisibilityRule[]>([]);
  const [isLoadingRules, setIsLoadingRules] = useState(false);

  // Tab 3: Download Logs State
  const [logs, setLogs] = useState<DownloadAuditLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [logsSearchTerm, setLogsSearchTerm] = useState('');

  // Tab 4: Database Live Status & Diagnostics State
  const [dbStatus, setDbStatus] = useState<DatabaseDiagnosticStatus | null>(null);
  const [isLoadingDbStatus, setIsLoadingDbStatus] = useState(false);
  const [isTestingDb, setIsTestingDb] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<any | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');
  const [isPurging, setIsPurging] = useState(false);
  const [dbNotice, setDbNotice] = useState<string | null>(null);

  // Tab: Columns State
  const [columnsList, setColumnsList] = useState<EnterpriseColumnDef[]>([]);
  const [isLoadingColumns, setIsLoadingColumns] = useState(false);
  const [columnsSearch, setColumnsSearch] = useState('');
  const [isSavingColumns, setIsSavingColumns] = useState(false);

  // Tab: Filters State (Admin-controlled filter visibility)
  const [filterRulesList, setFilterRulesList] = useState<FilterRuleConfig[]>([]);
  const [isLoadingFilters, setIsLoadingFilters] = useState(false);
  const [isSavingFilters, setIsSavingFilters] = useState(false);

  // Tab: Export Limits & Governance State
  const [exportSettings, setExportSettings] = useState<ExportGovernanceSettings>({
    employeeMaxDownloadLimit: 10000,
    requireApprovalAboveLimit: true,
    allowEmployeeDownload: true,
  });
  const [exportLimitInput, setExportLimitInput] = useState<number>(10000);
  const [exportRequests, setExportRequests] = useState<ExportApprovalRequest[]>([]);
  const [isLoadingExports, setIsLoadingExports] = useState(false);
  const [isSavingExportSettings, setIsSavingExportSettings] = useState(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [rejectNote, setRejectNote] = useState<string>('');
  const [rejectingRequestId, setRejectingRequestId] = useState<string | null>(null);

  const loadExportsData = async () => {
    setIsLoadingExports(true);
    try {
      const [settings, requests] = await Promise.all([
        getExportGovernanceSettings(),
        getExportApprovalRequests(),
      ]);
      setExportSettings(settings);
      setExportLimitInput(settings.employeeMaxDownloadLimit || 10000);
      setExportRequests(requests);
    } catch (err: any) {
      console.warn('Failed to load export governance data:', err);
    } finally {
      setIsLoadingExports(false);
    }
  };

  // Load data based on tab
  const loadUsersData = async () => {
    setIsLoadingUsers(true);
    try {
      const data = await getAllUsers();
      setUsers(data);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const loadFiltersData = async () => {
    setIsLoadingFilters(true);
    try {
      const data = await getFilterRules(undefined, 'ADMIN');
      setFilterRulesList(data);
    } finally {
      setIsLoadingFilters(false);
    }
  };

  const loadColumnsData = async () => {
    setIsLoadingColumns(true);
    try {
      const data = await getAllColumns();
      setColumnsList(data);
    } finally {
      setIsLoadingColumns(false);
    }
  };

  const loadRulesData = async () => {
    setIsLoadingRules(true);
    try {
      const data = await getFieldVisibilityRules();
      setRules(data);
    } finally {
      setIsLoadingRules(false);
    }
  };

  const loadLogsData = async () => {
    setIsLoadingLogs(true);
    try {
      const data = await getAllDownloadLogs();
      setLogs(data);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const loadDatabaseStatus = async () => {
    setIsLoadingDbStatus(true);
    try {
      const status = await fetchDatabaseStatus();
      setDbStatus(status);
    } catch (err: any) {
      console.warn('Failed to load database status', err);
    } finally {
      setIsLoadingDbStatus(false);
    }
  };

  const handleRunDiagnostics = async () => {
    setIsTestingDb(true);
    setDiagnosticResult(null);
    try {
      const result = await testDatabaseDiagnostics();
      setDiagnosticResult(result);
      await loadDatabaseStatus();
      onNotify(`Diagnostic check passed: Latency ${result.latencyMs}ms · ${result.readCheck} · ${result.writeCheck}`);
    } catch (err: any) {
      onNotify('Diagnostic test failed: ' + (err?.message || 'Server connection error'));
    } finally {
      setIsTestingDb(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    if (activeTab === 'users') loadUsersData();
    else if (activeTab === 'columns') loadColumnsData();
    else if (activeTab === 'filters') loadFiltersData();
    else if (activeTab === 'masking') loadRulesData();
    else if (activeTab === 'exports') loadExportsData();
    else if (activeTab === 'logs') loadLogsData();
    else if (activeTab === 'database') loadDatabaseStatus();
  }, [isOpen, activeTab]);

  // Handlers for Columns Layout (Aage / Peeche Position & Employee Visibility)
  const handleMoveColumnTab = (key: string, direction: 'UP' | 'DOWN' | 'TOP' | 'BOTTOM') => {
    const list = [...columnsList];
    const index = list.findIndex((c) => c.key === key);
    if (index === -1) return;

    const [item] = list.splice(index, 1);

    if (direction === 'TOP') {
      list.unshift(item);
    } else if (direction === 'BOTTOM') {
      list.push(item);
    } else if (direction === 'UP' && index > 0) {
      list.splice(index - 1, 0, item);
    } else if (direction === 'DOWN' && index < list.length) {
      list.splice(index + 1, 0, item);
    } else {
      list.splice(index, 0, item);
    }

    const reindexed = list.map((c, i) => ({
      ...c,
      order: i + 1,
    }));

    setColumnsList(reindexed);
  };

  const handleToggleEmployeeCol = (key: string) => {
    setColumnsList((prev) =>
      prev.map((c) => {
        if (c.key === key) {
          return { ...c, employeeVisible: c.employeeVisible === false ? true : false };
        }
        return c;
      })
    );
  };

  const handleSaveColumnsLayout = async () => {
    setIsSavingColumns(true);
    try {
      const saved = await updateColumnOrderAndVisibility(columnsList);
      setColumnsList(saved);
      onNotify(`Column layout saved: ${saved.length} columns ordered & employee visibility active.`);
      onDataChanged?.();
    } catch {
      onNotify('Failed to save column layout.');
    } finally {
      setIsSavingColumns(false);
    }
  };

  const handleResetColumnsDefault = async () => {
    setIsSavingColumns(true);
    try {
      const reset = await resetColumnOrderToDefault();
      setColumnsList(reset);
      onNotify('Column positions and employee visibility reset to default 31 standards.');
      onDataChanged?.();
    } catch {
      onNotify('Failed to reset column order.');
    } finally {
      setIsSavingColumns(false);
    }
  };

  // Handlers for Filter Controls Management
  const handleToggleFilterEnabled = (key: string, enabled: boolean) => {
    setFilterRulesList((prev) =>
      prev.map((f) => (f.key === key ? { ...f, enabled } : f))
    );
  };

  const handleToggleFilterEmployeeVisibility = (key: string, visibleToEmployees: boolean) => {
    setFilterRulesList((prev) =>
      prev.map((f) => (f.key === key ? { ...f, visibleToEmployees } : f))
    );
  };

  const handleMoveFilterOrder = (key: string, direction: 'UP' | 'DOWN') => {
    const list = [...filterRulesList];
    const index = list.findIndex((f) => f.key === key);
    if (index === -1) return;
    const targetIndex = direction === 'UP' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= list.length) return;

    const [item] = list.splice(index, 1);
    list.splice(targetIndex, 0, item);
    const updated = list.map((f, i) => ({ ...f, displayOrder: i + 1 }));
    setFilterRulesList(updated);
  };

  const handleApplyFilterPreset = (preset: 'default_secure' | 'all_visible') => {
    if (preset === 'default_secure') {
      setFilterRulesList((prev) =>
        prev.map((f) => ({
          ...f,
          enabled: true,
          visibleToEmployees: !['name', 'email', 'addressLink', 'phone'].includes(f.key),
        }))
      );
      onNotify('Applied Secure Preset: Contact Name, Email, Address Link & Phone hidden for employees.');
    } else if (preset === 'all_visible') {
      setFilterRulesList((prev) =>
        prev.map((f) => ({
          ...f,
          enabled: true,
          visibleToEmployees: true,
        }))
      );
      onNotify('Applied All Visible Preset: All filters visible to employees.');
    }
  };

  const handleSaveFilters = async () => {
    setIsSavingFilters(true);
    try {
      const saved = await updateFilterRules(filterRulesList);
      setFilterRulesList(saved);
      onNotify(`Filter controls saved! Updated ${saved.length} filter rules in database.`);
      onDataChanged?.();
    } catch (err: any) {
      onNotify('Failed to save filter settings: ' + err.message);
    } finally {
      setIsSavingFilters(false);
    }
  };

  const handleResetFiltersDefault = async () => {
    if (!confirm('Reset all filter controls to secure factory defaults?')) return;
    setIsSavingFilters(true);
    try {
      const reset = await resetFilterRulesToDefault();
      setFilterRulesList(reset);
      onNotify('Filter controls reset to secure factory defaults.');
      onDataChanged?.();
    } catch (err: any) {
      onNotify('Failed to reset filters: ' + err.message);
    } finally {
      setIsSavingFilters(false);
    }
  };

  if (!isOpen) return null;

  // Handlers for Users
  const handleToggleBlock = async (userId: string, currentStatus: string) => {
    try {
      const updated = await toggleBlockUser(userId);
      if (updated) {
        setUsers((prev) => prev.map((u) => (u.id === userId ? updated : u)));
      }
      onNotify(
        currentStatus === 'ACTIVE'
          ? 'Employee account blocked successfully'
          : 'Employee account unblocked and active'
      );
    } catch (err: any) {
      onNotify(err.message || 'Operation failed');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to permanently delete this account?')) return;
    try {
      await deleteEnterpriseUser(userId);
      setUsers((prev) => prev.filter((u) => u.id !== userId));
      onNotify('User account removed');
    } catch (err: any) {
      onNotify(err.message || 'Failed to remove user');
    }
  };

  const handleOpenReset = (u: EnterpriseUser) => {
    setResettingUser(u);
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pwd = 'Alltake@';
    for (let i = 0; i < 6; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPassword(pwd);
    setResetSuccessMsg(null);
    setResetErrorMsg(null);
    setCopied(false);
  };

  const handleConfirmReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resettingUser || !newPassword.trim()) return;
    setIsResetting(true);
    setResetErrorMsg(null);
    try {
      const res = await resetEnterpriseUserPassword(resettingUser.id, newPassword.trim());
      setResetSuccessMsg(res.message || 'Password successfully updated');
      onNotify(`Password reset for ${resettingUser.full_name}. New password: ${newPassword.trim()}`);
    } catch (err: any) {
      setResetErrorMsg(err.message || 'Failed to reset password');
    } finally {
      setIsResetting(false);
    }
  };

  const handleGeneratePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pwd = 'Alltake@';
    for (let i = 0; i < 6; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPassword(pwd);
    setCopied(false);
  };

  const handleCopyPassword = () => {
    navigator.clipboard.writeText(newPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim() || !username.trim() || !password) {
      setUserFormError('Please fill in all employee account fields');
      return;
    }

    try {
      setUserFormError(null);
      const newUser = await createEnterpriseUser({
        full_name: fullName.trim(),
        email: email.trim().toLowerCase(),
        username: username.trim().toLowerCase(),
        role,
        status: 'ACTIVE',
        password: password.trim(),
      });

      setUsers((prev) => [...prev, newUser]);
      setIsCreatingUser(false);
      setFullName('');
      setEmail('');
      setUsername('');
      setPassword('');
      setRole('EMPLOYEE');
      onNotify(`Account created for ${newUser.full_name} and saved to database`);
      onDataChanged?.();
    } catch (err: any) {
      setUserFormError(err.message || 'Could not create account');
    }
  };

  // Handlers for Export Governance & Limit Controls
  const handleSaveExportSettings = async () => {
    setIsSavingExportSettings(true);
    try {
      const updated = await updateExportGovernanceSettings({
        employeeMaxDownloadLimit: Number(exportLimitInput) || 10000,
        requireApprovalAboveLimit: exportSettings.requireApprovalAboveLimit,
        allowEmployeeDownload: exportSettings.allowEmployeeDownload,
      });
      setExportSettings(updated);
      onNotify(`Export policy updated: Employee limit set to ${updated.employeeMaxDownloadLimit.toLocaleString()} records.`);
      onDataChanged?.();
    } catch (err: any) {
      onNotify(err.message || 'Failed to update export policy');
    } finally {
      setIsSavingExportSettings(false);
    }
  };

  const handleReviewRequest = async (requestId: string, status: 'APPROVED' | 'REJECTED', note?: string) => {
    setReviewingId(requestId);
    try {
      const updated = await reviewExportApprovalRequest(requestId, status, note);
      setExportRequests((prev) => prev.map((r) => (r.id === requestId ? updated : r)));
      onNotify(`Export request ${requestId} ${status.toLowerCase()} successfully.`);
      setRejectingRequestId(null);
      setRejectNote('');
      onDataChanged?.();
    } catch (err: any) {
      onNotify(err.message || 'Failed to update request');
    } finally {
      setReviewingId(null);
    }
  };

  // Handlers for Masking & Export Rules
  const handleUpdateRule = async (
    columnKey: string,
    visibility: 'VISIBLE' | 'MASKED' | 'HIDDEN'
  ) => {
    await updateFieldVisibilityRule(columnKey, visibility);
    setRules((prev) =>
      prev.map((r) => (r.columnKey === columnKey ? { ...r, employeeVisibility: visibility } : r))
    );
    onNotify('Field visibility rule updated');
    onDataChanged?.();
  };

  const handleToggleDownloadRule = async (columnKey: string, allowed: boolean) => {
    await toggleColumnEmployeeDownloadRule(columnKey, allowed);
    setRules((prev) =>
      prev.map((r) => (r.columnKey === columnKey ? { ...r, allowEmployeeDownload: allowed } : r))
    );
    onNotify(`Employee export permission updated for column`);
    onDataChanged?.();
  };

  const handleApplyPreset = async (preset: 'strict_pii' | 'all_visible' | 'hide_contacts') => {
    for (const r of rules) {
      let vis: 'VISIBLE' | 'MASKED' | 'HIDDEN' = 'VISIBLE';
      if (preset === 'strict_pii') {
        if (['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(r.columnKey)) {
          vis = 'MASKED';
        }
      } else if (preset === 'hide_contacts') {
        if (['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(r.columnKey)) {
          vis = 'HIDDEN';
        }
      }
      await updateFieldVisibilityRule(r.columnKey, vis);
    }
    const updated = await getFieldVisibilityRules();
    setRules(updated);
    onNotify(`Preset applied: ${preset.replace('_', ' ').toUpperCase()}`);
    onDataChanged?.();
  };

  // Handlers for Database Sync
  const handleSyncDatabase = async () => {
    setIsSyncing(true);
    setSyncProgress(10);
    setSyncStatusMsg('Verifying PostgreSQL connection...');

    setTimeout(() => {
      setSyncProgress(35);
      setSyncStatusMsg('Connecting to Flask REST API...');
    }, 150);

    setTimeout(() => {
      setSyncProgress(65);
      setSyncStatusMsg('Streaming 31 standard columns & building indexes...');
    }, 320);

    setTimeout(async () => {
      try {
        const res = await syncLeadsFromBackendApi();
        setSyncProgress(100);
        setSyncStatusMsg(`Successfully populated ${res.syncedCount.toLocaleString()} leads!`);
        setDbNotice(`Synced ${res.syncedCount.toLocaleString()} leads from database.`);
        onNotify(`Database Sync Complete: Loaded ${res.syncedCount.toLocaleString()} leads.`);
        onDataChanged?.();
      } catch (err) {
        setSyncStatusMsg('Sync finished with local cache fallback');
      } finally {
        setIsSyncing(false);
      }
    }, 550);
  };

  const handlePurgeSeeds = async () => {
    if (!confirm('Purge initial sample seed data? Only uploaded and synced records will remain.'))
      return;
    setIsPurging(true);
    try {
      const res = await clearSampleSeedDataFromDB();
      setDbNotice(
        `Sample seeds purged. Retained ${res.remainingCount.toLocaleString()} genuine uploaded records.`
      );
      onNotify('Sample seed data purged. Database running in pure mode.');
      onDataChanged?.();
    } catch (err: any) {
      setDbNotice('Purge failed: ' + err.message);
    } finally {
      setIsPurging(false);
    }
  };

  // Filtered Logs
  const filteredLogs = logs.filter((log) => {
    if (!logsSearchTerm) return true;
    const q = logsSearchTerm.toLowerCase();
    return (
      log.userName.toLowerCase().includes(q) ||
      log.userEmail.toLowerCase().includes(q) ||
      log.filtersSummary.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50/80 border-b border-slate-200 shrink-0">
          <div className="flex items-center gap-3">
            <DmsLogo size="sm" variant="icon" />
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span>Admin Settings & Control Center</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  Super Admin
                </span>
              </h2>
              <p className="text-[11px] text-slate-500">
                Manage employee access, data masking policies, export compliance, and database engine
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Apple-style Segmented Tab Bar */}
        <div className="px-6 py-3 bg-white border-b border-slate-100 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200/80 text-xs w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('users')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Employees & Block</span>
            </button>

            <button
              onClick={() => setActiveTab('columns')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'columns'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Column Layout & Order</span>
            </button>

            <button
              onClick={() => setActiveTab('filters')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'filters'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filter Controls</span>
            </button>

            <button
              onClick={() => setActiveTab('masking')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'masking'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Masking Rules</span>
            </button>

            <button
              onClick={() => setActiveTab('exports')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'exports'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export Limits & Approvals</span>
              {exportRequests.filter((r) => r.status === 'PENDING').length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                  {exportRequests.filter((r) => r.status === 'PENDING').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'logs'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ClipboardList className="w-3.5 h-3.5" />
              <span>Download Logs</span>
            </button>

            <button
              onClick={() => setActiveTab('database')}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg font-medium transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'database'
                  ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Database & Sync</span>
            </button>
          </div>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          {/* TAB 1: EMPLOYEES & BLOCK ACCESS */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Authorized Team Accounts
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Control system credentials, roles, and instantly block unauthorized access
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsCreatingUser(!isCreatingUser)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{isCreatingUser ? 'Cancel' : 'Add Employee'}</span>
                </button>
              </div>

              {/* Add Employee Form Drawer */}
              {isCreatingUser && (
                <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-xs space-y-3">
                  <h4 className="text-xs font-bold text-blue-900">Create New Team Member</h4>
                  {userFormError && (
                    <div className="p-2 bg-rose-50 text-rose-700 text-xs rounded-lg flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{userFormError}</span>
                    </div>
                  )}

                  <form onSubmit={handleCreateUserSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="e.g. Johnathan Smith"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="john@alltake.com"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Login Username
                      </label>
                      <input
                        type="text"
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="jsmith"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Password
                      </label>
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Min 6 characters"
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">Role</label>
                      <select
                        value={role}
                        onChange={(e) => setRole(e.target.value as UserRole)}
                        className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      >
                        <option value="EMPLOYEE">Employee (Subject to Masking Rules)</option>
                        <option value="DATA_MANAGER">Data Manager (Can Upload & View All)</option>
                        <option value="ADMIN">Super Admin (Full Control)</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2 flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsCreatingUser(false)}
                        className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs"
                      >
                        Save Account
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Users List Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                {isLoadingUsers ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span>Loading accounts...</span>
                  </div>
                ) : (
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold text-[11px]">
                        <th className="py-2.5 px-4">User</th>
                        <th className="py-2.5 px-3">Role</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Created</th>
                        <th className="py-2.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map((u) => {
                        const isPrimaryAdmin = u.role === 'ADMIN';
                        const isBlocked = u.status === 'BLOCKED';

                        return (
                          <tr key={u.id} className="hover:bg-slate-50/60 transition-colors">
                            <td className="py-2.5 px-4">
                              <div className="flex items-center gap-2.5">
                                <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center text-[11px] font-semibold">
                                  {u.full_name.slice(0, 2).toUpperCase()}
                                </div>
                                <div>
                                  <span className="font-semibold text-slate-900 block">{u.full_name}</span>
                                  <span className="text-[10px] text-slate-400 font-mono">
                                    @{u.username} · {u.email}
                                  </span>
                                </div>
                              </div>
                            </td>

                            <td className="py-2.5 px-3">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                                  u.role === 'ADMIN'
                                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                    : u.role === 'DATA_MANAGER'
                                    ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                    : 'bg-slate-100 text-slate-700 border border-slate-200'
                                }`}
                              >
                                {u.role}
                              </span>
                            </td>

                            <td className="py-2.5 px-3">
                              {isBlocked ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                                  <Ban className="w-2.5 h-2.5" />
                                  <span>BLOCKED</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                                  <CheckCircle2 className="w-2.5 h-2.5" />
                                  <span>ACTIVE</span>
                                </span>
                              )}
                            </td>

                            <td className="py-2.5 px-3 text-[11px] text-slate-500 font-mono">
                              {new Date(u.created_at).toLocaleDateString()}
                            </td>

                            <td className="py-2.5 px-4 text-right">
                              <div className="inline-flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleOpenReset(u)}
                                  className="px-2 py-1 text-[10px] font-semibold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 flex items-center gap-1 cursor-pointer transition-colors"
                                  title="Reset password for this user"
                                >
                                  <KeyRound className="w-3 h-3" />
                                  <span>Reset Pwd</span>
                                </button>

                                {!isPrimaryAdmin && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => handleToggleBlock(u.id, u.status)}
                                      className={`px-2 py-1 text-[10px] font-semibold rounded border transition-colors cursor-pointer ${
                                        isBlocked
                                          ? 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                                          : 'bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100'
                                      }`}
                                    >
                                      {isBlocked ? 'Unblock' : 'Block Access'}
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() => handleDeleteUser(u.id)}
                                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                                      title="Delete Account"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* TAB: COLUMN LAYOUT & EMPLOYEE VISIBILITY (Positioning Aage/Peeche) */}
          {activeTab === 'columns' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Column Positions & Employee Filter Visibility
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Reorder column positions (Aage / Peeche) and choose which columns employees see after applying filters.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleResetColumnsDefault}
                    disabled={isSavingColumns}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-rose-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset Standard (1..31)</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveColumnsLayout}
                    disabled={isSavingColumns}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    {isSavingColumns ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Save Column Layout</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Search & stats bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={columnsSearch}
                    onChange={(e) => setColumnsSearch(e.target.value)}
                    placeholder="Search column name or key..."
                    className="w-full pl-8.5 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:bg-white"
                  />
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-2">
                  <span>Visible to Employees:</span>
                  <span className="font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                    {columnsList.filter((c) => c.employeeVisible !== false).length} of {columnsList.length}
                  </span>
                </div>
              </div>

              {/* Column list table */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="divide-y divide-slate-100 max-h-[50vh] overflow-y-auto">
                  {columnsList
                    .filter((col) => {
                      if (!columnsSearch.trim()) return true;
                      const q = columnsSearch.toLowerCase().trim();
                      return col.label.toLowerCase().includes(q) || col.key.toLowerCase().includes(q);
                    })
                    .map((col) => {
                      const origIndex = columnsList.findIndex((c) => c.key === col.key);
                      const isFirst = origIndex === 0;
                      const isLast = origIndex === columnsList.length - 1;
                      const isEmpVis = col.employeeVisible !== false;

                      return (
                        <div
                          key={col.key}
                          className="flex items-center justify-between p-3 hover:bg-slate-50/80 transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0 pr-2">
                            <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center text-xs font-mono font-bold shrink-0">
                              #{origIndex + 1}
                            </span>
                            <div className="truncate">
                              <span className="font-semibold text-slate-900 text-xs block truncate">
                                {col.label}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                key: {col.key} · type: {col.type}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {/* Employee Visibility Button */}
                            <button
                              type="button"
                              onClick={() => handleToggleEmployeeCol(col.key)}
                              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border cursor-pointer transition-colors ${
                                isEmpVis
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                              }`}
                            >
                              {isEmpVis ? (
                                <>
                                  <Eye className="w-3 h-3 text-emerald-600" />
                                  <span>Visible to Employee</span>
                                </>
                              ) : (
                                <>
                                  <EyeOff className="w-3 h-3 text-rose-600" />
                                  <span>Hidden for Employee</span>
                                </>
                              )}
                            </button>

                            {/* Move Up (Aage) */}
                            <button
                              type="button"
                              disabled={isFirst}
                              onClick={() => handleMoveColumnTab(col.key, 'UP')}
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 border border-slate-200 rounded-lg disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                              title="Move column forward (left in table)"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>

                            {/* Move Down (Peeche) */}
                            <button
                              type="button"
                              disabled={isLast}
                              onClick={() => handleMoveColumnTab(col.key, 'DOWN')}
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 border border-slate-200 rounded-lg disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                              title="Move column backward (right in table)"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: FILTER CONTROLS MANAGEMENT */}
          {activeTab === 'filters' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Filter className="w-4 h-4 text-blue-600" />
                    <span>Filter Visibility & Employee Access Management</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Super Admin controls which filters appear in the employee sidebar. By default, contact name, email, address link, and phone are hidden.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleApplyFilterPreset('default_secure')}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer"
                    title="Hide Contact Name, Email, Address Link, and Phone for employees"
                  >
                    Default Secure
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyFilterPreset('all_visible')}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
                  >
                    Show All
                  </button>
                  <button
                    type="button"
                    onClick={handleResetFiltersDefault}
                    disabled={isSavingFilters}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveFilters}
                    disabled={isSavingFilters}
                    className="px-3.5 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isSavingFilters ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                    <span>Save Filters</span>
                  </button>
                </div>
              </div>

              {/* Filter Rules Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                {isLoadingFilters ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span>Loading filter controls from database...</span>
                  </div>
                ) : (
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold text-[11px]">
                        <th className="py-2.5 px-4">Filter Dimension</th>
                        <th className="py-2.5 px-3">Category</th>
                        <th className="py-2.5 px-3 text-center">Master Enabled</th>
                        <th className="py-2.5 px-3 text-center bg-blue-50/50 text-blue-900 border-l border-r border-slate-200">
                          Visible to Employees
                        </th>
                        <th className="py-2.5 px-3 text-center">Order & Position</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filterRulesList.map((filter, index) => {
                        const isProtectedPII = filter.isSensitivePII || ['name', 'email', 'addressLink', 'phone'].includes(filter.key);
                        return (
                          <tr key={filter.key} className="hover:bg-slate-50/60 transition-colors">
                            <td className="py-2 px-4">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-900">{filter.label}</span>
                                {isProtectedPII && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 font-mono">
                                    PII Guarded
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400 font-mono block">
                                key: {filter.key}
                              </span>
                            </td>

                            <td className="py-2 px-3 text-slate-600 text-[11px]">
                              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium">
                                {filter.category || 'General'}
                              </span>
                            </td>

                            <td className="py-2 px-3 text-center">
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={filter.enabled !== false}
                                  onChange={(e) => handleToggleFilterEnabled(filter.key, e.target.checked)}
                                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                />
                                <span className="text-[10px] text-slate-500">
                                  {filter.enabled !== false ? 'Active' : 'Disabled'}
                                </span>
                              </label>
                            </td>

                            <td className="py-2 px-3 text-center bg-blue-50/20 border-l border-r border-slate-100">
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={filter.visibleToEmployees !== false}
                                  onChange={(e) => handleToggleFilterEmployeeVisibility(filter.key, e.target.checked)}
                                  className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                />
                                <span className={`text-[10px] font-semibold ${filter.visibleToEmployees !== false ? 'text-emerald-700' : 'text-rose-600 font-bold'}`}>
                                  {filter.visibleToEmployees !== false ? 'Shown in UI' : 'Hidden from UI'}
                                </span>
                              </label>
                            </td>

                            <td className="py-2 px-3 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <span className="font-mono text-slate-500 text-xs w-5 text-center">
                                  {index + 1}
                                </span>
                                <button
                                  type="button"
                                  disabled={index === 0}
                                  onClick={() => handleMoveFilterOrder(filter.key, 'UP')}
                                  className="p-1 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded disabled:opacity-20 cursor-pointer"
                                  title="Move filter up"
                                >
                                  <ArrowUp className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  disabled={index === filterRulesList.length - 1}
                                  onClick={() => handleMoveFilterOrder(filter.key, 'DOWN')}
                                  className="p-1 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded disabled:opacity-20 cursor-pointer"
                                  title="Move filter down"
                                >
                                  <ArrowDown className="w-3 h-3" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: DATA MASKING RULES */}
          {activeTab === 'masking' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Employee Column Visibility & Masking Rules
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Configure which fields are Visible, Masked (with ••••), or completely Hidden for employees
                  </p>
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('strict_pii')}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer"
                  >
                    Strict PII Masked
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('all_visible')}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-white text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    All Visible
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('hide_contacts')}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors cursor-pointer"
                  >
                    Hide Contacts
                  </button>
                </div>
              </div>

              {/* Rules Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                {isLoadingRules ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span>Loading column rules...</span>
                  </div>
                ) : (
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold text-[11px]">
                        <th className="py-2.5 px-4">Standard Column Name</th>
                        <th className="py-2.5 px-3 text-center">Visible</th>
                        <th className="py-2.5 px-3 text-center">Masked (••••)</th>
                        <th className="py-2.5 px-3 text-center">Hidden</th>
                        <th className="py-2.5 px-3 text-center bg-blue-50/50 text-blue-900 border-l border-slate-200">
                          Employee Export Allowed
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rules.map((rule) => {
                        const isSensitive = [
                          'emailAddress',
                          'companyPhone',
                          'directNumber',
                          'otherNumber',
                        ].includes(rule.columnKey);

                        const isExportAllowed = rule.allowEmployeeDownload !== false;

                        return (
                          <tr key={rule.columnKey} className="hover:bg-slate-50/60 transition-colors">
                            <td className="py-2 px-4">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-900">{rule.columnLabel}</span>
                                {isSensitive && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 font-mono">
                                    PII
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400 font-mono">{rule.columnKey}</span>
                            </td>

                            <td className="py-2 px-3 text-center">
                              <input
                                type="radio"
                                name={`vis_${rule.columnKey}`}
                                checked={rule.employeeVisibility === 'VISIBLE'}
                                onChange={() => handleUpdateRule(rule.columnKey, 'VISIBLE')}
                                className="w-3.5 h-3.5 text-blue-600 cursor-pointer"
                              />
                            </td>

                            <td className="py-2 px-3 text-center">
                              <input
                                type="radio"
                                name={`vis_${rule.columnKey}`}
                                checked={rule.employeeVisibility === 'MASKED'}
                                onChange={() => handleUpdateRule(rule.columnKey, 'MASKED')}
                                className="w-3.5 h-3.5 text-blue-600 cursor-pointer"
                              />
                            </td>

                            <td className="py-2 px-3 text-center">
                              <input
                                type="radio"
                                name={`vis_${rule.columnKey}`}
                                checked={rule.employeeVisibility === 'HIDDEN'}
                                onChange={() => handleUpdateRule(rule.columnKey, 'HIDDEN')}
                                className="w-3.5 h-3.5 text-blue-600 cursor-pointer"
                              />
                            </td>

                            <td className="py-2 px-3 text-center bg-blue-50/20 border-l border-slate-100">
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={isExportAllowed}
                                  onChange={(e) => handleToggleDownloadRule(rule.columnKey, e.target.checked)}
                                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                />
                                <span className={`text-[10px] font-semibold ${isExportAllowed ? 'text-emerald-700' : 'text-slate-400'}`}>
                                  {isExportAllowed ? 'Allowed' : 'Locked'}
                                </span>
                              </label>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* TAB: EXPORT GOVERNANCE & APPROVALS */}
          {activeTab === 'exports' && (
            <div className="space-y-6">
              {/* Section 1: Quota Policy Card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      <span>Employee Export Limit & Protection Policy</span>
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Prevent unauthorized bulk data extraction. Restrict employee direct downloads and mandate administrator approval for larger datasets.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleSaveExportSettings}
                    disabled={isSavingExportSettings}
                    className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {isSavingExportSettings ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving Policy...</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Export Policy</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-800">
                      Max Records per Direct Export (Quota)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min={100}
                        max={1000000}
                        step={1000}
                        value={exportLimitInput}
                        onChange={(e) => setExportLimitInput(Math.max(100, parseInt(e.target.value) || 0))}
                        className="w-full px-3 py-1.5 text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-medium">
                        rows
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                      {[500, 1000, 5000, 10000, 25000, 50000].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setExportLimitInput(preset)}
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors cursor-pointer ${
                            exportLimitInput === preset
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {preset >= 1000 ? `${preset / 1000}k` : `${preset}`}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-800">
                      Approval Enforcement
                    </label>
                    <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-slate-200 bg-slate-50/60 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={exportSettings.requireApprovalAboveLimit}
                        onChange={(e) =>
                          setExportSettings((prev) => ({
                            ...prev,
                            requireApprovalAboveLimit: e.target.checked,
                          }))
                        }
                        className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                      />
                      <div>
                        <span className="text-xs font-semibold text-slate-800 block">
                          Require Admin Approval
                        </span>
                        <span className="text-[10px] text-slate-500 block">
                          Block direct employee download above quota & prompt "Ask Approval"
                        </span>
                      </div>
                    </label>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-800">
                      Employee Export Access
                    </label>
                    <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-slate-200 bg-slate-50/60 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={exportSettings.allowEmployeeDownload}
                        onChange={(e) =>
                          setExportSettings((prev) => ({
                            ...prev,
                            allowEmployeeDownload: e.target.checked,
                          }))
                        }
                        className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                      />
                      <div>
                        <span className="text-xs font-semibold text-slate-800 block">
                          Allow Employee Exports
                        </span>
                        <span className="text-[10px] text-slate-500 block">
                          Toggle whether employees can download permitted columns at all
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Section 2: Pending Approval Requests Queue */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden space-y-0">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Pending Export Requests ({exportRequests.filter((r) => r.status === 'PENDING').length})
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={loadExportsData}
                    disabled={isLoadingExports}
                    className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
                    title="Refresh Requests"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingExports ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {isLoadingExports ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span>Loading approval requests...</span>
                  </div>
                ) : exportRequests.filter((r) => r.status === 'PENDING').length === 0 ? (
                  <div className="py-10 text-center text-slate-400 space-y-1">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto stroke-1" />
                    <p className="text-xs font-semibold text-slate-700">No Pending Requests</p>
                    <p className="text-[11px] text-slate-400">
                      All employee bulk export requests have been reviewed.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {exportRequests
                      .filter((r) => r.status === 'PENDING')
                      .map((req) => (
                        <div key={req.id} className="p-4 hover:bg-slate-50/60 transition-colors space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs font-bold text-slate-900">{req.id}</span>
                                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                                  {req.requested_count.toLocaleString()} rows requested
                                </span>
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-100 text-slate-600">
                                  {req.file_format}
                                </span>
                              </div>
                              <p className="text-xs text-slate-700 mt-1 font-medium">{req.reason}</p>
                              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                                <span>Requested by: <strong className="text-slate-700">{req.user_name}</strong> ({req.user_email})</span>
                                <span>·</span>
                                <span>{new Date(req.created_at).toLocaleString()}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                disabled={reviewingId === req.id}
                                onClick={() => handleReviewRequest(req.id, 'APPROVED')}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                              >
                                {reviewingId === req.id ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                )}
                                <span>Approve Export</span>
                              </button>

                              <button
                                type="button"
                                disabled={reviewingId === req.id}
                                onClick={() => {
                                  const reason = prompt('Please enter rejection reason (optional):', 'Export volume too large, refine search query first');
                                  if (reason !== null) {
                                    handleReviewRequest(req.id, 'REJECTED', reason);
                                  }
                                }}
                                className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                              >
                                <XCircle className="w-3.5 h-3.5 inline mr-1" />
                                <span>Reject</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* Section 3: Review History */}
              {exportRequests.some((r) => r.status !== 'PENDING') && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                  <div className="p-3.5 bg-slate-50 border-b border-slate-200">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Recent Approval Decisions & Audit Log
                    </h4>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
                    {exportRequests
                      .filter((r) => r.status !== 'PENDING')
                      .slice(0, 10)
                      .map((req) => (
                        <div key={req.id} className="p-3 text-xs flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-semibold text-slate-800">{req.id}</span>
                              <span className="text-slate-500 font-mono text-[11px]">
                                {req.requested_count.toLocaleString()} leads ({req.user_name})
                              </span>
                            </div>
                            {req.admin_note && (
                              <p className="text-[11px] text-slate-500 mt-0.5">Note: {req.admin_note}</p>
                            )}
                          </div>
                          <div>
                            {req.status === 'APPROVED' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                Approved by {req.reviewed_by || 'Admin'}
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                                Rejected
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: DOWNLOAD AUDIT LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Export Compliance Audit Trail
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Immutable log of each CSV export including user, timestamp, records downloaded, and filter parameters
                  </p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={logsSearchTerm}
                    onChange={(e) => setLogsSearchTerm(e.target.value)}
                    placeholder="Search logs by user or filter..."
                    className="w-full pl-8 pr-3 py-1 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
                  />
                </div>
              </div>

              {/* Logs Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                {isLoadingLogs ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500 text-xs">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span>Loading audit records...</span>
                  </div>
                ) : filteredLogs.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 space-y-1">
                    <ClipboardList className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-xs font-semibold text-slate-700">No export logs recorded</p>
                    <p className="text-[11px] text-slate-400">
                      When users export leads from the Lead Explorer, every action is logged here.
                    </p>
                  </div>
                ) : (
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold text-[11px]">
                        <th className="py-2.5 px-4">User</th>
                        <th className="py-2.5 px-3">Role</th>
                        <th className="py-2.5 px-3">Campaign</th>
                        <th className="py-2.5 px-3">Records</th>
                        <th className="py-2.5 px-4">Filter Parameters</th>
                        <th className="py-2.5 px-4 text-right">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-2.5 px-4">
                            <span className="font-semibold text-slate-900 block">{log.userName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{log.userEmail}</span>
                          </td>

                          <td className="py-2.5 px-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                              {log.userRole}
                            </span>
                          </td>

                          <td className="py-2.5 px-3">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 max-w-[150px]">
                              <Target className="w-3 h-3 text-emerald-600 shrink-0" />
                              <span className="truncate" title={log.campaignName || 'General Outreach'}>
                                {log.campaignName || 'General Outreach'}
                              </span>
                            </span>
                          </td>

                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                            <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[11px]">
                              {log.recordCount.toLocaleString()} leads
                            </span>
                          </td>

                          <td className="py-2.5 px-4 text-slate-600 max-w-xs truncate" title={log.filtersSummary}>
                            {log.filtersSummary || 'All records'}
                          </td>

                          <td className="py-2.5 px-4 text-right text-[11px] font-mono text-slate-500 whitespace-nowrap">
                            {new Date(log.timestamp).toLocaleString([], {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: DATABASE & SYNC */}
          {activeTab === 'database' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <span>Database Engine & Live Condition Monitor</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Real-time database health, dynamic schema inspector, latency diagnostics, and problem detector
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={loadDatabaseStatus}
                    disabled={isLoadingDbStatus}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer disabled:opacity-50"
                    title="Refresh live status from database"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${isLoadingDbStatus ? 'animate-spin text-blue-600' : ''}`} />
                    <span>{isLoadingDbStatus ? 'Checking...' : 'Refresh Status'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRunDiagnostics}
                    disabled={isTestingDb}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {isTestingDb ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Running Test...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        <span>Run Diagnostics Ping</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {dbNotice && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{dbNotice}</span>
                </div>
              )}

              {/* 1. Primary DB Cluster Specs Card */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-xs">
                      <HardDrive className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold font-mono text-slate-900 block tracking-tight">
                          {dbStatus?.serverName || 'ALLTAKE-HYPERSCALE-DB-PRIMARY'}
                        </span>
                        <span className="px-2 py-0.2 rounded-full text-[9px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                          Primary Node
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500 font-medium">
                        {dbStatus?.engine || 'PostgreSQL Enterprise Columnar Engine v16.5 & High-Speed Memory Indexer'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border flex items-center gap-1.5 ${
                      (dbStatus?.totalRecords ?? 0) > 0
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        (dbStatus?.totalRecords ?? 0) > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-blue-500'
                      }`} />
                      <span>{dbStatus?.status || 'ONLINE'}</span>
                    </span>
                  </div>
                </div>

                {/* Condition Banner */}
                <div className="px-3.5 py-2 rounded-lg bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Activity className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span className="font-semibold text-slate-900">Current DB Condition:</span>
                    <span className="text-slate-600">{dbStatus?.conditionText || 'Optimal Condition · 100% Query Consistency'}</span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-400">
                    Checked {new Date(dbStatus?.lastHealthCheck || Date.now()).toLocaleTimeString()}
                  </span>
                </div>

                {/* 4 Metric Columns */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Total Records in DB</span>
                    <span className="font-mono font-bold text-base text-slate-900">
                      {(dbStatus?.totalRecords ?? 0).toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Verified leads</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Dynamic Columns</span>
                    <span className="font-mono font-bold text-base text-blue-600">
                      {dbStatus?.columnsCount ?? 0} Fields
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">No 31-column limit</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Read / Write Latency</span>
                    <span className="font-mono font-bold text-xs text-emerald-700 block mt-1">
                      {dbStatus?.readLatencyMs ?? 1.2}ms Read · {dbStatus?.writeLatencyMs ?? 2.4}ms Write
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Ultra-low latency</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                    <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Storage Footprint</span>
                    <span className="font-mono font-bold text-xs text-slate-800 block mt-1">
                      {dbStatus?.memoryUsageMb ?? '0.00 MB'}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">TLS v1.3 + AES-256</span>
                  </div>
                </div>

                {/* Database Endpoint References */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Host:</span>
                    <span className="font-mono font-semibold text-slate-800">{dbStatus?.host || 'db-node-01.alltake.internal:5432'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Database Name:</span>
                    <span className="font-mono font-semibold text-slate-800">{dbStatus?.database || 'alltake_master_production_vault'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Table Catalog:</span>
                    <span className="font-mono font-semibold text-slate-800">{dbStatus?.table || 'enterprise_leads_dataset'}</span>
                  </div>
                </div>
              </div>

              {/* 2. LIVE DIAGNOSTIC RESULT BANNER (If diagnostic ping was executed) */}
              {diagnosticResult && (
                <div className="p-4 bg-emerald-50/90 border border-emerald-200 rounded-xl space-y-2 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-bold text-emerald-950">Diagnostic Ping Verification Complete</span>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-700 font-bold bg-emerald-100/80 px-2 py-0.5 rounded">
                      Status: {diagnosticResult.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-800">
                    {diagnosticResult.message}
                  </p>
                  <div className="grid grid-cols-3 gap-2 pt-2 text-[10px] font-mono border-t border-emerald-200/80">
                    <div>Read Check: <strong className="text-emerald-900">{diagnosticResult.readCheck}</strong></div>
                    <div>Write Check: <strong className="text-emerald-900">{diagnosticResult.writeCheck}</strong></div>
                    <div>Integrity: <strong className="text-emerald-900">{diagnosticResult.indexIntegrity}</strong></div>
                  </div>
                </div>
              )}

              {/* 3. DATABASE CONDITION & PROBLEM DETECTOR (What problem exists in DB) */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    <h4 className="text-xs font-bold text-slate-900">
                      Live Database Condition & Problem Inspector
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">
                    Automated Data Integrity Scanner
                  </span>
                </div>

                {dbStatus?.issues && dbStatus.issues.length > 0 ? (
                  <div className="space-y-2">
                    {dbStatus.issues.map((issue, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border text-xs space-y-1 ${
                          issue.severity === 'critical'
                            ? 'bg-rose-50 border-rose-200 text-rose-900'
                            : issue.severity === 'warning'
                            ? 'bg-amber-50 border-amber-200 text-amber-900'
                            : 'bg-blue-50 border-blue-200 text-blue-900'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold flex items-center gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            <span>{issue.title}</span>
                          </span>
                          <span className="font-mono text-[9px] uppercase px-1.5 py-0.2 rounded font-semibold bg-white/80 border border-current">
                            {issue.code || issue.severity}
                          </span>
                        </div>
                        <p className="text-[11px] leading-relaxed opacity-90">
                          {issue.message}
                        </p>
                        {issue.suggestion && (
                          <p className="text-[10px] font-semibold opacity-80 pt-0.5">
                            Recommendation: {issue.suggestion}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      Zero database problems detected. All record indexes, schema integrity, and query routing are 100% operational.
                    </span>
                  </div>
                )}
              </div>

              {/* 4. Active Column Catalog Preview */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600" />
                    <h4 className="text-xs font-bold text-slate-900">
                      Dynamic Columns Active in Database ({columnsList.length})
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Configurable via Column Layout & Order tab
                  </span>
                </div>

                <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-slate-50 rounded-lg border border-slate-100">
                  {columnsList.map((col, i) => (
                    <span
                      key={col.key}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 rounded text-[11px] text-slate-700 shadow-2xs"
                    >
                      <span className="font-mono text-[9px] font-bold text-slate-400">#{col.order ?? (i + 1)}</span>
                      <span className="font-medium">{col.label}</span>
                      <span className="text-[9px] font-mono text-blue-600 px-1 py-0.2 bg-blue-50 rounded">
                        {col.type}
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* 5. Direct Fetch & Sync Action */}
              <div className="p-4 bg-gradient-to-br from-blue-50/80 to-indigo-50/50 rounded-xl border border-blue-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-blue-950">
                    1-Click Direct Fetch & Sync from Database
                  </h4>
                  <p className="text-[11px] text-blue-800/80">
                    Refreshes your client data cache directly from the backend server database
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleSyncDatabase}
                  disabled={isSyncing}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50 transition-colors"
                >
                  {isSyncing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Syncing ({syncProgress}%)...</span>
                    </>
                  ) : (
                    <>
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>Fetch & Sync Now</span>
                    </>
                  )}
                </button>
              </div>

              {/* 6. Purge / Clean Reset Database */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">
                    Clean Database Mode — Purge All Records
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Wipes existing or sample records completely so database starts at clean 0 records
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handlePurgeSeeds}
                  disabled={isPurging}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isPurging ? 'Purging...' : 'Purge All Records'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Alltake Data Core Software · Admin Control Center</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close Settings
          </button>
        </div>
      </div>

      {/* Password Reset Submodal */}
      {resettingUser && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-5 py-3.5 bg-blue-50/70 border-b border-blue-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Reset User Password</h3>
                  <p className="text-[10px] text-slate-500">
                    Administrator Credential Override · Instant Security Update
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setResettingUser(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmReset} className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="text-slate-500 font-medium">Target User:</span>
                  <span className="font-bold text-slate-900">{resettingUser.full_name}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="text-slate-500 font-medium">Email / Username:</span>
                  <span className="font-mono text-slate-700">{resettingUser.email} (@{resettingUser.username})</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-medium">Account Role:</span>
                  <span className="font-semibold text-blue-700">{resettingUser.role}</span>
                </div>
              </div>

              {resetSuccessMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold block">Password Updated Successfully!</span>
                    <span className="text-[11px] text-emerald-700">{resetSuccessMsg}</span>
                  </div>
                </div>
              )}

              {resetErrorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-medium">{resetErrorMsg}</span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    New Password *
                  </label>
                  <button
                    type="button"
                    onClick={handleGeneratePassword}
                    className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Auto-Generate</span>
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showResetPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full pl-3 pr-20 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setShowResetPassword(!showResetPassword)}
                      className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      title={showResetPassword ? 'Hide password' : 'Show password'}
                    >
                      {showResetPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyPassword}
                      className="p-1 text-slate-400 hover:text-blue-600 cursor-pointer"
                      title="Copy password"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                {copied && (
                  <span className="text-[10px] text-emerald-600 font-medium block mt-1">
                    ✓ Password copied to clipboard
                  </span>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setResettingUser(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isResetting || !newPassword.trim()}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isResetting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Updating Database...</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Confirm & Save Password</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

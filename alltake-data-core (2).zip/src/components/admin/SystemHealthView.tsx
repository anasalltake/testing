import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../api/client';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { Badge } from '../common/Badge';
import {
  Server,
  Database,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  HardDrive,
  Cpu,
  Layers,
  Shield,
} from 'lucide-react';

export const SystemHealthView: React.FC = () => {
  const [healthData, setHealthData] = useState<any>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [checkTime, setCheckTime] = useState<string>('');

  const checkConnection = async () => {
    setIsChecking(true);
    try {
      const res = await apiRequest('/health');
      setHealthData(res);
      setCheckTime(new Date().toLocaleTimeString());
    } catch (err: any) {
      setHealthData({ status: 'unhealthy', database: 'disconnected', error: err.message });
      setCheckTime(new Date().toLocaleTimeString());
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    checkConnection();
  }, []);

  const isConnected = healthData?.database === 'connected' && healthData?.status === 'healthy';

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-blue-600" />
            <h1 className="text-base font-bold text-slate-900 tracking-tight">
              Database & System Diagnostics
            </h1>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            PostgreSQL connectivity verification, SQLAlchemy engine parameters, and migration checks
          </p>
        </div>

        <button
          onClick={checkConnection}
          disabled={isChecking}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md shadow-2xs transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
          <span>Test Database Link</span>
        </button>
      </div>

      {/* Main Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* PostgreSQL Connection State */}
        <div className="bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase font-mono">
              PostgreSQL Service
            </span>
            <Database className="w-4 h-4 text-slate-400" />
          </div>

          <div className="mt-3 flex items-center gap-2">
            {isConnected ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span className="text-sm font-bold text-emerald-700">CONNECTED & VERIFIED</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-5 h-5 text-rose-600" />
                <span className="text-sm font-bold text-rose-700">AWAITING DB CONFIG</span>
              </>
            )}
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">
            {checkTime ? `Last check: ${checkTime}` : 'Executing query check...'}
          </p>
        </div>

        {/* SQLAlchemy Engine Configuration */}
        <div className="bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase font-mono">
              Driver / ORM Stack
            </span>
            <Cpu className="w-4 h-4 text-slate-400" />
          </div>

          <div className="mt-3">
            <span className="text-sm font-bold text-slate-900 font-mono">
              SQLAlchemy 2.0 + Psycopg
            </span>
            <p className="text-[11px] text-slate-500 mt-1">
              Connection Pool: 20 connections (10 overflow)
            </p>
          </div>
        </div>

        {/* Schema Migration Status */}
        <div className="bg-white p-4 rounded-lg border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase font-mono">
              Alembic Migrations
            </span>
            <Layers className="w-4 h-4 text-slate-400" />
          </div>

          <div className="mt-3">
            <span className="text-sm font-bold text-blue-700 font-mono">
              001_initial_schema
            </span>
            <p className="text-[11px] text-slate-500 mt-1">
              8 Managed Tables • Automatic Schema Tracking
            </p>
          </div>
        </div>
      </div>

      {/* Database Schema Objects Checklist */}
      <div className="bg-white rounded-lg border border-slate-200/90 p-4 shadow-2xs space-y-3">
        <h3 className="text-xs font-semibold text-slate-800 uppercase font-mono tracking-wider">
          Managed Database Entities
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
          {[
            { name: 'users', desc: 'RBAC accounts & bcrypt hashes' },
            { name: 'datasets', desc: 'Dataset manifests & row counters' },
            { name: 'dataset_columns', desc: 'Dynamic column schema registry' },
            { name: 'dataset_records', desc: 'High-speed indexed lead records' },
            { name: 'upload_jobs', desc: 'Chunked bulk upload tracking' },
            { name: 'download_jobs', desc: 'Background export jobs & filters' },
            { name: 'audit_logs', desc: 'Immutable compliance trail' },
            { name: 'login_logs', desc: 'Authentication attempts & IPs' },
          ].map((table) => (
            <div
              key={table.name}
              className="p-2.5 rounded bg-slate-50 border border-slate-200/70"
            >
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                {table.name}
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5 font-sans truncate">{table.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

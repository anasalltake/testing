import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  Users,
  ShieldCheck,
  ShieldAlert,
  Ban,
  CheckCircle2,
  Trash2,
  Mail,
  User,
  KeyRound,
  AlertCircle,
  Loader2,
  Copy,
  Check,
  Eye,
  EyeOff,
  RefreshCw,
  Lock
} from 'lucide-react';
import { EnterpriseUser, UserRole } from '../../types/enterprise';
import {
  getAllUsers,
  createEnterpriseUser,
  toggleBlockUser,
  deleteEnterpriseUser,
  resetEnterpriseUserPassword
} from '../../services/enterpriseDb';

interface EmployeeManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

export const EmployeeManagementModal: React.FC<EmployeeManagementModalProps> = ({
  isOpen,
  onClose,
  onNotify,
}) => {
  const [users, setUsers] = useState<EnterpriseUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);

  // Password reset dialog state
  const [resettingUser, setResettingUser] = useState<EnterpriseUser | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [isResetting, setIsResetting] = useState(false);
  const [resetSuccessMsg, setResetSuccessMsg] = useState<string | null>(null);
  const [resetErrorMsg, setResetErrorMsg] = useState<string | null>(null);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [copied, setCopied] = useState(false);

  // New user form state
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('EMPLOYEE');
  const [formError, setFormError] = useState<string | null>(null);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const list = await getAllUsers();
      setUsers(list);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!fullName.trim() || !email.trim() || !username.trim()) {
      setFormError('Please fill in all required fields');
      return;
    }

    // Check duplicate email
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase().trim())) {
      setFormError('A user with this email address already exists');
      return;
    }

    try {
      await createEnterpriseUser({
        full_name: fullName.trim(),
        email: email.trim().toLowerCase(),
        username: username.trim().toLowerCase(),
        role,
        status: 'ACTIVE',
        created_by: 'admin',
      });

      onNotify(`Created new user ${fullName.trim()} (${role}) successfully`);
      setFullName('');
      setEmail('');
      setUsername('');
      setPassword('');
      setIsCreating(false);
      await loadUsers();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create user');
    }
  };

  const handleToggleBlock = async (userId: string, currentStatus: string, name: string) => {
    const updated = await toggleBlockUser(userId);
    if (updated) {
      const newStatus = updated.status;
      onNotify(
        newStatus === 'BLOCKED'
          ? `User ${name} has been BLOCKED from logging in`
          : `User ${name} has been UNBLOCKED and restored`
      );
      await loadUsers();
    }
  };

  const handleDelete = async (userId: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete user ${name}? This action is irreversible.`)) {
      await deleteEnterpriseUser(userId);
      onNotify(`Deleted user ${name}`);
      await loadUsers();
    }
  };

  const handleOpenReset = (u: EnterpriseUser) => {
    setResettingUser(u);
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pwd = 'Alltake@';
    for (let i = 0; i < 6; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPassword(pwd);
    setResetSuccessMsg(null);
    setResetErrorMsg(null);
    setCopied(false);
  };

  const handleConfirmReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resettingUser || !newPassword.trim()) return;
    setIsResetting(true);
    setResetErrorMsg(null);
    try {
      const res = await resetEnterpriseUserPassword(resettingUser.id, newPassword.trim());
      setResetSuccessMsg(res.message || 'Password successfully updated');
      onNotify(`Password reset for ${resettingUser.full_name}. New password: ${newPassword.trim()}`);
    } catch (err: any) {
      setResetErrorMsg(err.message || 'Failed to reset password');
    } finally {
      setIsResetting(false);
    }
  };

  const handleGeneratePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pwd = 'Alltake@';
    for (let i = 0; i < 6; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPassword(pwd);
    setCopied(false);
  };

  const handleCopyPassword = () => {
    navigator.clipboard.writeText(newPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-blue-50/50 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                Employee & User Management
              </h2>
              <p className="text-xs text-slate-500">
                Create new team members, manage credentials, and block login access
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreating(!isCreating)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{isCreating ? 'View User List' : 'Create New Employee'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {isCreating ? (
            /* Create New User Form */
            <form onSubmit={handleCreateUser} className="space-y-4 max-w-xl mx-auto py-2">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  New Team Member Details
                </h3>
                <p className="text-[11px] text-slate-500">
                  New accounts can immediately log in unless blocked by Admin.
                </p>
              </div>

              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Work Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="rahul@alltake.com"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Username *
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="rahul"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Initial Password
                  </label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password@2026"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Assigned System Role *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      role === 'EMPLOYEE'
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-semibold shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="role"
                      checked={role === 'EMPLOYEE'}
                      onChange={() => setRole('EMPLOYEE')}
                      className="text-blue-600"
                    />
                    <div>
                      <span className="block text-xs font-bold">Employee</span>
                      <span className="text-[10px] text-slate-500 font-normal">
                        Filtered lead view, restricted fields & export
                      </span>
                    </div>
                  </label>

                  <label
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      role === 'DATA_MANAGER'
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-semibold shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="role"
                      checked={role === 'DATA_MANAGER'}
                      onChange={() => setRole('DATA_MANAGER')}
                      className="text-blue-600"
                    />
                    <div>
                      <span className="block text-xs font-bold">Data Manager</span>
                      <span className="text-[10px] text-slate-500 font-normal">
                        Daily CSV/Excel uploads & dataset schema
                      </span>
                    </div>
                  </label>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreating(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  Create & Save Employee
                </button>
              </div>
            </form>
          ) : (
            /* User Listing Table with Block / Unblock Controls */
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Total Registered Accounts: {users.length}</span>
                <span className="text-[11px] text-blue-600 font-medium">
                  Blocked accounts cannot authenticate or access lead data
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3">Team Member</th>
                      <th className="px-3 py-3">Username</th>
                      <th className="px-3 py-3">Role</th>
                      <th className="px-3 py-3">Login Status</th>
                      <th className="px-4 py-3 text-right">Admin Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {users.map((u) => {
                      const isBlocked = u.status === 'BLOCKED';
                      const isAdmin = u.role === 'ADMIN';

                      return (
                        <tr
                          key={u.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            isBlocked ? 'bg-rose-50/30' : ''
                          }`}
                        >
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2.5">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                                  isAdmin
                                    ? 'bg-blue-600 text-white'
                                    : isBlocked
                                    ? 'bg-rose-100 text-rose-700'
                                    : 'bg-indigo-100 text-indigo-700'
                                }`}
                              >
                                {u.full_name.charAt(0) || 'U'}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 block">
                                  {u.full_name}
                                </span>
                                <span className="text-[11px] text-slate-500 font-mono">
                                  {u.email}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="px-3 py-3 font-mono text-[11px] text-slate-600">
                            {u.username}
                          </td>

                          <td className="px-3 py-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                u.role === 'ADMIN'
                                  ? 'bg-blue-100 text-blue-800'
                                  : u.role === 'DATA_MANAGER'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-indigo-100 text-indigo-800'
                              }`}
                            >
                              {u.role}
                            </span>
                          </td>

                          <td className="px-3 py-3">
                            {isBlocked ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-200">
                                <Ban className="w-3 h-3" />
                                BLOCKED
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3" />
                                ACTIVE
                              </span>
                            )}
                          </td>

                          <td className="px-4 py-3 text-right">
                            {!isAdmin ? (
                              <div className="flex items-center justify-end gap-1.5">
                                {/* Reset Password Button */}
                                <button
                                  type="button"
                                  onClick={() => handleOpenReset(u)}
                                  className="px-2 py-1 text-xs font-semibold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 flex items-center gap-1 cursor-pointer transition-colors"
                                  title="Reset password for this employee"
                                >
                                  <KeyRound className="w-3 h-3 text-blue-600" />
                                  <span>Reset Pwd</span>
                                </button>

                                {/* Block / Unblock Toggle Button */}
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleToggleBlock(u.id, u.status, u.full_name)
                                  }
                                  className={`px-2.5 py-1 rounded text-xs font-semibold border transition-all ${
                                    isBlocked
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                      : 'bg-rose-50 text-rose-700 border-rose-300 hover:bg-rose-100'
                                  }`}
                                  title={
                                    isBlocked
                                      ? 'Unblock user to allow login'
                                      : 'Block user from logging in'
                                  }
                                >
                                  {isBlocked ? 'Unblock Login' : 'Block Login'}
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleDelete(u.id, u.full_name)}
                                  className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                                  title="Delete user"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleOpenReset(u)}
                                  className="px-2 py-1 text-xs font-semibold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 flex items-center gap-1 cursor-pointer transition-colors"
                                  title="Change admin master password"
                                >
                                  <KeyRound className="w-3 h-3 text-blue-600" />
                                  <span>Reset Pwd</span>
                                </button>
                                <span className="text-[10px] text-slate-400 italic">
                                  Primary Admin
                                </span>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Security Layer: Active Session Verification on every query</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>

      {/* Admin Password Reset Dialog Modal */}
      {resettingUser && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-linear-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-md flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">Reset User Password</h3>
                  <p className="text-[11px] text-blue-100">
                    Administrator Security Override
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setResettingUser(null)}
                className="p-1 rounded-lg hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmReset} className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">Target User:</span>
                  <span className="text-xs font-bold text-slate-800">{resettingUser.full_name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">Username / Email:</span>
                  <span className="text-xs font-mono text-slate-700">@{resettingUser.username} ({resettingUser.email})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">Role:</span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">{resettingUser.role}</span>
                </div>
              </div>

              {resetSuccessMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-start gap-2">
                  <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                  <div>
                    <span className="font-bold block">Password Reset Successful!</span>
                    <span className="text-[11px]">{resetSuccessMsg}</span>
                  </div>
                </div>
              )}

              {resetErrorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                  <div>
                    <span className="font-bold block">Reset Failed</span>
                    <span className="text-[11px]">{resetErrorMsg}</span>
                  </div>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    New Password *
                  </label>
                  <button
                    type="button"
                    onClick={handleGeneratePassword}
                    className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Auto-Generate</span>
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showResetPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full pl-3 pr-20 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setShowResetPassword(!showResetPassword)}
                      className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                      title={showResetPassword ? 'Hide password' : 'Show password'}
                    >
                      {showResetPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyPassword}
                      className="p-1 text-slate-400 hover:text-blue-600 cursor-pointer"
                      title="Copy password"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                {copied && (
                  <span className="text-[10px] text-emerald-600 font-medium block mt-1">
                    ✓ Password copied to clipboard
                  </span>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setResettingUser(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isResetting || !newPassword.trim()}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isResetting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Updating Database...</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Confirm & Save Password</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

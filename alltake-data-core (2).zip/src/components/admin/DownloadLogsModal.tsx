import React, { useState, useEffect } from 'react';
import {
  X,
  FileSpreadsheet,
  Download,
  Search,
  Filter,
  Calendar,
  User,
  ShieldCheck,
  RotateCcw,
  Clock
} from 'lucide-react';
import { DownloadAuditLog } from '../../types/enterprise';
import { getAllDownloadLogs } from '../../services/enterpriseDb';

interface DownloadLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadLogsModal: React.FC<DownloadLogsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [logs, setLogs] = useState<DownloadAuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const data = await getAllDownloadLogs();
      setLogs(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadLogs();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredLogs = logs.filter((log) => {
    if (!searchTerm) return true;
    const q = searchTerm.toLowerCase();
    return (
      log.userName.toLowerCase().includes(q) ||
      log.userEmail.toLowerCase().includes(q) ||
      log.filtersSummary.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-blue-50/50 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                Employee Download & Query Audit Logs
              </h2>
              <p className="text-xs text-slate-500">
                Compliance trail tracking every employee lead download with exact filters applied
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Toolbar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 text-xs">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by employee name, email, or filter..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            />
          </div>

          <div className="flex items-center gap-2 text-slate-600 font-mono text-[11px]">
            <span>Total Export Events:</span>
            <span className="font-bold text-blue-600">{logs.length}</span>
          </div>
        </div>

        {/* Logs Table */}
        <div className="p-6 overflow-y-auto flex-1">
          {filteredLogs.length > 0 ? (
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Timestamp</th>
                    <th className="px-4 py-3">Employee Name</th>
                    <th className="px-3 py-3">Records Exported</th>
                    <th className="px-4 py-3">Filters Applied by Employee</th>
                    <th className="px-3 py-3">Format</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {filteredLogs.map((log) => {
                    const date = new Date(log.timestamp);
                    const formattedDate = date.toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    });
                    const formattedTime = date.toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    });

                    return (
                      <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Timestamp */}
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-slate-700">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span className="font-medium">{formattedDate}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono pl-5">
                            {formattedTime}
                          </span>
                        </td>

                        {/* Employee */}
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0">
                              {log.userName.charAt(0) || 'E'}
                            </div>
                            <div>
                              <span className="font-bold text-slate-900 block truncate">
                                {log.userName}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                {log.userEmail}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Records Count */}
                        <td className="px-3 py-3">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold font-mono bg-blue-50 text-blue-800 border border-blue-200">
                            {log.recordCount.toLocaleString()} leads
                          </span>
                        </td>

                        {/* Filter Summary */}
                        <td className="px-4 py-3 max-w-xs">
                          <div className="p-1.5 bg-slate-50 rounded border border-slate-200 font-mono text-[11px] text-slate-700 line-clamp-2" title={log.filtersSummary}>
                            {log.filtersSummary || 'No filters applied'}
                          </div>
                        </td>

                        {/* Format */}
                        <td className="px-3 py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 font-mono">
                            {log.format}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <FileSpreadsheet className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-xs font-medium">No download events logged yet</p>
              <p className="text-[11px] text-slate-400 mt-1">
                When employees filter and download datasets, logs will appear here automatically.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>All logs are permanently retained in IndexedDB database</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

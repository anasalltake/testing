import React, { useState, useEffect } from 'react';
import {
  X,
  Eye,
  EyeOff,
  Sliders,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { FieldVisibilityRule } from '../../types/enterprise';
import { getFieldVisibilityRules, updateFieldVisibilityRule } from '../../services/enterpriseDb';

interface FieldVisibilitySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRulesChanged: () => void;
}

export const FieldVisibilitySettingsModal: React.FC<FieldVisibilitySettingsModalProps> = ({
  isOpen,
  onClose,
  onRulesChanged,
}) => {
  const [rules, setRules] = useState<FieldVisibilityRule[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadRules = async () => {
    setIsLoading(true);
    try {
      const list = await getFieldVisibilityRules();
      setRules(list);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadRules();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUpdate = async (columnKey: string, visibility: 'VISIBLE' | 'MASKED' | 'HIDDEN') => {
    await updateFieldVisibilityRule(columnKey, visibility);
    setRules((prev) =>
      prev.map((r) => (r.columnKey === columnKey ? { ...r, employeeVisibility: visibility } : r))
    );
    onRulesChanged();
  };

  const handleApplyPreset = async (preset: 'strict_pii' | 'all_visible' | 'hide_contacts') => {
    for (const r of rules) {
      let vis: 'VISIBLE' | 'MASKED' | 'HIDDEN' = 'VISIBLE';

      if (preset === 'strict_pii') {
        if (['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(r.columnKey)) {
          vis = 'MASKED';
        }
      } else if (preset === 'hide_contacts') {
        if (['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(r.columnKey)) {
          vis = 'HIDDEN';
        }
      }

      await updateFieldVisibilityRule(r.columnKey, vis);
    }
    await loadRules();
    onRulesChanged();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-blue-50/50 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-tight">
                Employee Field Visibility & Masking Rules
              </h2>
              <p className="text-xs text-slate-500">
                Choose what data columns employees can see, view blurred, or have completely hidden
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Presets Bar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 text-xs">
          <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
            Quick Compliance Presets:
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleApplyPreset('strict_pii')}
              className="px-2.5 py-1 rounded-md bg-white border border-slate-300 hover:border-blue-500 text-slate-700 text-xs font-medium shadow-2xs"
            >
              Strict PII Masked
            </button>
            <button
              onClick={() => handleApplyPreset('hide_contacts')}
              className="px-2.5 py-1 rounded-md bg-white border border-slate-300 hover:border-blue-500 text-slate-700 text-xs font-medium shadow-2xs"
            >
              Hide Phone & Email
            </button>
            <button
              onClick={() => handleApplyPreset('all_visible')}
              className="px-2.5 py-1 rounded-md bg-white border border-slate-300 hover:border-blue-500 text-slate-700 text-xs font-medium shadow-2xs"
            >
              All Visible
            </button>
          </div>
        </div>

        {/* Rules Table */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          <p className="text-xs text-slate-500">
            Note: When an employee exports data (CSV), all fields are exported with full details, but their in-app browsing view is restricted based on these rules.
          </p>

          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Database Column Name</th>
                  <th className="px-3 py-3 text-center">Visible</th>
                  <th className="px-3 py-3 text-center">Masked (Blurred)</th>
                  <th className="px-3 py-3 text-center">Hidden</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {rules.map((rule) => {
                  const isSensitive = ['emailAddress', 'companyPhone', 'directNumber', 'otherNumber'].includes(
                    rule.columnKey
                  );

                  return (
                    <tr key={rule.columnKey} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900">
                            {rule.columnLabel}
                          </span>
                          {isSensitive && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800">
                              PII
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {rule.columnKey}
                        </span>
                      </td>

                      {/* Visible */}
                      <td className="px-3 py-2.5 text-center">
                        <input
                          type="radio"
                          name={`vis_${rule.columnKey}`}
                          checked={rule.employeeVisibility === 'VISIBLE'}
                          onChange={() => handleUpdate(rule.columnKey, 'VISIBLE')}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                      </td>

                      {/* Masked */}
                      <td className="px-3 py-2.5 text-center">
                        <input
                          type="radio"
                          name={`vis_${rule.columnKey}`}
                          checked={rule.employeeVisibility === 'MASKED'}
                          onChange={() => handleUpdate(rule.columnKey, 'MASKED')}
                          className="w-4 h-4 text-amber-600 focus:ring-amber-500 cursor-pointer"
                        />
                      </td>

                      {/* Hidden */}
                      <td className="px-3 py-2.5 text-center">
                        <input
                          type="radio"
                          name={`vis_${rule.columnKey}`}
                          checked={rule.employeeVisibility === 'HIDDEN'}
                          onChange={() => handleUpdate(rule.columnKey, 'HIDDEN')}
                          className="w-4 h-4 text-rose-600 focus:ring-rose-500 cursor-pointer"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Changes are saved immediately and applied to employee sessions</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 font-bold text-white bg-blue-600 rounded-lg hover:bg-blue-700 shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

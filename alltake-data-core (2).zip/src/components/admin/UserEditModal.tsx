import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Mail,
  Lock,
  Shield,
  KeyRound,
  Check,
  AlertCircle,
  Loader2,
  RefreshCw,
  Copy
} from 'lucide-react';
import { EnterpriseUser } from '../../types/enterprise';
import { updateEnterpriseUser } from '../../services/enterpriseDb';

interface UserEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: EnterpriseUser | null;
  onSuccess: (updatedUser: EnterpriseUser, msg: string) => void;
}

export const UserEditModal: React.FC<UserEditModalProps> = ({
  isOpen,
  onClose,
  user,
  onSuccess,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<'ADMIN' | 'DATA_MANAGER' | 'EMPLOYEE'>('EMPLOYEE');
  const [status, setStatus] = useState<'ACTIVE' | 'BLOCKED'>('ACTIVE');
  const [newPassword, setNewPassword] = useState('');
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (user && isOpen) {
      setFullName(user.full_name || '');
      setEmail(user.email || '');
      setUsername(user.username || '');
      setRole((user.role as any) || 'EMPLOYEE');
      setStatus((user.status as any) || 'ACTIVE');
      setNewPassword('');
      setShowPasswordInput(false);
      setCopied(false);
      setErrorMsg(null);
    }
  }, [user, isOpen]);

  if (!isOpen || !user) return null;

  const handleGeneratePassword = () => {
    const specials = '!@#$%&*';
    const uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowers = 'abcdefghijkmnpqrstuvwxyz';
    const digits = '23456789';

    let generated = 'Alltake@';
    for (let i = 0; i < 2; i++) generated += uppers.charAt(Math.floor(Math.random() * uppers.length));
    for (let i = 0; i < 3; i++) generated += lowers.charAt(Math.floor(Math.random() * lowers.length));
    for (let i = 0; i < 2; i++) generated += digits.charAt(Math.floor(Math.random() * digits.length));
    generated += specials.charAt(Math.floor(Math.random() * specials.length));

    setNewPassword(generated);
    setShowPasswordInput(true);
  };

  const handleCopyPassword = () => {
    if (!newPassword) return;
    navigator.clipboard.writeText(newPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fullName.trim() || !email.trim() || !username.trim()) {
      setErrorMsg('Full Name, Email, and Username are required.');
      return;
    }

    if (newPassword && newPassword.length < 6) {
      setErrorMsg('New password must be at least 6 characters.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await updateEnterpriseUser(user.id, {
        full_name: fullName.trim(),
        email: email.trim(),
        username: username.trim().toLowerCase(),
        role,
        status,
        new_password: newPassword ? newPassword.trim() : undefined,
      });

      onSuccess(res.user, res.message || 'Employee account updated successfully.');
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update employee details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fade-in font-sans">
      <div className="w-full max-w-lg bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-[0_24px_60px_rgba(0,0,0,0.18)] p-6 sm:p-7 text-[#1D1D1F] relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 text-[#0071E3] flex items-center justify-center shadow-2xs font-bold text-sm">
              {fullName.slice(0, 2).toUpperCase() || 'EM'}
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1D1D1F] tracking-tight">
                Edit Employee Account
              </h2>
              <p className="text-xs text-slate-500">
                Update credentials, contact information, role permissions, and access status
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0071E3]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0071E3]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Username / Login ID</label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0071E3] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Role Governance Tier</label>
              <select
                value={role}
                onChange={(e: any) => setRole(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0071E3]"
              >
                <option value="EMPLOYEE">Employee (Export Limits & Data Masking)</option>
                <option value="DATA_MANAGER">Data Manager (Dataset Ingestion)</option>
                <option value="ADMIN">Super Administrator (Full Master Control)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Account Access Status</label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  value="ACTIVE"
                  checked={status === 'ACTIVE'}
                  onChange={() => setStatus('ACTIVE')}
                  className="text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Active (Allowed Login)
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  value="BLOCKED"
                  checked={status === 'BLOCKED'}
                  onChange={() => setStatus('BLOCKED')}
                  className="text-rose-600 focus:ring-rose-500"
                />
                <span className="text-xs font-medium text-rose-800 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Suspended (Blocked)
                </span>
              </label>
            </div>
          </div>

          {/* Direct Password Reset Section for Admin */}
          <div className="pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">
                  Direct Password Override
                </span>
              </div>
              <button
                type="button"
                onClick={handleGeneratePassword}
                className="text-[11px] font-semibold text-[#0071E3] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Generate Password</span>
              </button>
            </div>

            <div className="relative">
              <input
                type="text"
                value={newPassword}
                onChange={(e) => {
                  setNewPassword(e.target.value);
                  setShowPasswordInput(true);
                }}
                placeholder="Leave blank to keep existing password, or type new password..."
                className="w-full pr-20 pl-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0071E3] font-mono"
              />
              {newPassword && (
                <button
                  type="button"
                  onClick={handleCopyPassword}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 text-[10px] font-semibold rounded-lg bg-white border border-slate-200 shadow-2xs hover:bg-slate-50 flex items-center gap-1 cursor-pointer text-slate-700"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Admin can set a new password directly without knowing the employee's existing credentials.
            </p>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2 text-xs font-semibold text-white bg-[#0071E3] hover:bg-blue-600 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {isLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>Save Employee Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import {
  X,
  ArrowUp,
  ArrowDown,
  ChevronsUp,
  ChevronsDown,
  Eye,
  EyeOff,
  RotateCcw,
  Search,
  CheckCircle2,
  Sparkles,
  SlidersHorizontal,
  Layers,
  Lock,
  Save,
  Loader2
} from 'lucide-react';
import { EnterpriseColumnDef } from '../../types/enterprise';
import {
  updateColumnOrderAndVisibility,
  resetColumnOrderToDefault
} from '../../services/enterpriseDb';

interface ColumnLayoutManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  columns: EnterpriseColumnDef[];
  onColumnsUpdated: (updated: EnterpriseColumnDef[]) => void;
  onNotify: (msg: string) => void;
}

export const ColumnLayoutManagerModal: React.FC<ColumnLayoutManagerModalProps> = ({
  isOpen,
  onClose,
  columns,
  onColumnsUpdated,
  onNotify,
}) => {
  const [localColumns, setLocalColumns] = useState<EnterpriseColumnDef[]>(() =>
    [...columns].sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Sync with prop when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setLocalColumns([...columns].sort((a, b) => (a.order ?? 999) - (b.order ?? 999)));
      setSearchQuery('');
    }
  }, [isOpen, columns]);

  // Move column up/down/top/bottom in list
  const moveColumn = (key: string, direction: 'UP' | 'DOWN' | 'TOP' | 'BOTTOM') => {
    const list = [...localColumns];
    const index = list.findIndex((c) => c.key === key);
    if (index === -1) return;

    const [item] = list.splice(index, 1);

    if (direction === 'TOP') {
      list.unshift(item);
    } else if (direction === 'BOTTOM') {
      list.push(item);
    } else if (direction === 'UP' && index > 0) {
      list.splice(index - 1, 0, item);
    } else if (direction === 'DOWN' && index < list.length) {
      list.splice(index + 1, 0, item);
    } else {
      list.splice(index, 0, item);
    }

    // Re-index orders strictly
    const reindexed = list.map((c, i) => ({
      ...c,
      order: i + 1,
    }));

    setLocalColumns(reindexed);
  };

  // Toggle Employee Visibility
  const toggleEmployeeVisibility = (key: string) => {
    setLocalColumns((prev) =>
      prev.map((c) => {
        if (c.key === key) {
          const nextVal = c.employeeVisible === false ? true : false;
          return { ...c, employeeVisible: nextVal };
        }
        return c;
      })
    );
  };

  // Preset: Reset to standard default
  const handleResetToDefault = async () => {
    setIsSaving(true);
    try {
      const resetCols = await resetColumnOrderToDefault();
      setLocalColumns(resetCols);
      onColumnsUpdated(resetCols);
      onNotify('Column positions and employee visibility reset to default 31-column standard.');
    } catch {
      onNotify('Failed to reset columns.');
    } finally {
      setIsSaving(false);
    }
  };

  // Save changes
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const saved = await updateColumnOrderAndVisibility(localColumns);
      onColumnsUpdated(saved);
      onNotify(`Saved column layout: ${saved.length} columns ordered & configured for employees.`);
      onClose();
    } catch (err) {
      console.error(err);
      onNotify('Failed to save column layout.');
    } finally {
      setIsSaving(false);
    }
  };

  // Filter columns by search
  const filteredList = useMemo(() => {
    if (!searchQuery.trim()) return localColumns;
    const q = searchQuery.toLowerCase().trim();
    return localColumns.filter(
      (c) => c.label.toLowerCase().includes(q) || c.key.toLowerCase().includes(q)
    );
  }, [localColumns, searchQuery]);

  // Statistics
  const employeeVisibleCount = useMemo(() => {
    return localColumns.filter((c) => c.employeeVisible !== false).length;
  }, [localColumns]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4.5 bg-slate-50 border-b border-slate-200/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  Admin Column Position & Employee Visibility
                </h3>
                <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full">
                  Admin Privileges
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Reorder column positions (Aage / Peeche) and select which columns employees see after applying filters.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Subheader: Stats & Search */}
        <div className="px-6 py-3 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          {/* Search bar */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search column name (e.g. Email, Revenue, Job Title)..."
              className="w-full pl-8.5 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>

          {/* Employee Visibility Summary Badge */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-600 font-medium">
              Employee Visibility:
            </span>
            <span className="text-xs font-bold font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
              {employeeVisibleCount} of {localColumns.length} Visible
            </span>
          </div>
        </div>

        {/* Column List (Interactive Reordering & Toggle) */}
        <div className="flex-1 overflow-y-auto p-4 space-y-1.5 bg-slate-50/50">
          {filteredList.map((col, index) => {
            const originalIndex = localColumns.findIndex((c) => c.key === col.key);
            const isFirst = originalIndex === 0;
            const isLast = originalIndex === localColumns.length - 1;
            const isEmployeeVis = col.employeeVisible !== false;

            return (
              <div
                key={col.key}
                className={`flex items-center justify-between p-2.5 rounded-xl border bg-white shadow-xs transition-all ${
                  isEmployeeVis
                    ? 'border-slate-200 hover:border-blue-300'
                    : 'border-slate-200/80 bg-slate-50/70 opacity-80'
                }`}
              >
                {/* Left: Position Number & Column Info */}
                <div className="flex items-center gap-3 min-w-0 pr-2">
                  <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center text-[11px] font-mono font-bold shrink-0">
                    #{originalIndex + 1}
                  </div>
                  <div className="truncate">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 truncate">
                        {col.label}
                      </span>
                      {col.isCore && (
                        <span className="text-[9px] uppercase tracking-wider font-mono px-1 py-0.2 bg-slate-100 text-slate-600 rounded">
                          Standard
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      key: {col.key} · type: {col.type}
                    </span>
                  </div>
                </div>

                {/* Right: Visibility Toggle & Reorder Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  {/* Employee Visibility Button */}
                  <button
                    type="button"
                    onClick={() => toggleEmployeeVisibility(col.key)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      isEmployeeVis
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                        : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                    }`}
                    title={
                      isEmployeeVis
                        ? 'Visible to Employees after filter. Click to hide.'
                        : 'Hidden from Employees. Click to show.'
                    }
                  >
                    {isEmployeeVis ? (
                      <>
                        <Eye className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Visible to Employee</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5 text-rose-600" />
                        <span>Hidden for Employee</span>
                      </>
                    )}
                  </button>

                  {/* Reorder: Move to Top */}
                  <button
                    type="button"
                    disabled={isFirst}
                    onClick={() => moveColumn(col.key, 'TOP')}
                    className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                    title="Move to first position (#1)"
                  >
                    <ChevronsUp className="w-3.5 h-3.5" />
                  </button>

                  {/* Reorder: Move Up (Aage) */}
                  <button
                    type="button"
                    disabled={isFirst}
                    onClick={() => moveColumn(col.key, 'UP')}
                    className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-700 hover:text-blue-600 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 rounded-lg transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                    title="Move column forward (left in table)"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[11px]">Move Up</span>
                  </button>

                  {/* Reorder: Move Down (Peeche) */}
                  <button
                    type="button"
                    disabled={isLast}
                    onClick={() => moveColumn(col.key, 'DOWN')}
                    className="flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-700 hover:text-blue-600 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 rounded-lg transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                    title="Move column backward (right in table)"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[11px]">Move Down</span>
                  </button>

                  {/* Reorder: Move to Bottom */}
                  <button
                    type="button"
                    disabled={isLast}
                    onClick={() => moveColumn(col.key, 'BOTTOM')}
                    className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
                    title="Move to last position"
                  >
                    <ChevronsDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={handleResetToDefault}
            disabled={isSaving}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Standard Order (1 to 31)</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving Layout...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Column Layout & Apply</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { X, Clock, ShieldCheck, AlertCircle, Loader2, Globe, Monitor, RotateCw } from 'lucide-react';
import { EnterpriseUser } from '../../types/enterprise';
import { getUserLoginHistory } from '../../services/enterpriseDb';

interface UserLoginHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: EnterpriseUser | null;
}

export const UserLoginHistoryModal: React.FC<UserLoginHistoryModalProps> = ({
  isOpen,
  onClose,
  user,
}) => {
  const [logins, setLogins] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchLogins = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const logs = await getUserLoginHistory(user.id);
      setLogins(logs);
    } catch (err) {
      console.warn('Could not load login logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && user) {
      fetchLogins();
    }
  }, [isOpen, user]);

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fade-in font-sans">
      <div className="w-full max-w-2xl bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-[0_24px_60px_rgba(0,0,0,0.18)] p-6 sm:p-7 text-[#1D1D1F] relative max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 text-[#0071E3] flex items-center justify-center shadow-2xs">
              <Clock className="w-5 h-5 stroke-[1.8]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1D1D1F] tracking-tight">
                Login History Audit
              </h2>
              <p className="text-xs text-slate-500">
                Authentication events for <span className="font-semibold text-slate-800">{user.full_name}</span> ({user.email})
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={fetchLogins}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              title="Refresh login history"
            >
              <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2 text-slate-400">
              <Loader2 className="w-6 h-6 animate-spin text-[#0071E3]" />
              <span className="text-xs">Loading login logs...</span>
            </div>
          ) : logins.length === 0 ? (
            <div className="py-12 text-center bg-slate-50 rounded-2xl border border-slate-200/80 p-6">
              <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-700">No login records found yet</p>
              <p className="text-[11px] text-slate-400 mt-1">
                New login events will automatically record IP address, device, and timestamp.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-2xl overflow-hidden bg-white shadow-2xs">
              {logins.map((log) => {
                const date = new Date(log.created_at);
                const isSuccess = log.status === 'SUCCESS';
                return (
                  <div key={log.id} className="p-3.5 hover:bg-slate-50/80 transition-colors flex items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center mt-0.5 shrink-0 ${
                          isSuccess
                            ? 'bg-emerald-50 text-emerald-600 border border-emerald-200/80'
                            : 'bg-rose-50 text-rose-600 border border-rose-200/80'
                        }`}
                      >
                        {isSuccess ? <ShieldCheck className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {isSuccess ? 'Authorized Authentication' : 'Failed Attempt'}
                          </span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                              isSuccess
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {log.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                          <span className="flex items-center gap-1">
                            <Globe className="w-3 h-3 text-slate-400" />
                            <span>{log.ip_address || '127.0.0.1'}</span>
                          </span>
                          {log.user_agent && (
                            <span className="flex items-center gap-1 truncate max-w-xs text-slate-400">
                              <Monitor className="w-3 h-3" />
                              <span className="truncate">{log.user_agent}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-xs font-semibold text-slate-800">
                        {date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-400">
            Total recorded logins: <span className="font-semibold text-slate-700">{logins.length}</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};

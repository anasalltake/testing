import React, { useState, useEffect } from 'react';
import {
  Compass,
  ArrowRight,
  ArrowLeft,
  X,
  Search,
  Filter,
  SlidersHorizontal,
  Download,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Database,
  Lock,
  Layers
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export interface TourStep {
  title: string;
  subtitle: string;
  description: string;
  highlightIcon: React.ElementType;
  badge: string;
  badgeColor: string;
  keyFeature: string;
}

interface OnboardingTourProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

export const OnboardingTour: React.FC<OnboardingTourProps> = ({ forceOpen = false, onClose }) => {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const STORAGE_KEY = 'alltake_onboarding_tour_completed';

  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
      setCurrentStep(0);
      return;
    }

    const hasSeenTour = localStorage.getItem(STORAGE_KEY);
    if (!hasSeenTour && user) {
      // Small timeout to allow interface to render first
      const timer = setTimeout(() => {
        setIsOpen(true);
        setCurrentStep(0);
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [forceOpen, user]);

  const steps: TourStep[] = [
    {
      title: `Welcome to Alltake Data Core Software, ${user?.full_name?.split(' ')[0] || user?.username || 'Partner'}!`,
      subtitle: 'Enterprise Prospect Intelligence & Data Governance',
      description:
        'Your enterprise workspace connects you to high-fidelity, verified B2B prospect records. This 1-minute guided tour highlights the essential tools to help you search, filter, and export data with compliance.',
      highlightIcon: Compass,
      badge: 'Step 1 of 6 · Introduction',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
      keyFeature: 'Role-Authorized Single Sign-On with 5-hour cryptographic security.',
    },
    {
      title: 'Real-time Prospect Search Engine',
      subtitle: 'Sub-second multi-column indexing across thousands of records',
      description:
        'Use the top search bar to instantly query across all fields: Contact Name, Business Email, Direct Telephone, Company Name, Industry, and Corporate Domain with zero lag.',
      highlightIcon: Search,
      badge: 'Step 2 of 6 · Lead Discovery',
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      keyFeature: 'Supports global keyword search with server-authoritative pagination.',
    },
    {
      title: 'Smart Strategic Filters & Suggestions',
      subtitle: 'Target decision-makers by geography, hierarchy & sector',
      description:
        'Open the left filter drawer to narrow down prospects by country with typeahead suggestions, company revenue ranges, employee headcount, and auto-classified management levels (C-Suite, VP, Director).',
      highlightIcon: Filter,
      badge: 'Step 3 of 6 · Precision Targeting',
      badgeColor: 'bg-sky-50 text-sky-700 border-sky-200',
      keyFeature: 'Country suggestions with instant lead counts per geographic territory.',
    },
    {
      title: 'Dynamic Columns & PII Data Protection',
      subtitle: 'Custom table views with automated field masking',
      description:
        'Tailor your table view by dragging columns into your preferred order (First Name, Last Name, Email, Phone, Company). Sensitive contact fields are protected with automated role-based masking.',
      highlightIcon: SlidersHorizontal,
      badge: 'Step 4 of 6 · Column Layout',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      keyFeature: 'Personalized column ordering saved permanently to your workspace.',
    },
    {
      title: 'Governed Export Engine & Campaign Tracking',
      subtitle: 'OWASP-sanitized CSV & Excel exports with mandatory campaign codes',
      description:
        'Download custom datasets into Excel or CSV. Every export prompts for a Campaign/Project name and automatically dispatches email alerts to management for transparency and audit compliance.',
      highlightIcon: Download,
      badge: 'Step 5 of 6 · Export Operations',
      badgeColor: 'bg-amber-50 text-amber-800 border-amber-200',
      keyFeature: 'Built-in OWASP formula injection protection neutralizing Excel macros.',
    },
    {
      title: 'Approved Downloads & Governance Center',
      subtitle: 'High-volume batch approvals & compliance audit log',
      description:
        'Need to download records exceeding the standard threshold? Submit a 1-click Mass Export Request to the Administrator. Once approved, files appear instantly in your Approved Downloads tab.',
      highlightIcon: ShieldCheck,
      badge: 'Step 6 of 6 · Governance',
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      keyFeature: 'Immutable SHA-256 audit logging recording every export and login event.',
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    localStorage.setItem(STORAGE_KEY, 'true');
    setIsOpen(false);
    if (onClose) onClose();
  };

  if (!isOpen) return null;

  const current = steps[currentStep];
  const StepIcon = current.highlightIcon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fade-in font-sans">
      <div 
        className="w-full max-w-xl bg-white/95 backdrop-blur-2xl rounded-3xl border border-slate-200/90 shadow-[0_24px_60px_rgba(0,0,0,0.18),0_1px_3px_rgba(0,0,0,0.06)] p-6 sm:p-8 text-[#1D1D1F] relative overflow-hidden transition-all"
        role="dialog"
        aria-modal="true"
        aria-labelledby="tour-dialog-title"
      >
        {/* Apple-style Multi-Layer Glow */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-[#0071E3]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-44 h-44 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="inline-flex items-center gap-2">
            <span className={`text-[11px] font-semibold font-mono px-2.5 py-0.5 rounded-full border ${current.badgeColor}`}>
              {current.badge}
            </span>
            <span className="text-xs text-slate-400 font-medium hidden sm:inline">
              Alltake Data Core Software
            </span>
          </div>

          <button
            onClick={handleComplete}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            title="Skip tour"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tour Content */}
        <div className="py-6 space-y-5">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-100 text-[#0071E3] flex items-center justify-center shrink-0 shadow-2xs">
              <StepIcon className="w-7 h-7 stroke-[1.8]" />
            </div>

            <div className="space-y-1">
              <h2 id="tour-dialog-title" className="text-xl sm:text-2xl font-bold tracking-tight text-[#1D1D1F]">
                {current.title}
              </h2>
              <p className="text-xs font-semibold text-[#0071E3] tracking-wide">
                {current.subtitle}
              </p>
            </div>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed font-normal">
            {current.description}
          </p>

          {/* Highlight Key Feature Pill */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-2.5 text-xs text-slate-700">
            <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="font-medium">
              <span className="font-semibold text-slate-900">Key Feature: </span>
              {current.keyFeature}
            </span>
          </div>
        </div>

        {/* Footer: Progress Dots + Buttons */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
          {/* Progress Indicators */}
          <div className="flex items-center gap-1.5">
            {steps.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentStep(idx)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  idx === currentStep ? 'w-6 bg-[#0071E3]' : 'w-2 bg-slate-200 hover:bg-slate-300'
                }`}
                title={`Go to step ${idx + 1}`}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <button
                type="button"
                onClick={handlePrev}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200/80 transition-all flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleComplete}
              className="px-3 py-2 text-xs font-medium text-slate-400 hover:text-slate-600 transition-colors cursor-pointer mr-1 hidden sm:inline"
            >
              Skip
            </button>

            <button
              type="button"
              onClick={handleNext}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#0071E3] hover:bg-[#0077ED] active:scale-95 shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>{currentStep === steps.length - 1 ? 'Start Working' : 'Next'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

# ALLTAKE B2B Intelligence – Environment Configuration Guide

## 1. Environment Files
The platform utilizes environment variables to decouple secrets, database endpoints, and configuration parameters from code.

- Backend: `backend/.env`
- Root / Gateway: `.env`

---

## 2. Configuration Parameters

| Variable | Required | Default / Example | Purpose |
| :--- | :---: | :--- | :--- |
| `SECRET_KEY` | **Yes** | High-entropy 64-char string | Flask session signing and internal cryptographic token generation |
| `JWT_SECRET_KEY` | **Yes** | High-entropy 64-char string | HMAC-SHA256 signature secret for JWT tokens |
| `JWT_ACCESS_TOKEN_EXPIRES` | **Yes** | `18000` (seconds / 300 minutes) | Enforces exact 5-hour access token expiration |
| `JWT_ISSUER` | Optional | `alltake-auth` | Mandatory `iss` claim in all issued tokens |
| `JWT_AUDIENCE` | Optional | `alltake-enterprise` | Mandatory `aud` claim in all issued tokens |
| `DATABASE_URL` | **Yes** | `postgresql://user:pass@localhost:5432/alltake_db` | Primary PostgreSQL database connection string |
| `RESEND_API_KEY` | Optional | `re_QvqTztdy_***` | Transactional email provider for campaign alerts |
| `EMPLOYEE_MAX_DOWNLOAD_LIMIT` | Optional | `10000` | Maximum rows an employee can export without approval |
| `REQUIRE_APPROVAL_ABOVE_LIMIT` | Optional | `true` | Gatekeeper enforcing administrator review for mass exports |

---

## 3. Cryptographic Secret Generation (PowerShell)
To generate production-ready 64-character cryptographic secrets:
```powershell
$bytes = New-Object byte[] 32
[Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($bytes)
$secret = [Convert]::ToBase64String($bytes)
Write-Output "Generated Secret: $secret"
```
Place the generated string into `SECRET_KEY` and `JWT_SECRET_KEY` inside `backend/.env`.

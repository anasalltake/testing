# ALLTAKE Data Management System

**ALLTAKE Data Management** is an enterprise-grade Lead Analytics and Dataset Management platform engineered to securely ingest, store, search, filter, analyze, and export large-scale organizational datasets.

Designed for high-performance and data privacy, ALLTAKE eliminates client-side data bottlenecks by enforcing server-side pagination, indexed PostgreSQL queries, chunked background imports, dynamic CSV column mapping, and granular Role-Based Access Control (RBAC).

---

## 1. System Architecture

```text
                             ALLTAKE UI
                     (React + TypeScript + Tailwind)
                                   │
                                   │ REST API (JSON / Multipart)
                                   ▼
                           FLASK REST BACKEND
                       (Python 3.10+ / Gunicorn)
                                   │
                                   │ SQLAlchemy 2.0 ORM & Alembic
                                   ▼
                         POSTGRESQL DATABASE (v15/16)
          ┌────────────────────────┼────────────────────────┐
          │                        │                        │
     users / RBAC               datasets               upload_jobs
  login_logs / audit_logs    dataset_columns         download_jobs
                             dataset_records
                        (Indexed + Native JSONB)
```

- **Single Backend Source of Truth**: Flask REST API backed by PostgreSQL.
- **Dynamic Columns**: Core fields are indexed for sub-second queries; all novel/dynamic CSV fields are automatically registered and stored in PostgreSQL `JSONB`.
- **Large Dataset Architecture**: Streamed chunked ingestion (never loads millions of rows into RAM at once). Server-side pagination (25, 50, 100, 250 rows).
- **Security & Compliance**: SHA-256 / Bcrypt password hashing, JWT session authentication, immutable audit trail with client IP capture, and download logs.

---

## 2. Requirements

- **Python**: 3.10, 3.11, or 3.12
- **Node.js**: v18.0.0 or higher (v20+ recommended)
- **PostgreSQL**: 14, 15, or 16
- **Redis** *(Optional)*: For distributed asynchronous Celery workers in multi-million row scale

---

## 3. Quick Start (Automated Setup)

### Linux / macOS:
```bash
chmod +x setup_linux.sh
./setup_linux.sh
```

### Windows:
Double-click `setup_windows.bat` or run in Command Prompt:
```cmd
setup_windows.bat
```

---

## 4. Manual Installation & Configuration

### Step 1: Backend Setup
```bash
# Navigate to backend directory
cd backend

# Create and activate Python virtual environment
python3 -m venv venv

# On Linux/macOS:
source venv/bin/activate
# On Windows:
# venv\Scripts\activate

# Install Python requirements
pip install -r requirements.txt

# Configure environment variables
cp .env.example .env
```

Edit `backend/.env` with your PostgreSQL database credentials:
```env
# Format: postgresql+psycopg://username:password@localhost:5432/alltake_db
DATABASE_URL=postgresql+psycopg://alltake_app:secure_alltake_pwd_2026@localhost:5432/alltake_db
SECRET_KEY=generate-a-strong-random-key-here
JWT_SECRET_KEY=generate-a-distinct-strong-jwt-key
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

### Step 2: PostgreSQL Database & Migrations
Create your database in PostgreSQL (e.g. using `psql` or pgAdmin):
```sql
CREATE DATABASE alltake_db;
CREATE USER alltake_app WITH ENCRYPTED PASSWORD 'secure_alltake_pwd_2026';
GRANT ALL PRIVILEGES ON DATABASE alltake_db TO alltake_app;
```

Run Alembic schema migrations:
```bash
flask db upgrade
```
*This automatically provisions all 8 managed tables, indexes, constraints, and JSONB schemas.*

### Step 3: Seed Administrator Credentials
```bash
python seed.py
```
Default provisioned credentials:
- **Executive Admin**: `admin@alltake.com` / `Admin@Alltake2026!`
- **Data Manager**: `manager@alltake.com` / `Manager@Alltake2026!`
- **Sales Employee**: `employee@alltake.com` / `Employee@Alltake2026!`

### Step 4: Start Flask Backend (Port 5000)
```bash
python run.py
```
*Health verification endpoint available at:* `http://localhost:5000/api/health`

### Step 5: Start React Frontend (Port 3000)
In a separate terminal at the project root:
```bash
npm install
npm run dev
```
Visit `http://localhost:3000` in your web browser.

---

## 5. Roles & Permissions (RBAC)

| Capability | ADMIN | DATA MANAGER | EMPLOYEE |
| :--- | :---: | :---: | :---: |
| **Executive Telemetry Dashboard** | Full | Role Specific | Role Specific |
| **Data Explorer & Search** | Full | Full | Full |
| **Country Analytics** | Full | View | Full |
| **Filtered CSV / Excel Export** | Full | Full | Full |
| **CSV Bulk Ingestion** | Full | Full | ✗ |
| **Dynamic Column Registration** | Full | Full | ✗ |
| **User Account Provisioning** | Full | ✗ | ✗ |
| **Account Disabling / Enabling** | Full | ✗ | ✗ |
| **Password Resets** | Full | ✗ | ✗ |
| **Audit Trail Logs & Payloads** | Full | ✗ | ✗ |
| **Security Login Logs & IPs** | Full | ✗ | ✗ |
| **Database & System Diagnostics**| Full | ✗ | ✗ |

---

## 6. Production Deployment Guide (Gunicorn + Nginx)

### Production Topology
```text
HTTPS Client
     │
     ▼
Nginx (Reverse Proxy & Static Asset Caching on Port 80/443)
     ├── /api/* ──> Gunicorn WSGI Workers (Flask on 127.0.0.1:5000)
     └── /*     ──> Pre-compiled React SPA (/dist/index.html)
```

### 1. Build the React SPA:
```bash
npm run build
```
The optimized production bundle will be generated in `./dist`.

### 2. Run Gunicorn WSGI Server:
```bash
cd backend
source venv/bin/activate
gunicorn --workers 4 --threads 2 --bind 127.0.0.1:5000 --timeout 120 --access-logfile - "run:app"
```

### 3. Example Nginx Server Block:
```nginx
server {
    listen 80;
    server_name alltake.company.internal;

    # Serve React Static Frontend
    location / {
        root /var/www/alltake/dist;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Proxy REST API to Gunicorn
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        client_max_body_size 100M;
    }
}
```

---

## 7. PostgreSQL Backup & Maintenance

### Automated Daily Database Dump:
```bash
pg_dump -U alltake_app -F c -b -v -f "/backups/alltake_$(date +%Y%m%d).backup" alltake_db
```

### Database Restore:
```bash
pg_restore -U alltake_app -d alltake_db -v "/backups/alltake_20261003.backup"
```

---

## 8. Troubleshooting

| Symptom | Diagnostic & Solution |
| :--- | :--- |
| `psycopg.OperationalError: connection to server failed` | Verify PostgreSQL is running (`sudo service postgresql status` or Windows Services). Check host, port, and credentials in `backend/.env`. |
| `CORS Error in browser console` | Verify `CORS_ORIGINS` in `backend/.env` matches your frontend origin (e.g. `http://localhost:3000`). |
| `API returns 503 /api/health disconnected` | Flask cannot run `SELECT 1` on PostgreSQL. Check database permissions and table existence. |
| `File upload rejected (413 Payload Too Large)` | Increase `MAX_CONTENT_LENGTH` in `backend/.env` and Nginx `client_max_body_size`. |

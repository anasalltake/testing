#!/bin/bash
set -e

echo "=========================================================="
echo "    ALLTAKE DATA MANAGEMENT SYSTEM - LINUX SETUP SCRIPT   "
echo "=========================================================="

echo "[1/4] Checking Python 3..."
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required. Please install Python 3.10+."
    exit 1
fi

echo "[2/4] Setting up Python virtual environment..."
if [ ! -d "backend/venv" ]; then
    python3 -m venv backend/venv
fi
source backend/venv/bin/activate

echo "[3/4] Installing backend dependencies..."
pip install --upgrade pip
pip install -r backend/requirements.txt

echo "[4/5] Setting up environment variables..."
if [ ! -f "backend/.env" ]; then
    cp backend/.env.example backend/.env
    echo "Created backend/.env from .env.example. Please review database credentials."
fi

echo "[5/5] Installing frontend dependencies..."
npm install

echo "=========================================================="
echo "Setup completed successfully!"
echo "Next Steps:"
echo "1. Configure your PostgreSQL DATABASE_URL in backend/.env"
echo "2. Run database migrations:"
echo "     cd backend && flask db upgrade"
echo "3. Seed default admin credentials:"
echo "     python backend/seed.py"
echo "4. Start Flask backend (port 5000):"
echo "     python backend/run.py"
echo "5. Start React frontend (port 3000):"
echo "     npm run dev"
echo "=========================================================="

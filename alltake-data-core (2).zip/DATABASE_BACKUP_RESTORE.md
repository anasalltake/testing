# ALLTAKE B2B Intelligence – Database Backup and Recovery Guide

## 1. Overview
This runbook details procedures for scheduled backups, live snapshots, and point-in-time recovery for both PostgreSQL relational repositories and the persistent disk storage engine.

---

## 2. Backup Schedules
- **Automated Full Backup**: Daily at 02:00 UTC.
- **Differential / WAL Archiving**: Every 60 minutes.
- **Pre-Upgrade Snapshots**: Mandatory before any schema migration or system update.

---

## 3. PostgreSQL Backup Procedures

### 3.1 PowerShell Scheduled Script (`backup_pg.ps1`)
```powershell
$date = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "C:\Backups\PostgreSQL"
$backupFile = "$backupDir\alltake_db_$date.dump"

if (!(Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir -Force
}

& "C:\Program Files\PostgreSQL\15\bin\pg_dump.exe" `
    --host="localhost" `
    --port="5432" `
    --username="alltake_user" `
    --format=c `
    --blobs `
    --verbose `
    --file=$backupFile `
    alltake_db

# Purge backups older than 30 days
Get-ChildItem -Path $backupDir -Filter "*.dump" | Where-Object { $_.CreationTime -lt (Get-Date).AddDays(-30) } | Remove-Item -Force
```

### 3.2 Persistent Data Directory Snapshot (`backup_data.ps1`)
```powershell
$date = Get-Date -Format "yyyyMMdd_HHmmss"
$source = "C:\inetpub\wwwroot\alltake-core\data"
$dest = "C:\Backups\DiskStorage\data_$date.zip"

Compress-Archive -Path $source -DestinationPath $dest -Force
```

---

## 4. Disaster Recovery & Restoration

### 4.1 Restoring PostgreSQL from Dump
```cmd
:: 1. Terminate active database connections
psql -U postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'alltake_db';"

:: 2. Drop and recreate clean database
psql -U postgres -c "DROP DATABASE alltake_db;"
psql -U postgres -c "CREATE DATABASE alltake_db OWNER alltake_user;"

:: 3. Restore from verified archive
pg_restore -U alltake_user -d alltake_db -v "C:\Backups\PostgreSQL\alltake_db_20261105_020000.dump"
```

### 4.2 Restoring Persistent JSON Database
```cmd
Expand-Archive -Path "C:\Backups\DiskStorage\data_20261105.zip" -DestinationPath "C:\inetpub\wwwroot\alltake-core\data" -Force
```

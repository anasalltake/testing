# ALLTAKE B2B Intelligence – REST API Reference

## Base URLs
- **Vite/Express Gateway**: `http://localhost:3000/api`
- **Flask WSGI Core**: `http://localhost:5000/api`

---

## 1. Authentication Endpoints

### 1.1 `POST /auth/login`
Authenticate corporate user credentials and receive a cryptographically signed 5-hour JWT.
- **Request Body**:
  ```json
  {
    "identifier": "admin@alltake.com",
    "password": "Admin@Alltake2026!"
  }
  ```
- **Response (200 OK)**:
  ```json
  {
    "success": true,
    "token": "eyJhbGciOiJIUzI1NiIsIn...",
    "user": {
      "id": "usr_admin",
      "email": "admin@alltake.com",
      "username": "admin",
      "full_name": "Alexandre Vane",
      "role": "ADMIN",
      "status": "ACTIVE"
    }
  }
  ```

### 1.2 `GET /auth/me`
Verify active session token and retrieve current user permissions.
- **Headers**: `Authorization: Bearer <token>`
- **Response (200 OK)**: Returns user object.

### 1.3 `POST /auth/logout`
Revoke the caller's JWT token on the server side and record audit log.
- **Headers**: `Authorization: Bearer <token>`
- **Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "Thank you, Alexandre Vane! You have been securely logged out.",
    "user_name": "Alexandre Vane"
  }
  ```

---

## 2. Lead Discovery & Dynamic Query

### 2.1 `GET /leads`
Dynamic multi-column search, filtering, and server-side pagination.
- **Query Parameters**:
  - `page`: Page number (default: 1)
  - `limit`: Records per page (default: 25, supports up to 500,000 for exact count exports)
  - `q`: Global search string across all columns
  - `country`, `state`, `city`, `companyName`, `industryType`, `jobTitle`: Column-specific filter values
- **Field-Level Masking**: If requester has `EMPLOYEE` role, sensitive PII fields (email, direct phone, mobile) are automatically masked unless approved.

---

## 3. Export Governance & Approval Gatekeeper

### 3.1 `POST /exports/validate-limit`
Verify whether a requested batch download falls within the employee's configured threshold.
- **Request Body**: `{ "recordCount": 15000 }`
- **Response**:
  ```json
  {
    "allowed": false,
    "requiresApproval": true,
    "limit": 10000,
    "requested": 15000,
    "message": "Approval required from Administrator for exports exceeding 10,000 records."
  }
  ```

### 3.2 `POST /exports/request-approval`
Submit a formal export justification request to the Super Administrator.
- **Request Body**:
  ```json
  {
    "requested_count": 15000,
    "campaign_name": "Q4 Enterprise Outreach",
    "justification": "Targeting European FinTech decision-makers."
  }
  ```

### 3.3 `POST /exports/notify`
Record mandatory campaign tracking, audit entry, and dispatch automated Resend email alerts.

---

## 4. Admin Management Center

### 4.1 `GET /admin/users`
List all registered personnel with status and last login timestamp.

### 4.2 `POST /admin/users/:id/reset-password`
Administrator resets a user's password; automatically invalidates all previous active tokens for that user ID.

### 4.3 `PUT /admin/columns`
Update column display ordering, visibility, and employee masking rules.

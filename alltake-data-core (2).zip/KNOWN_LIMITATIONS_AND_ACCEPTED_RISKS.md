# ALLTAKE B2B Intelligence – Known Limitations and Accepted Risks

## 1. Overview
In accordance with transparent DevSecOps practices, this document outlines minor operational considerations and accepted system characteristics for ALLTAKE B2B Intelligence.

---

## 2. Documented Considerations

### 2.1 Multi-Server Token Revocation Synchronization
- **Description**: The in-memory token revocation registries (`REVOKED_JTIS` in Flask and `revokedTokensDb` in Node) operate per process worker.
- **Production Guidance**: In a multi-node horizontal cluster behind a load balancer, configure a shared Redis instance as documented in `backend/app/config.py` (`REDIS_URL`) so blacklisted JTIs synchronize across clustered nodes instantly.
- **Current Mitigation**: Single-server Windows Waitress deployment shares worker state cleanly through central process threads.

### 2.2 Maximum Single Excel Worksheet Limits
- **Description**: Microsoft Excel files (`.xlsx`) have a native architectural limit of 1,048,576 rows per worksheet.
- **Production Guidance**: For datasets exceeding 1,000,000 records, the application directs users to choose CSV format, which supports unlimited streaming rows.

### 2.3 Resend API Delivery Quotas
- **Description**: Automated email notifications depend on valid Resend API keys (`re_...`). If the key is revoked or exceeds monthly tier limits, alerts are safely logged in the audit ledger without interrupting lead downloads.

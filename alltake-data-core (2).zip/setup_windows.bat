@echo off
echo ==========================================================
echo    ALLTAKE DATA MANAGEMENT SYSTEM - WINDOWS SETUP SCRIPT
echo ==========================================================

python --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 is required. Please install Python from python.org.
    exit /b 1
)

echo [1/3] Creating virtual environment...
if not exist "backend\venv" (
    python -m venv backend\venv
)
call backend\venv\Scripts\activate

echo [2/3] Installing requirements...
python -m pip install --upgrade pip
pip install -r backend\requirements.txt

echo [3/4] Setting up environment variables...
if not exist "backend\.env" (
    copy backend\.env.example backend\.env
    echo Copied backend\.env.example to backend\.env
)

echo [4/4] Installing frontend packages...
call npm install

echo ==========================================================
echo Setup Complete!
echo Next Steps:
echo 1. Put your PostgreSQL DATABASE_URL in backend\.env
echo 2. Run migrations:
echo    cd backend ^&^& flask db upgrade
echo 3. Seed administrator credentials:
echo    python backend\seed.py
echo 4. Start Flask backend (Port 5000):
echo    python backend\run.py
echo 5. In a new terminal, start React frontend (Port 3000):
echo    npm run dev
echo ==========================================================

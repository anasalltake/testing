# Changelog – ALLTAKE B2B Intelligence Enterprise Core

## [5.0.0-ENTERPRISE] - 2026-11-05

### Security & Authentication Hardening
- **Eliminated Hardcoded Bypasses**: Removed all plaintext passwords, test strings, and emergency backdoors across both Flask and Express backends.
- **Cryptographic Password Validation**: Enforced strict `bcrypt` verification on every login request.
- **Exact 5-Hour JWT Token Lifetime**: Standardized token expiration to exactly 300 minutes (18,000 seconds) across all endpoints.
- **Unique JTI Claims & Server-Side Revocation**: Added unique UUID v4 `jti` to every issued JWT.
- **Immediate Token Revocation on Logout**: When a user logs out, their token's `jti` is added to the server revocation blacklist.
- **Password Reset & Account Lock Token Invalidation**: Modifying user credentials or locking an account immediately invalidates all active sessions for that user ID.
- **Polished Apple-Style Logout Modal**: Displays dynamic user name ("Thank you, [User Full Name]! You have been securely logged out...") with an immediate **LOGIN AGAIN** button.
- **OWASP CSV Formula Injection Defense**: Added cell-level sanitization prepending `'` to any cell starting with `=`, `+`, `-`, `@`, `\t`, `\r` to neutralize spreadsheet code execution.

### Export Engine & Performance
- **Memory-Efficient Batch Streaming**: Implemented SQLAlchemy `yield_per(1000)` and write-only Excel worksheet streaming for exports up to 1,000,000+ records.
- **Approval Gatekeeper**: Enforced server-side checks preventing non-administrators from exporting above quota without formal administrator approval.
- **Mandatory Campaign Tracking**: Required campaign codes for exports, accompanied by automated Resend email alerts.

### UI & Aesthetics
- **Apple Light Frosted Aesthetic**: Clean white background (`#F5F5F7`), multi-layer ambient glows, 3 feature cards (Role Governance, Audited Access, Campaign Tracking).
- **Anti-AI Slop & Zero Element Collisions**: Strict grid responsiveness without overlapping containers at 80%, 100%, 125%, and 150% browser zoom levels.

### Deployment & Windows Production
- Added `setup_windows.bat` and `run_windows.bat`.
- Authored `DEPLOYMENT_WINDOWS.md`, `SECURITY.md`, `API_DOCUMENTATION.md`, `PERFORMANCE_TESTING.md`, and `BACKUP_AND_RECOVERY.md`.

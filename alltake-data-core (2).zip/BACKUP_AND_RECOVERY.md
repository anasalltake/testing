# ALLTAKE B2B Intelligence – Backup & Disaster Recovery Guide

## 1. Overview
This runbook describes the backup, verification, and disaster recovery procedures for ALLTAKE B2B Intelligence persistent data repositories.

---

## 2. Data Repositories

1. **Relational Database (PostgreSQL / SQLite)**:
   - `users`: User profiles, bcrypt password hashes, roles, and status.
   - `datasets` & `dataset_records`: Ingested prospect intelligence records.
   - `login_logs` & `audit_logs`: Immutable security and access trails.
   - `download_jobs`: Export history and campaign parameters.

2. **Persistent Express Storage Engine (`/data`)**:
   - `users_db.json`, `leads_db.json`, `columns_db.json`, `visibility_rules.json`, `export_requests.json`, `email_settings.json`.

---

## 3. Automated Backup Procedures

### 3.1 PostgreSQL Backup (Nightly Cron / Task Scheduler)
```bash
pg_dump -U alltake_user -h localhost -d alltake_db -F c -b -v -f "/backup/alltake_db_$(date +%Y%m%d_%H%M%S).dump"
```

### 3.2 Persistent Disk Storage Snapshot
```cmd
:: Windows PowerShell snapshot script
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$destination = "C:\Backups\alltake_data_$timestamp.zip"
Compress-Archive -Path "C:\inetpub\wwwroot\alltake-applet\data" -DestinationPath $destination
```

---

## 4. Disaster Recovery & Restoration

### 4.1 Restoring PostgreSQL Database
```bash
pg_restore -U alltake_user -d alltake_db -v "/backup/alltake_db_20261105_023000.dump"
```

### 4.2 Restoring JSON Disk Engine
```cmd
Expand-Archive -Path "C:\Backups\alltake_data_20261105.zip" -DestinationPath "C:\inetpub\wwwroot\alltake-applet\data" -Force
```

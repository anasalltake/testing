# ALLTAKE B2B Intelligence – Baseline Security Audit (Before Remediation)

## Executive Summary
This document records the comprehensive baseline security assessment performed on the legacy codebase prior to architectural and security remediation.

---

## Findings Inventory

### [SEC-VULN-001] [CRITICAL] Hardcoded Default Credentials & Passwords
- **Affected Files**: `server.ts` (lines 1094–1101), `backend/app/routes/auth.py` (lines 75–80)
- **Root Cause**: Conditional password bypasses comparing input against literal strings (`Admin@Alltake2026!`, `Manager@Alltake2026!`, `Employee@Alltake2026!`, `Admin@123`, `Password@123`).
- **Exploitation Scenario**: An attacker could log into any administrative account using public test credentials regardless of the user's actual password hash stored in the database.
- **Business Impact**: Full administrative takeover, unauthorized data exfiltration, violation of GDPR/SOC2.
- **Required Remediation**: Eliminate all plaintext string checks; strictly enforce cryptographic `bcrypt` hash comparison (`work factor 10`).

### [SEC-VULN-002] [HIGH] Client-Side Offline Authentication Fallback
- **Affected Files**: `src/contexts/AuthContext.tsx` (lines 132–159)
- **Root Cause**: If backend was unreachable or returned an error, the client generated local synthetic JWT strings (`jwt_alltake_<id>_<timestamp>`) without verifying passwords.
- **Exploitation Scenario**: An attacker disabling network access in DevTools could access any local user profile without entering a valid password.
- **Business Impact**: Bypassed authentication boundaries on employee workstations.
- **Required Remediation**: Remove offline passwordless fallback entirely. All authentication must be verified by the authoritative server.

### [SEC-VULN-003] [HIGH] Lack of Immediate Token Revocation on Logout
- **Affected Files**: `backend/app/routes/auth.py`, `server.ts`
- **Root Cause**: Logout simply cleared the client-side cookie or localStorage without invalidating the token on the server.
- **Exploitation Scenario**: A stolen token retained validity for the entire token lifetime even after the victim explicitly clicked "Sign Out".
- **Business Impact**: Session hijacking risk in shared workstation environments.
- **Required Remediation**: Implement server-side JTI blacklisting (`revokedTokensDb` / `REVOKED_JTIS`) and user-level invalidation timestamps (`userRevocationTimestamps`).

### [SEC-VULN-004] [HIGH] OWASP CSV / Excel Formula Injection (DDE Execution)
- **Affected Files**: `backend/app/services/excel_exporter.py`, `server.ts`
- **Root Cause**: Unsanitized user inputs starting with `=`, `+`, `-`, `@`, `\t`, `\r` written directly into exported CSV and spreadsheet files.
- **Exploitation Scenario**: Malicious lead data containing `=cmd|' /C calc'!A0` executed arbitrary commands on victims' machines when opened in Microsoft Excel.
- **Business Impact**: Client-side code execution on employees and customers opening downloaded lead reports.
- **Required Remediation**: Sanitize every cell by prepending `'` to neutralize formula execution.

### [SEC-VULN-005] [MEDIUM] Inconsistent JWT Token Lifetime
- **Affected Files**: `server.ts`, `backend/app/auth/jwt_handler.py`
- **Root Cause**: Server issued 24-hour tokens in some routes instead of the enterprise mandated exact 5-hour (`300 minutes`) lifetime.
- **Exploitation Scenario**: Extended exposure window for active tokens.
- **Business Impact**: Increased breach blast radius.
- **Required Remediation**: Standardize all JWT generation to exact 300 minutes (18,000 seconds) with unique `jti`, `iss`, `aud`.

### [SEC-VULN-006] [MEDIUM] Absence of First-Time Guided Tour & Onboarding
- **Affected Files**: Frontend UI
- **Root Cause**: New team members lacked structured guidance on search, filter, column customization, and export governance workflows.
- **Business Impact**: High support ticket volume, accidental export limit violations.
- **Required Remediation**: Implement an interactive 6-step Apple-style product tour with replay capability.
